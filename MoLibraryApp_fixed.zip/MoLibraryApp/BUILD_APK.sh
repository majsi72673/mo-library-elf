#!/bin/bash
# ============================================================
# MO Library PS5 — Android APK Build Script
# Run on Codespaces: bash BUILD_APK.sh
# ============================================================
# FIX: المشروع يستخدم AGP 8.2.0 ويتطلب Gradle 8.2 بالضبط.
# السكربت القديم كان يثبت Gradle من apt (نسخة غير متوافقة)
# وهذا يسبب خطأ: Cannot mutate the dependencies of configuration
# ':app:debugCompileClasspath' after the configuration was resolved
# الحل: تحميل Gradle 8.2 مباشرة + تنظيف الكاش القديم.
# ============================================================
set -e
cd "$(dirname "$0")"

GRADLE_VERSION=8.2
GRADLE_HOME=/opt/gradle-${GRADLE_VERSION}

echo "================================================"
echo " MO Library PS5 — Android APK Builder"
echo "================================================"

# [0/5] JDK 17
if ! java -version 2>&1 | grep -q "17\|21"; then
    echo "[0/5] Installing JDK 17..."
    sudo apt-get update -qq
    sudo apt-get install -y -qq openjdk-17-jdk
fi
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64

# [1/5] Gradle 8.2 (متوافق مع AGP 8.2.0 — لا تستخدم apt)
if [ ! -d "$GRADLE_HOME" ]; then
    echo "[1/5] Installing Gradle ${GRADLE_VERSION}..."
    sudo apt-get install -y -qq wget unzip
    wget -q https://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip \
        -O /tmp/gradle.zip
    sudo unzip -q /tmp/gradle.zip -d /opt/
    rm -f /tmp/gradle.zip
fi
export PATH=${GRADLE_HOME}/bin:$PATH
echo "Gradle version: $(gradle --version | grep '^Gradle' | awk '{print $2}')"

# [2/5] Android SDK
export ANDROID_HOME=/opt/android-sdk
export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools

if [ ! -d "/opt/android-sdk/platforms/android-34" ]; then
    echo "[2/5] Installing Android SDK..."
    sudo mkdir -p /opt/android-sdk/cmdline-tools
    wget -q https://dl.google.com/android/repository/commandlinetools-linux-10406996_latest.zip \
        -O /tmp/cmdtools.zip
    unzip -q /tmp/cmdtools.zip -d /tmp/cmdtools
    sudo rm -rf /opt/android-sdk/cmdline-tools/latest
    sudo mv /tmp/cmdtools/cmdline-tools /opt/android-sdk/cmdline-tools/latest
    rm -f /tmp/cmdtools.zip

    yes | sdkmanager --licenses > /dev/null 2>&1 || true
    sdkmanager "platforms;android-34" "build-tools;34.0.0" "platform-tools" > /dev/null 2>&1
    echo "Android SDK installed"
else
    echo "[2/5] Android SDK found"
fi

# [3/5] تنظيف حالة Gradle القديمة (كاش من نسخة غير متوافقة)
echo "[3/5] Cleaning old build state..."
rm -rf .gradle app/build build

# [4/5] Build
echo "[4/5] Building APK (this takes a few minutes on first run)..."
gradle assembleDebug --no-daemon

APK=$(find . -name "*.apk" | head -1)
if [ -z "$APK" ]; then
    echo "ERROR: APK not found"
    exit 1
fi

echo "[5/5] Done!"
echo "================================================"
echo " APK: $APK"
echo " Size: $(du -sh $APK | cut -f1)"
echo "================================================"
echo ""
echo "نقل الـ APK للمشروع الرئيسي:"
cp "$APK" /workspaces/mo-library-elf/MoLibrary_PS5.apk 2>/dev/null || true
echo "تحميل: /workspaces/mo-library-elf/MoLibrary_PS5.apk"
