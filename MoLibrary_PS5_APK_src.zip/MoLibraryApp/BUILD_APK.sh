#!/bin/bash
# ============================================================
# MO Library PS5 — Android APK Build Script
# Run on Codespaces: bash BUILD_APK.sh
# ============================================================
set -e
cd "$(dirname "$0")"

echo "================================================"
echo " MO Library PS5 — Android APK Builder"
echo "================================================"

# Install Android SDK if not present
if [ ! -d "/opt/android-sdk" ]; then
    echo "[1/4] Installing Android SDK..."
    sudo apt-get update -qq
    sudo apt-get install -y -qq openjdk-17-jdk wget unzip

    mkdir -p /opt/android-sdk/cmdline-tools
    wget -q https://dl.google.com/android/repository/commandlinetools-linux-10406996_latest.zip \
        -O /tmp/cmdtools.zip
    unzip -q /tmp/cmdtools.zip -d /tmp/cmdtools
    sudo mv /tmp/cmdtools/cmdline-tools /opt/android-sdk/cmdline-tools/latest
    rm -f /tmp/cmdtools.zip

    export ANDROID_HOME=/opt/android-sdk
    export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools

    yes | sdkmanager --licenses > /dev/null 2>&1 || true
    sdkmanager "platforms;android-34" "build-tools;34.0.0" > /dev/null 2>&1
    echo "Android SDK installed"
else
    echo "[1/4] Android SDK found"
    export ANDROID_HOME=/opt/android-sdk
    export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools
fi

# Install Gradle
if ! command -v gradle &>/dev/null; then
    echo "[2/4] Installing Gradle..."
    sudo apt-get install -y -qq gradle
fi

echo "[3/4] Building APK..."
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
gradle assembleDebug --no-daemon -q

APK=$(find . -name "*.apk" | head -1)
if [ -z "$APK" ]; then
    echo "ERROR: APK not found"
    exit 1
fi

echo "[4/4] Done!"
echo "================================================"
echo " APK: $APK"
echo " Size: $(du -sh $APK | cut -f1)"
echo "================================================"
echo ""
echo "نقل الـ APK للمشروع الرئيسي:"
cp "$APK" /workspaces/mo-library-elf/MoLibrary_PS5.apk 2>/dev/null || true
echo "تحميل: /workspaces/mo-library-elf/MoLibrary_PS5.apk"
