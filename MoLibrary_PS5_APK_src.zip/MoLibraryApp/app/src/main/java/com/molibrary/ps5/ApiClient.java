package com.molibrary.ps5;

import android.util.Log;
import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;
import org.json.JSONObject;
import org.json.JSONArray;
import java.net.URI;
import java.util.concurrent.TimeUnit;
import okhttp3.*;

public class ApiClient {

    private static final String TAG = "MoLib";
    private static ApiClient instance;

    private String host;
    private int port = 8855;
    private OkHttpClient http;
    private WebSocketClient ws;
    private WsListener wsListener;

    public interface WsListener {
        void onEvent(String event, JSONObject data);
        void onConnected();
        void onDisconnected();
    }

    public interface Callback {
        void onSuccess(JSONObject data);
        void onError(String error);
    }

    public interface ArrayCallback {
        void onSuccess(JSONArray data);
        void onError(String error);
    }

    private ApiClient() {
        http = new OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build();
    }

    public static ApiClient getInstance() {
        if (instance == null) instance = new ApiClient();
        return instance;
    }

    public void setServer(String host, int port) {
        this.host = host;
        this.port = port;
    }

    public String getBaseUrl() {
        return "http://" + host + ":" + port;
    }

    public boolean isConnected() {
        return host != null && !host.isEmpty();
    }

    // ── HTTP GET ──────────────────────────────────────────────────────────────
    public void get(String path, Callback cb) {
        Request req = new Request.Builder()
            .url(getBaseUrl() + path)
            .build();

        http.newCall(req).enqueue(new okhttp3.Callback() {
            @Override public void onFailure(Call call, java.io.IOException e) {
                if (cb != null) cb.onError(e.getMessage());
            }
            @Override public void onResponse(Call call, Response resp) throws java.io.IOException {
                try {
                    String body = resp.body().string();
                    if (cb != null) cb.onSuccess(new JSONObject(body));
                } catch (Exception e) {
                    if (cb != null) cb.onError(e.getMessage());
                }
            }
        });
    }

    // ── HTTP POST JSON ────────────────────────────────────────────────────────
    public void post(String path, JSONObject payload, Callback cb) {
        RequestBody body = RequestBody.create(
            payload != null ? payload.toString() : "{}",
            MediaType.parse("application/json")
        );
        Request req = new Request.Builder()
            .url(getBaseUrl() + path)
            .post(body)
            .build();

        http.newCall(req).enqueue(new okhttp3.Callback() {
            @Override public void onFailure(Call call, java.io.IOException e) {
                if (cb != null) cb.onError(e.getMessage());
            }
            @Override public void onResponse(Call call, Response resp) throws java.io.IOException {
                try {
                    String b = resp.body().string();
                    if (cb != null) cb.onSuccess(new JSONObject(b));
                } catch (Exception e) {
                    if (cb != null) cb.onError(e.getMessage());
                }
            }
        });
    }

    // ── WebSocket ─────────────────────────────────────────────────────────────
    public void connectWs(WsListener listener) {
        this.wsListener = listener;
        try {
            URI uri = new URI("ws://" + host + ":" + port + "/ws");
            ws = new WebSocketClient(uri) {
                @Override public void onOpen(ServerHandshake h) {
                    Log.d(TAG, "WS connected");
                    if (wsListener != null) wsListener.onConnected();
                }
                @Override public void onMessage(String msg) {
                    try {
                        JSONObject j = new JSONObject(msg);
                        String event = j.optString("event");
                        if (wsListener != null) wsListener.onEvent(event, j);
                    } catch (Exception e) {
                        Log.e(TAG, "WS parse: " + e.getMessage());
                    }
                }
                @Override public void onClose(int code, String reason, boolean remote) {
                    Log.d(TAG, "WS closed: " + reason);
                    if (wsListener != null) wsListener.onDisconnected();
                }
                @Override public void onError(Exception e) {
                    Log.e(TAG, "WS error: " + e.getMessage());
                    if (wsListener != null) wsListener.onDisconnected();
                }
            };
            ws.connect();
        } catch (Exception e) {
            Log.e(TAG, "WS connect: " + e.getMessage());
        }
    }

    public void disconnectWs() {
        if (ws != null) { ws.close(); ws = null; }
    }

    // ── API shortcuts ─────────────────────────────────────────────────────────
    public void getStatus(Callback cb)   { get("/api/v1/status", cb); }
    public void getCatalog(Callback cb)  { get("/api/v1/catalog", cb); }
    public void getMods(Callback cb)     { get("/api/v1/mods", cb); }
    public void getPkgJobs(Callback cb)  { get("/api/v1/pkg/jobs", cb); }
    public void getPkgScan(Callback cb)  { get("/api/v1/pkg/scan", cb); }
    public void getLogs(Callback cb)     { get("/api/v1/logs", cb); }
    public void getQueue(Callback cb)    { get("/api/v1/status", cb); }

    public void installPkgUrl(String url, String dest, Callback cb) {
        try {
            JSONObject p = new JSONObject();
            p.put("url", url);
            p.put("dest", dest);
            post("/api/v1/pkg/install", p, cb);
        } catch (Exception e) { if (cb != null) cb.onError(e.getMessage()); }
    }

    public void installPkgLocal(String path, String dest, Callback cb) {
        try {
            JSONObject p = new JSONObject();
            p.put("path", path);
            p.put("dest", dest);
            post("/api/v1/pkg/install", p, cb);
        } catch (Exception e) { if (cb != null) cb.onError(e.getMessage()); }
    }

    public void enqueueTitle(String titleId, String variantId, String dest, Callback cb) {
        try {
            JSONObject p = new JSONObject();
            p.put("titleId", titleId);
            p.put("variantId", variantId);
            p.put("destPath", dest);
            post("/api/v1/queue", p, cb);
        } catch (Exception e) { if (cb != null) cb.onError(e.getMessage()); }
    }

    public void jobAction(String jobId, String action, Callback cb) {
        post("/api/v1/queue/" + jobId + "/" + action, null, cb);
    }

    public void modAction(String modId, String action, Callback cb) {
        post("/api/v1/mods/" + modId + "/" + action, null, cb);
    }
}
