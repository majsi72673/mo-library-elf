package com.molibrary.ps5;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class CatalogActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private SwipeRefreshLayout swipeRefresh;
    private EditText etSearch;
    private Spinner spinnerCategory, spinnerRegion;
    private TextView tvCount;
    private CatalogAdapter adapter;
    private List<JSONObject> allTitles = new ArrayList<>();
    private List<JSONObject> filteredTitles = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catalog);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("المكتبة");
        }

        recyclerView  = findViewById(R.id.recycler_catalog);
        swipeRefresh  = findViewById(R.id.swipe_refresh);
        etSearch      = findViewById(R.id.et_search);
        spinnerCategory = findViewById(R.id.spinner_category);
        spinnerRegion   = findViewById(R.id.spinner_region);
        tvCount       = findViewById(R.id.tv_count);

        adapter = new CatalogAdapter(filteredTitles, this::onTitleClick);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        // Category filter
        String[] cats = {"الكل","لعبة","DLC","تحديث","Backport","حزمة"};
        spinnerCategory.setAdapter(new ArrayAdapter<>(this,
            android.R.layout.simple_spinner_dropdown_item, cats));

        // Region filter
        String[] regions = {"الكل","US","EU","JP","ASIA"};
        spinnerRegion.setAdapter(new ArrayAdapter<>(this,
            android.R.layout.simple_spinner_dropdown_item, regions));

        // Search
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s,int a,int b,int c){}
            @Override public void onTextChanged(CharSequence s,int a,int b,int c){ applyFilter(); }
            @Override public void afterTextChanged(Editable s){}
        });

        spinnerCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p,View v,int pos,long id){ applyFilter(); }
            @Override public void onNothingSelected(AdapterView<?> p){}
        });

        spinnerRegion.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p,View v,int pos,long id){ applyFilter(); }
            @Override public void onNothingSelected(AdapterView<?> p){}
        });

        swipeRefresh.setColorSchemeResources(R.color.mo_red);
        swipeRefresh.setOnRefreshListener(this::loadCatalog);

        loadCatalog();
    }

    private void loadCatalog() {
        swipeRefresh.setRefreshing(true);
        ApiClient.getInstance().getCatalog(new ApiClient.Callback() {
            @Override public void onSuccess(JSONObject data) {
                runOnUiThread(() -> {
                    try {
                        JSONArray titles = data.getJSONArray("titles");
                        allTitles.clear();
                        for (int i = 0; i < titles.length(); i++)
                            allTitles.add(titles.getJSONObject(i));
                        applyFilter();
                    } catch (Exception e) {
                        Toast.makeText(CatalogActivity.this, "خطأ في التحميل", Toast.LENGTH_SHORT).show();
                    }
                    swipeRefresh.setRefreshing(false);
                });
            }
            @Override public void onError(String e) {
                runOnUiThread(() -> {
                    Toast.makeText(CatalogActivity.this, "❌ " + e, Toast.LENGTH_SHORT).show();
                    swipeRefresh.setRefreshing(false);
                });
            }
        });
    }

    private void applyFilter() {
        String query  = etSearch.getText().toString().trim().toLowerCase();
        String cat    = spinnerCategory.getSelectedItemPosition() == 0 ? "" :
                        new String[]{"","game","dlc","update","backport","package"}
                            [spinnerCategory.getSelectedItemPosition()];
        String region = spinnerRegion.getSelectedItemPosition() == 0 ? "" :
                        new String[]{"","US","EU","JP","ASIA"}
                            [spinnerRegion.getSelectedItemPosition()];

        filteredTitles.clear();
        for (JSONObject t : allTitles) {
            try {
                String title    = t.optString("title","").toLowerCase();
                String pub      = t.optString("publisher","").toLowerCase();
                String tCat     = t.optString("category","");
                String tRegion  = t.optString("region","");

                if (!query.isEmpty() && !title.contains(query) && !pub.contains(query)) continue;
                if (!cat.isEmpty()    && !tCat.equals(cat))        continue;
                if (!region.isEmpty() && !tRegion.equals(region))  continue;

                filteredTitles.add(t);
            } catch (Exception ignored) {}
        }

        tvCount.setText(filteredTitles.size() + " عنوان");
        adapter.notifyDataSetChanged();
    }

    private void onTitleClick(JSONObject title) {
        try {
            // Show install dialog
            JSONArray variants = title.getJSONArray("variants");
            String titleId = title.optString("id");
            String titleName = title.optString("title");

            String[] variantNames = new String[variants.length()];
            for (int i = 0; i < variants.length(); i++) {
                JSONObject v = variants.getJSONObject(i);
                long sz = v.optLong("sizeBytes");
                variantNames[i] = v.optString("format") + " — " + formatBytes(sz);
            }

            new android.app.AlertDialog.Builder(this)
                .setTitle(titleName)
                .setItems(variantNames, (dialog, which) -> {
                    try {
                        String variantId = variants.getJSONObject(which).optString("id");
                        ApiClient.getInstance().enqueueTitle(titleId, variantId, "/data",
                            new ApiClient.Callback() {
                                @Override public void onSuccess(JSONObject d) {
                                    runOnUiThread(() ->
                                        Toast.makeText(CatalogActivity.this,
                                            "✅ أُضيف للقائمة", Toast.LENGTH_SHORT).show());
                                }
                                @Override public void onError(String e) {
                                    runOnUiThread(() ->
                                        Toast.makeText(CatalogActivity.this,
                                            "❌ " + e, Toast.LENGTH_SHORT).show());
                                }
                            });
                    } catch (Exception e) { /* ignore */ }
                })
                .setNegativeButton("إلغاء", null)
                .show();
        } catch (Exception e) { /* ignore */ }
    }

    private String formatBytes(long b) {
        if (b < 1024L*1024*1024) return String.format("%.1f MB", b/(1024.0*1024));
        return String.format("%.2f GB", b/(1024.0*1024*1024));
    }

    @Override public boolean onSupportNavigateUp() { finish(); return true; }
}
