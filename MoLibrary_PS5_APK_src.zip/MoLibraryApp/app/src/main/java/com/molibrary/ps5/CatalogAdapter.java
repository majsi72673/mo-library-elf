package com.molibrary.ps5;

import android.view.*;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import org.json.JSONObject;
import java.util.List;

public class CatalogAdapter extends RecyclerView.Adapter<CatalogAdapter.VH> {

    public interface OnClick { void onClick(JSONObject title); }

    private final List<JSONObject> items;
    private final OnClick listener;

    public CatalogAdapter(List<JSONObject> items, OnClick listener) {
        this.items = items;
        this.listener = listener;
    }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.item_title, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        JSONObject t = items.get(pos);
        h.tvTitle.setText(t.optString("title", "?"));
        h.tvMeta.setText(t.optString("category","?").toUpperCase()
            + " • " + t.optString("region","?")
            + " • FW " + t.optString("requiredFirmware","?"));
        h.tvPublisher.setText(t.optString("publisher",""));

        int varCount = 0;
        try { varCount = t.getJSONArray("variants").length(); } catch(Exception ignored){}
        h.tvVariants.setText(varCount + " نسخ");

        h.itemView.setOnClickListener(v -> listener.onClick(t));
    }

    @Override public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvTitle, tvMeta, tvPublisher, tvVariants;
        VH(View v) {
            super(v);
            tvTitle     = v.findViewById(R.id.tv_title);
            tvMeta      = v.findViewById(R.id.tv_meta);
            tvPublisher = v.findViewById(R.id.tv_publisher);
            tvVariants  = v.findViewById(R.id.tv_variants);
        }
    }
}
