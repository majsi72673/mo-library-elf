package com.molibrary.ps5;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONObject;

public class ConnectActivity extends AppCompatActivity {

    private EditText etHost, etPort;
    private Button btnConnect;
    private TextView tvStatus, tvScan;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_connect);

        etHost      = findViewById(R.id.et_host);
        etPort      = findViewById(R.id.et_port);
        btnConnect  = findViewById(R.id.btn_connect);
        tvStatus    = findViewById(R.id.tv_status);
        tvScan      = findViewById(R.id.tv_scan);
        progressBar = findViewById(R.id.progress_bar);

        // Load saved connection
        SharedPreferences prefs = getSharedPreferences("MoLib", MODE_PRIVATE);
        etHost.setText(prefs.getString("host", ""));
        etPort.setText(String.valueOf(prefs.getInt("port", 8855)));

        // Show local WiFi IP as hint
        try {
            WifiManager wm = (WifiManager) getApplicationContext()
                .getSystemService(WIFI_SERVICE);
            int ip = wm.getConnectionInfo().getIpAddress();
            String ipStr = String.format("%d.%d.%d.%d",
                ip & 0xff, (ip >> 8) & 0xff, (ip >> 16) & 0xff, (ip >> 24) & 0xff);
            // Suggest PS5 is on same subnet
            String[] parts = ipStr.split("\\.");
            if (parts.length == 4)
                tvScan.setText("شبكتك: " + parts[0]+"."+parts[1]+"."+parts[2]+".x");
        } catch (Exception ignored) {}

        btnConnect.setOnClickListener(v -> attemptConnect());
    }

    private void attemptConnect() {
        String host = etHost.getText().toString().trim();
        String portStr = etPort.getText().toString().trim();

        if (host.isEmpty()) {
            etHost.setError("أدخل عنوان IP للـ PS5");
            return;
        }

        int port = 8855;
        try { port = Integer.parseInt(portStr); } catch (Exception ignored) {}

        ApiClient.getInstance().setServer(host, port);

        btnConnect.setEnabled(false);
        progressBar.setVisibility(View.VISIBLE);
        tvStatus.setText("جاري الاتصال بـ " + host + ":" + port + "...");

        final int finalPort = port;
        ApiClient.getInstance().getStatus(new ApiClient.Callback() {
            @Override public void onSuccess(JSONObject data) {
                runOnUiThread(() -> {
                    try {
                        String fw = data.optString("firmware", "?");
                        String ver = data.optString("payloadVersion", "?");
                        tvStatus.setText("✅ متصل! | الإصدار: " + fw + " | البايلود: v" + ver);

                        // Save connection
                        getSharedPreferences("MoLib", MODE_PRIVATE).edit()
                            .putString("host", host)
                            .putInt("port", finalPort)
                            .apply();

                        // Go to main
                        startActivity(new Intent(ConnectActivity.this, MainActivity.class));
                        finish();
                    } catch (Exception e) {
                        showError("خطأ في تحليل البيانات");
                    }
                });
            }
            @Override public void onError(String error) {
                runOnUiThread(() -> showError("❌ فشل الاتصال: " + error));
            }
        });
    }

    private void showError(String msg) {
        tvStatus.setText(msg);
        btnConnect.setEnabled(true);
        progressBar.setVisibility(View.GONE);
    }
}
