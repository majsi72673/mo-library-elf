package com.molibrary.ps5;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import org.json.JSONArray;
import org.json.JSONObject;
import android.view.*;
import androidx.annotation.NonNull;
import java.util.ArrayList;
import java.util.List;

// ── Logs Activity ─────────────────────────────────────────────────────────────
class LogsActivity extends AppCompatActivity {
    private RecyclerView rv;
    private SwipeRefreshLayout swipe;
    private LogAdapter adapter;
    private List<JSONObject> logs = new ArrayList<>();

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_logs);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("السجلات");
        }
        rv    = findViewById(R.id.rv_logs);
        swipe = findViewById(R.id.swipe_refresh);
        Button btnCopy  = findViewById(R.id.btn_copy_logs);
        Button btnClear = findViewById(R.id.btn_clear_logs);

        adapter = new LogAdapter(logs);
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(adapter);

        swipe.setColorSchemeResources(R.color.mo_red);
        swipe.setOnRefreshListener(this::loadLogs);

        if (btnCopy != null) btnCopy.setOnClickListener(v -> copyLogs());
        if (btnClear != null) btnClear.setOnClickListener(v -> {
            ApiClient.getInstance().post("/api/v1/logs/clear", null, null);
            logs.clear(); adapter.notifyDataSetChanged();
        });

        loadLogs();
    }

    private void loadLogs() {
        swipe.setRefreshing(true);
        ApiClient.getInstance().getLogs(new ApiClient.Callback() {
            @Override public void onSuccess(JSONObject d) {
                runOnUiThread(() -> {
                    try {
                        logs.clear();
                        JSONArray arr = d.optJSONArray("logs");
                        if (arr != null)
                            for (int i = 0; i < arr.length(); i++)
                                logs.add(arr.getJSONObject(i));
                        adapter.notifyDataSetChanged();
                        // Scroll to bottom
                        if (!logs.isEmpty())
                            rv.scrollToPosition(logs.size() - 1);
                    } catch (Exception ignored) {}
                    swipe.setRefreshing(false);
                });
            }
            @Override public void onError(String e) {
                runOnUiThread(() -> swipe.setRefreshing(false));
            }
        });
    }

    private void copyLogs() {
        StringBuilder sb = new StringBuilder();
        for (JSONObject log : logs) {
            sb.append("[").append(log.optString("level","?").toUpperCase()).append("] ")
              .append(log.optString("source","?")).append(": ")
              .append(log.optString("message","?")).append("\n");
        }
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("MoLib Logs", sb.toString()));
        Toast.makeText(this, "✅ تم النسخ", Toast.LENGTH_SHORT).show();
    }

    @Override public boolean onSupportNavigateUp() { finish(); return true; }
}

// ── Log Adapter ───────────────────────────────────────────────────────────────
class LogAdapter extends RecyclerView.Adapter<LogAdapter.VH> {
    private final List<JSONObject> items;
    LogAdapter(List<JSONObject> items) { this.items = items; }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup p, int t) {
        return new VH(LayoutInflater.from(p.getContext())
            .inflate(R.layout.item_log, p, false));
    }

    @Override public void onBindViewHolder(@NonNull VH h, int pos) {
        JSONObject log = items.get(pos);
        String level = log.optString("level","info");
        h.tvLevel.setText("[" + level.toUpperCase() + "]");
        h.tvSource.setText(log.optString("source","?"));
        h.tvMessage.setText(log.optString("message",""));

        int color;
        switch (level) {
            case "error": color = 0xFFCC0000; break;
            case "warn":  color = 0xFFFF8800; break;
            default:      color = 0xFF00CC44; break;
        }
        h.tvLevel.setTextColor(color);
    }

    @Override public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvLevel, tvSource, tvMessage;
        VH(View v) {
            super(v);
            tvLevel   = v.findViewById(R.id.tv_log_level);
            tvSource  = v.findViewById(R.id.tv_log_source);
            tvMessage = v.findViewById(R.id.tv_log_message);
        }
    }
}
