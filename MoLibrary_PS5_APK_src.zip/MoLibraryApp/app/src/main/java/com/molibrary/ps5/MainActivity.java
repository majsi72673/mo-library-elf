package com.molibrary.ps5;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    private TextView tvFirmware, tvVersion, tvStatus;
    private TextView tvInternalUsed, tvInternalTotal;
    private TextView tvUsbUsed, tvUsbTotal;
    private TextView tvActiveJobs, tvQueueCount;
    private View dotStatus;
    private Handler refreshHandler = new Handler();
    private boolean running = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvFirmware    = findViewById(R.id.tv_firmware);
        tvVersion     = findViewById(R.id.tv_version);
        tvStatus      = findViewById(R.id.tv_status);
        tvInternalUsed = findViewById(R.id.tv_internal_used);
        tvInternalTotal = findViewById(R.id.tv_internal_total);
        tvUsbUsed     = findViewById(R.id.tv_usb_used);
        tvUsbTotal    = findViewById(R.id.tv_usb_total);
        tvActiveJobs  = findViewById(R.id.tv_active_jobs);
        tvQueueCount  = findViewById(R.id.tv_queue_count);
        dotStatus     = findViewById(R.id.dot_status);

        // Navigation cards
        setupCard(R.id.card_catalog,  CatalogActivity.class);
        setupCard(R.id.card_queue,    QueueActivity.class);
        setupCard(R.id.card_mods,     ModsActivity.class);
        setupCard(R.id.card_pkg,      PkgActivity.class);
        setupCard(R.id.card_logs,     LogsActivity.class);
        setupCard(R.id.card_settings, SettingsActivity.class);

        // WebSocket for live updates
        ApiClient.getInstance().connectWs(new ApiClient.WsListener() {
            @Override public void onEvent(String event, JSONObject data) {
                runOnUiThread(() -> handleWsEvent(event, data));
            }
            @Override public void onConnected() {
                runOnUiThread(() -> dotStatus.setBackgroundResource(R.drawable.dot_green));
            }
            @Override public void onDisconnected() {
                runOnUiThread(() -> dotStatus.setBackgroundResource(R.drawable.dot_red));
            }
        });

        refreshStatus();
        scheduleRefresh();
    }

    private void setupCard(int cardId, Class<?> target) {
        CardView card = findViewById(cardId);
        if (card != null)
            card.setOnClickListener(v -> startActivity(new Intent(this, target)));
    }

    private void refreshStatus() {
        ApiClient.getInstance().getStatus(new ApiClient.Callback() {
            @Override public void onSuccess(JSONObject d) {
                runOnUiThread(() -> updateUI(d));
            }
            @Override public void onError(String e) {
                runOnUiThread(() -> tvStatus.setText("❌ " + e));
            }
        });
    }

    private void updateUI(JSONObject d) {
        try {
            tvFirmware.setText("FW: " + d.optString("firmware", "?"));
            tvVersion.setText("v" + d.optString("payloadVersion", "?"));
            tvStatus.setText(d.optBoolean("serviceRunning") ? "✅ شغّال" : "⚠️ متوقف");
            dotStatus.setBackgroundResource(R.drawable.dot_green);

            long intUsed  = d.optLong("internalUsedBytes");
            long intTotal = d.optLong("internalTotalBytes");
            long usbUsed  = d.optLong("usbUsedBytes");
            long usbTotal = d.optLong("usbTotalBytes");

            tvInternalUsed.setText(formatBytes(intUsed));
            tvInternalTotal.setText(formatBytes(intTotal));
            tvUsbUsed.setText(formatBytes(usbUsed));
            tvUsbTotal.setText(d.optBoolean("usbMounted") ?
                formatBytes(usbTotal) : "غير متصل");

            int queueSize = d.optJSONArray("queue") != null ?
                d.getJSONArray("queue").length() : 0;
            tvQueueCount.setText(String.valueOf(queueSize));

            int active = 0;
            if (d.has("queue")) {
                for (int i = 0; i < d.getJSONArray("queue").length(); i++) {
                    String st = d.getJSONArray("queue").getJSONObject(i).optString("status");
                    if ("downloading".equals(st) || "installing".equals(st)) active++;
                }
            }
            tvActiveJobs.setText(String.valueOf(active));

        } catch (Exception e) { /* ignore */ }
    }

    private void handleWsEvent(String event, JSONObject data) {
        if ("storage".equals(event) || "queue.update".equals(event))
            refreshStatus();
    }

    private void scheduleRefresh() {
        refreshHandler.postDelayed(() -> {
            if (running) {
                refreshStatus();
                scheduleRefresh();
            }
        }, 5000);
    }

    private String formatBytes(long b) {
        if (b < 1024) return b + " B";
        if (b < 1024*1024) return String.format("%.1f KB", b/1024.0);
        if (b < 1024L*1024*1024) return String.format("%.1f MB", b/(1024.0*1024));
        return String.format("%.2f GB", b/(1024.0*1024*1024));
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        running = false;
        refreshHandler.removeCallbacksAndMessages(null);
        ApiClient.getInstance().disconnectWs();
    }
}
