package com.molibrary.ps5;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import org.json.JSONArray;
import org.json.JSONObject;
import android.view.*;
import androidx.annotation.NonNull;
import java.util.ArrayList;
import java.util.List;

public class ModsActivity extends AppCompatActivity {

    private RecyclerView rv;
    private SwipeRefreshLayout swipe;
    private TextView tvEmpty, tvCount;
    private ModAdapter adapter;
    private List<JSONObject> mods = new ArrayList<>();

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_mods);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("المودات");
        }

        rv      = findViewById(R.id.recycler_mods);
        swipe   = findViewById(R.id.swipe_refresh);
        tvEmpty = findViewById(R.id.tv_empty);
        tvCount = findViewById(R.id.tv_count);

        adapter = new ModAdapter(mods, this::onModClick);
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(adapter);

        swipe.setColorSchemeResources(R.color.mo_red);
        swipe.setOnRefreshListener(this::loadMods);

        // Import mod catalog button
        Button btnImport = findViewById(R.id.btn_import_mods);
        if (btnImport != null) {
            btnImport.setOnClickListener(v -> showImportDialog());
        }

        loadMods();
    }

    private void loadMods() {
        swipe.setRefreshing(true);
        ApiClient.getInstance().getMods(new ApiClient.Callback() {
            @Override public void onSuccess(JSONObject d) {
                runOnUiThread(() -> {
                    try {
                        JSONArray arr = d.optJSONArray("mods");
                        mods.clear();
                        if (arr != null)
                            for (int i = 0; i < arr.length(); i++)
                                mods.add(arr.getJSONObject(i));
                        adapter.notifyDataSetChanged();
                        tvCount.setText(mods.size() + " مود");
                        tvEmpty.setVisibility(mods.isEmpty() ? View.VISIBLE : View.GONE);
                    } catch (Exception ignored) {}
                    swipe.setRefreshing(false);
                });
            }
            @Override public void onError(String e) {
                runOnUiThread(() -> {
                    Toast.makeText(ModsActivity.this, "❌ " + e, Toast.LENGTH_SHORT).show();
                    swipe.setRefreshing(false);
                });
            }
        });
    }

    private void onModClick(JSONObject mod) {
        String modId   = mod.optString("id");
        String modName = mod.optString("name");
        String state   = mod.optString("state");

        String[] actions;
        if ("available".equals(state))
            actions = new String[]{"تثبيت"};
        else if ("installed".equals(state) || "disabled".equals(state))
            actions = new String[]{"تفعيل", "حذف"};
        else if ("enabled".equals(state))
            actions = new String[]{"تعطيل", "حذف"};
        else
            actions = new String[]{"تثبيت"};

        new android.app.AlertDialog.Builder(this)
            .setTitle(modName)
            .setMessage("النوع: " + mod.optString("type","?")
                + "\nالحجم: " + formatBytes(mod.optLong("sizeBytes"))
                + "\nالحالة: " + state)
            .setItems(actions, (dialog, which) -> {
                String action = "";
                if ("تثبيت".equals(actions[which]))   action = "install";
                else if ("تفعيل".equals(actions[which]))  action = "enable";
                else if ("تعطيل".equals(actions[which])) action = "disable";
                else if ("حذف".equals(actions[which]))    action = "uninstall";

                final String finalAction = action;
                ApiClient.getInstance().modAction(modId, finalAction,
                    new ApiClient.Callback() {
                        @Override public void onSuccess(JSONObject d) {
                            runOnUiThread(() -> {
                                Toast.makeText(ModsActivity.this,
                                    "✅ تم " + finalAction, Toast.LENGTH_SHORT).show();
                                loadMods();
                            });
                        }
                        @Override public void onError(String e) {
                            runOnUiThread(() ->
                                Toast.makeText(ModsActivity.this,
                                    "❌ " + e, Toast.LENGTH_SHORT).show());
                        }
                    });
            })
            .setNegativeButton("إلغاء", null)
            .show();
    }

    private void showImportDialog() {
        EditText et = new EditText(this);
        et.setHint("رابط JSON للمودات أو مسار الملف");
        et.setPadding(32, 16, 32, 16);

        new android.app.AlertDialog.Builder(this)
            .setTitle("استيراد كتالوج مودات")
            .setView(et)
            .setPositiveButton("استيراد", (d, w) -> {
                String url = et.getText().toString().trim();
                if (!url.isEmpty()) {
                    try {
                        JSONObject p = new JSONObject();
                        p.put("url", url);
                        ApiClient.getInstance().post("/api/v1/mods/import", p,
                            new ApiClient.Callback() {
                                @Override public void onSuccess(JSONObject data) {
                                    runOnUiThread(() -> {
                                        Toast.makeText(ModsActivity.this,
                                            "✅ تم الاستيراد", Toast.LENGTH_SHORT).show();
                                        loadMods();
                                    });
                                }
                                @Override public void onError(String e) {
                                    runOnUiThread(() ->
                                        Toast.makeText(ModsActivity.this,
                                            "❌ " + e, Toast.LENGTH_SHORT).show());
                                }
                            });
                    } catch (Exception ignored) {}
                }
            })
            .setNegativeButton("إلغاء", null)
            .show();
    }

    private String formatBytes(long b) {
        if (b < 1024*1024) return String.format("%.1f KB", b/1024.0);
        if (b < 1024L*1024*1024) return String.format("%.1f MB", b/(1024.0*1024));
        return String.format("%.2f GB", b/(1024.0*1024*1024));
    }

    @Override public boolean onSupportNavigateUp() { finish(); return true; }
}

// ── Mod Adapter ───────────────────────────────────────────────────────────────
class ModAdapter extends RecyclerView.Adapter<ModAdapter.VH> {
    interface OnClick { void onClick(JSONObject mod); }
    private final List<JSONObject> items;
    private final OnClick listener;

    ModAdapter(List<JSONObject> items, OnClick l) { this.items=items; this.listener=l; }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup p, int t) {
        return new VH(LayoutInflater.from(p.getContext())
            .inflate(R.layout.item_mod, p, false));
    }

    @Override public void onBindViewHolder(@NonNull VH h, int pos) {
        JSONObject m = items.get(pos);
        h.tvName.setText(m.optString("name","?"));
        h.tvAuthor.setText(m.optString("author","?"));
        h.tvType.setText(m.optString("type","?").toUpperCase());
        String state = m.optString("state","?");
        h.tvState.setText(state);
        int color;
        switch(state) {
            case "enabled":   color = 0xFF00CC44; break;
            case "installed": color = 0xFF0088FF; break;
            case "disabled":  color = 0xFF888888; break;
            default:          color = 0xFFCCCCCC; break;
        }
        h.tvState.setTextColor(color);
        h.itemView.setOnClickListener(v -> listener.onClick(m));
    }

    @Override public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvName, tvAuthor, tvType, tvState;
        VH(View v) {
            super(v);
            tvName   = v.findViewById(R.id.tv_mod_name);
            tvAuthor = v.findViewById(R.id.tv_mod_author);
            tvType   = v.findViewById(R.id.tv_mod_type);
            tvState  = v.findViewById(R.id.tv_mod_state);
        }
    }
}
