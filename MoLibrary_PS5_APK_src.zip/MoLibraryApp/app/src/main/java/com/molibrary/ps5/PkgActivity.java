package com.molibrary.ps5;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import org.json.JSONArray;
import org.json.JSONObject;
import android.view.*;
import androidx.annotation.NonNull;
import java.util.ArrayList;
import java.util.List;

public class PkgActivity extends AppCompatActivity {

    private EditText etPkgUrl;
    private Spinner spinnerDest;
    private Button btnInstallUrl, btnScanUsb;
    private RecyclerView rvJobs, rvScan;
    private TextView tvJobsTitle, tvScanTitle;
    private PkgJobAdapter jobAdapter;
    private PkgScanAdapter scanAdapter;
    private List<JSONObject> jobs = new ArrayList<>();
    private List<JSONObject> scanResults = new ArrayList<>();

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_pkg);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("تثبيت PKG");
        }

        etPkgUrl     = findViewById(R.id.et_pkg_url);
        spinnerDest  = findViewById(R.id.spinner_dest);
        btnInstallUrl = findViewById(R.id.btn_install_url);
        btnScanUsb   = findViewById(R.id.btn_scan_usb);
        rvJobs       = findViewById(R.id.rv_pkg_jobs);
        rvScan       = findViewById(R.id.rv_pkg_scan);
        tvJobsTitle  = findViewById(R.id.tv_jobs_title);
        tvScanTitle  = findViewById(R.id.tv_scan_title);

        // Destination spinner
        String[] dests = {"/data (داخلي)", "/mnt", "/mnt/usb0 (USB)"};
        spinnerDest.setAdapter(new ArrayAdapter<>(this,
            android.R.layout.simple_spinner_dropdown_item, dests));

        // Jobs recycler
        jobAdapter = new PkgJobAdapter(jobs);
        rvJobs.setLayoutManager(new LinearLayoutManager(this));
        rvJobs.setAdapter(jobAdapter);

        // Scan recycler
        scanAdapter = new PkgScanAdapter(scanResults, this::installScannedPkg);
        rvScan.setLayoutManager(new LinearLayoutManager(this));
        rvScan.setAdapter(scanAdapter);

        btnInstallUrl.setOnClickListener(v -> installFromUrl());
        btnScanUsb.setOnClickListener(v -> scanUsb());

        loadJobs();
    }

    private String getSelectedDest() {
        switch (spinnerDest.getSelectedItemPosition()) {
            case 1: return "/mnt";
            case 2: return "/mnt/usb0";
            default: return "/data";
        }
    }

    private void installFromUrl() {
        String url = etPkgUrl.getText().toString().trim();
        if (url.isEmpty()) {
            etPkgUrl.setError("أدخل رابط PKG");
            return;
        }

        String dest = getSelectedDest();
        btnInstallUrl.setEnabled(false);

        ApiClient.getInstance().installPkgUrl(url, dest, new ApiClient.Callback() {
            @Override public void onSuccess(JSONObject d) {
                runOnUiThread(() -> {
                    Toast.makeText(PkgActivity.this,
                        "✅ أُضيف للتثبيت", Toast.LENGTH_SHORT).show();
                    etPkgUrl.setText("");
                    btnInstallUrl.setEnabled(true);
                    loadJobs();
                });
            }
            @Override public void onError(String e) {
                runOnUiThread(() -> {
                    Toast.makeText(PkgActivity.this, "❌ " + e, Toast.LENGTH_SHORT).show();
                    btnInstallUrl.setEnabled(true);
                });
            }
        });
    }

    private void scanUsb() {
        btnScanUsb.setEnabled(false);
        btnScanUsb.setText("جاري الفحص...");

        ApiClient.getInstance().getPkgScan(new ApiClient.Callback() {
            @Override public void onSuccess(JSONObject d) {
                runOnUiThread(() -> {
                    try {
                        scanResults.clear();
                        JSONArray usb  = d.optJSONArray("usb");
                        JSONArray data = d.optJSONArray("internal");

                        if (usb != null)
                            for (int i = 0; i < usb.length(); i++)
                                scanResults.add(usb.getJSONObject(i));
                        if (data != null)
                            for (int i = 0; i < data.length(); i++)
                                scanResults.add(data.getJSONObject(i));

                        scanAdapter.notifyDataSetChanged();
                        tvScanTitle.setText("نتائج الفحص (" + scanResults.size() + ")");
                        tvScanTitle.setVisibility(View.VISIBLE);
                        rvScan.setVisibility(scanResults.isEmpty() ? View.GONE : View.VISIBLE);

                        if (scanResults.isEmpty())
                            Toast.makeText(PkgActivity.this,
                                "لم يُعثر على ملفات PKG", Toast.LENGTH_SHORT).show();
                    } catch (Exception ignored) {}
                    btnScanUsb.setEnabled(true);
                    btnScanUsb.setText("فحص USB");
                });
            }
            @Override public void onError(String e) {
                runOnUiThread(() -> {
                    Toast.makeText(PkgActivity.this, "❌ " + e, Toast.LENGTH_SHORT).show();
                    btnScanUsb.setEnabled(true);
                    btnScanUsb.setText("فحص USB");
                });
            }
        });
    }

    private void installScannedPkg(JSONObject pkg) {
        String path  = pkg.optString("path");
        String title = pkg.optString("title", "PKG");
        String dest  = getSelectedDest();

        new android.app.AlertDialog.Builder(this)
            .setTitle("تثبيت " + title)
            .setMessage("المسار: " + path + "\nالوجهة: " + dest)
            .setPositiveButton("تثبيت", (d, w) ->
                ApiClient.getInstance().installPkgLocal(path, dest,
                    new ApiClient.Callback() {
                        @Override public void onSuccess(JSONObject data) {
                            runOnUiThread(() -> {
                                Toast.makeText(PkgActivity.this,
                                    "✅ أُضيف للتثبيت", Toast.LENGTH_SHORT).show();
                                loadJobs();
                            });
                        }
                        @Override public void onError(String e) {
                            runOnUiThread(() ->
                                Toast.makeText(PkgActivity.this,
                                    "❌ " + e, Toast.LENGTH_SHORT).show());
                        }
                    }))
            .setNegativeButton("إلغاء", null)
            .show();
    }

    private void loadJobs() {
        ApiClient.getInstance().getPkgJobs(new ApiClient.Callback() {
            @Override public void onSuccess(JSONObject d) {
                runOnUiThread(() -> {
                    try {
                        jobs.clear();
                        JSONArray arr = d.optJSONArray("jobs");
                        if (arr != null)
                            for (int i = 0; i < arr.length(); i++)
                                jobs.add(arr.getJSONObject(i));
                        jobAdapter.notifyDataSetChanged();
                        tvJobsTitle.setText("عمليات التثبيت (" + jobs.size() + ")");
                        rvJobs.setVisibility(jobs.isEmpty() ? View.GONE : View.VISIBLE);
                    } catch (Exception ignored) {}
                });
            }
            @Override public void onError(String e) {}
        });
    }

    @Override public boolean onSupportNavigateUp() { finish(); return true; }
}

// ── PKG Job Adapter ───────────────────────────────────────────────────────────
class PkgJobAdapter extends RecyclerView.Adapter<PkgJobAdapter.VH> {
    private final List<JSONObject> items;
    PkgJobAdapter(List<JSONObject> items) { this.items = items; }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup p, int t) {
        return new VH(LayoutInflater.from(p.getContext())
            .inflate(R.layout.item_pkg_job, p, false));
    }

    @Override public void onBindViewHolder(@NonNull VH h, int pos) {
        JSONObject j = items.get(pos);
        h.tvTitle.setText(j.optString("title", j.optString("titleId","?")));
        h.tvType.setText(j.optString("type","?"));
        h.tvState.setText(j.optString("state","?"));
        int prog = (int)(j.optDouble("progress",0)*100);
        h.progress.setProgress(prog);
        h.tvProgress.setText(prog + "%");

        h.btnCancel.setOnClickListener(v -> {
            String id = j.optString("id","");
            ApiClient.getInstance().post("/api/v1/pkg/"+id+"/cancel", null, null);
        });

        String state = j.optString("state","");
        h.btnCancel.setVisibility(
            "done".equals(state)||"failed".equals(state) ? View.GONE : View.VISIBLE);
    }

    @Override public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvTitle, tvType, tvState, tvProgress;
        ProgressBar progress;
        Button btnCancel;
        VH(View v) {
            super(v);
            tvTitle   = v.findViewById(R.id.tv_pkg_title);
            tvType    = v.findViewById(R.id.tv_pkg_type);
            tvState   = v.findViewById(R.id.tv_pkg_state);
            tvProgress= v.findViewById(R.id.tv_pkg_progress);
            progress  = v.findViewById(R.id.progress_pkg);
            btnCancel = v.findViewById(R.id.btn_pkg_cancel);
        }
    }
}

// ── PKG Scan Adapter ─────────────────────────────────────────────────────────
class PkgScanAdapter extends RecyclerView.Adapter<PkgScanAdapter.VH> {
    interface OnInstall { void onInstall(JSONObject pkg); }
    private final List<JSONObject> items;
    private final OnInstall listener;
    PkgScanAdapter(List<JSONObject> items, OnInstall l) { this.items=items; this.listener=l; }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup p, int t) {
        return new VH(LayoutInflater.from(p.getContext())
            .inflate(R.layout.item_pkg_scan, p, false));
    }

    @Override public void onBindViewHolder(@NonNull VH h, int pos) {
        JSONObject pkg = items.get(pos);
        h.tvTitle.setText(pkg.optString("title","PKG"));
        h.tvType.setText(pkg.optString("type","?") +
            (pkg.optBoolean("isFake") ? " [Fake]" : ""));
        long sz = pkg.optLong("pkgSize");
        h.tvSize.setText(sz > 0 ?
            String.format("%.2f GB", sz/(1024.0*1024*1024)) : "?");
        h.btnInstall.setOnClickListener(v -> listener.onInstall(pkg));
    }

    @Override public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvTitle, tvType, tvSize;
        Button btnInstall;
        VH(View v) {
            super(v);
            tvTitle    = v.findViewById(R.id.tv_scan_title);
            tvType     = v.findViewById(R.id.tv_scan_type);
            tvSize     = v.findViewById(R.id.tv_scan_size);
            btnInstall = v.findViewById(R.id.btn_scan_install);
        }
    }
}
