package com.molibrary.ps5;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import org.json.JSONArray;
import org.json.JSONObject;
import android.view.*;
import androidx.annotation.NonNull;
import java.util.ArrayList;
import java.util.List;

// ── Queue Activity ────────────────────────────────────────────────────────────
class QueueActivity extends AppCompatActivity {
    private RecyclerView rv;
    private TextView tvEmpty;
    private Handler h = new Handler();
    private boolean running = true;
    private QueueAdapter adapter;
    private List<JSONObject> jobs = new ArrayList<>();

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_queue);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("قائمة التحميل");
        }
        rv = findViewById(R.id.recycler_queue);
        tvEmpty = findViewById(R.id.tv_empty);
        adapter = new QueueAdapter(jobs);
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(adapter);

        Button btnPauseAll = findViewById(R.id.btn_pause_all);
        Button btnCancelAll = findViewById(R.id.btn_cancel_all);
        Button btnClearDone = findViewById(R.id.btn_clear_done);

        if (btnPauseAll != null) btnPauseAll.setOnClickListener(v ->
            ApiClient.getInstance().post("/api/v1/service/stop", null, null));
        if (btnCancelAll != null) btnCancelAll.setOnClickListener(v ->
            Toast.makeText(this, "إلغاء الكل...", Toast.LENGTH_SHORT).show());
        if (btnClearDone != null) btnClearDone.setOnClickListener(v -> loadQueue());

        loadQueue();
        h.postDelayed(this::autoRefresh, 2000);
    }

    private void autoRefresh() {
        if (running) { loadQueue(); h.postDelayed(this::autoRefresh, 2000); }
    }

    private void loadQueue() {
        ApiClient.getInstance().getStatus(new ApiClient.Callback() {
            @Override public void onSuccess(JSONObject d) {
                runOnUiThread(() -> {
                    try {
                        jobs.clear();
                        JSONArray arr = d.optJSONArray("queue");
                        if (arr != null)
                            for (int i = 0; i < arr.length(); i++)
                                jobs.add(arr.getJSONObject(i));
                        adapter.notifyDataSetChanged();
                        tvEmpty.setVisibility(jobs.isEmpty() ? View.VISIBLE : View.GONE);
                        rv.setVisibility(jobs.isEmpty() ? View.GONE : View.VISIBLE);
                    } catch (Exception ignored) {}
                });
            }
            @Override public void onError(String e) {}
        });
    }

    @Override protected void onDestroy() { super.onDestroy(); running = false; }
    @Override public boolean onSupportNavigateUp() { finish(); return true; }
}

// ── Queue Adapter ─────────────────────────────────────────────────────────────
class QueueAdapter extends RecyclerView.Adapter<QueueAdapter.VH> {
    private final List<JSONObject> items;
    QueueAdapter(List<JSONObject> items) { this.items = items; }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup p, int t) {
        return new VH(LayoutInflater.from(p.getContext())
            .inflate(R.layout.item_job, p, false));
    }

    @Override public void onBindViewHolder(@NonNull VH h, int pos) {
        JSONObject j = items.get(pos);
        h.tvId.setText(j.optString("titleId","?"));
        h.tvStatus.setText(j.optString("status","?"));
        int prog = (int)(j.optDouble("progress", 0) * 100);
        h.progressBar.setProgress(prog);
        h.tvProgress.setText(prog + "%");
        h.tvSpeed.setText(formatSpeed(j.optLong("speedBps")));

        String status = j.optString("status","");
        String jobId  = j.optString("id","");

        h.btnPause.setOnClickListener(v ->
            ApiClient.getInstance().jobAction(jobId, "pause", null));
        h.btnResume.setOnClickListener(v ->
            ApiClient.getInstance().jobAction(jobId, "resume", null));
        h.btnCancel.setOnClickListener(v ->
            ApiClient.getInstance().jobAction(jobId, "cancel", null));

        h.btnPause.setVisibility("downloading".equals(status) ? View.VISIBLE : View.GONE);
        h.btnResume.setVisibility("paused".equals(status) ? View.VISIBLE : View.GONE);
        h.btnCancel.setVisibility(
            ("queued".equals(status)||"downloading".equals(status)||"paused".equals(status))
            ? View.VISIBLE : View.GONE);
    }

    private String formatSpeed(long bps) {
        if (bps == 0) return "";
        if (bps < 1024*1024) return String.format("%.0f KB/s", bps/1024.0);
        return String.format("%.1f MB/s", bps/(1024.0*1024));
    }

    @Override public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvId, tvStatus, tvProgress, tvSpeed;
        ProgressBar progressBar;
        Button btnPause, btnResume, btnCancel;
        VH(View v) {
            super(v);
            tvId        = v.findViewById(R.id.tv_job_id);
            tvStatus    = v.findViewById(R.id.tv_job_status);
            tvProgress  = v.findViewById(R.id.tv_job_progress);
            tvSpeed     = v.findViewById(R.id.tv_job_speed);
            progressBar = v.findViewById(R.id.progress_job);
            btnPause    = v.findViewById(R.id.btn_pause);
            btnResume   = v.findViewById(R.id.btn_resume);
            btnCancel   = v.findViewById(R.id.btn_cancel);
        }
    }
}
