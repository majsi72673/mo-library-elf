package com.molibrary.ps5;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_settings);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("الإعدادات");
        }
        SharedPreferences prefs = getSharedPreferences("MoLib", MODE_PRIVATE);
        TextView tvCurrentServer = findViewById(R.id.tv_current_server);
        EditText etPassword      = findViewById(R.id.et_password);
        Button btnDisconnect     = findViewById(R.id.btn_disconnect);
        Button btnSave           = findViewById(R.id.btn_save_settings);
        TextView tvAbout         = findViewById(R.id.tv_about);
        String host = prefs.getString("host","");
        int port    = prefs.getInt("port", 8855);
        if (tvCurrentServer != null)
            tvCurrentServer.setText("الخادم: " + host + ":" + port);
        if (tvAbout != null)
            tvAbout.setText("MO Library PS5\nالإصدار 1.0.2\nبروتوكول: 1.0\nPort: 8855");
        if (btnDisconnect != null)
            btnDisconnect.setOnClickListener(v -> {
                prefs.edit().remove("host").remove("port").apply();
                startActivity(new Intent(SettingsActivity.this, ConnectActivity.class)
                    .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
            });
        if (btnSave != null)
            btnSave.setOnClickListener(v ->
                Toast.makeText(this, "✅ تم الحفظ", Toast.LENGTH_SHORT).show());
    }
    @Override public boolean onSupportNavigateUp() { finish(); return true; }
}
