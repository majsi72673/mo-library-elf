package com.molibrary.ps5;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        new Handler().postDelayed(() -> {
            SharedPreferences prefs = getSharedPreferences("MoLib", MODE_PRIVATE);
            String savedHost = prefs.getString("host", "");

            Intent intent;
            if (!savedHost.isEmpty()) {
                // Auto-connect to last server
                ApiClient.getInstance().setServer(
                    savedHost,
                    prefs.getInt("port", 8855)
                );
                intent = new Intent(this, MainActivity.class);
            } else {
                intent = new Intent(this, ConnectActivity.class);
            }
            startActivity(intent);
            finish();
        }, 1500);
    }
}
