# Building mo_library.elf

## Prerequisites

| Tool | Version | Notes |
|------|---------|-------|
| `clang` + `lld` | ≥ 15 | Cross-compiles for x86\_64-unknown-freebsd |
| `ps5-payload-sdk` | latest | [github.com/john-tornblom/ps5-payload-sdk](https://github.com/john-tornblom/ps5-payload-sdk) |
| `curl` | any | Downloads vendored libraries |
| `make` | GNU ≥ 4.2 | |
| `python3` (optional) | ≥ 3.9 | Only needed for SDK build scripts |

Tested on: Ubuntu 22.04 / Debian 12 / macOS 13+

---

## 1 — Install Clang / LLD

**Ubuntu / Debian:**
```bash
sudo apt update
sudo apt install -y clang lld llvm
```

**macOS (Homebrew):**
```bash
brew install llvm
export PATH="$(brew --prefix llvm)/bin:$PATH"
```

---

## 2 — Clone and Build the PS5 Payload SDK

```bash
git clone https://github.com/john-tornblom/ps5-payload-sdk.git ~/ps5-payload-sdk
cd ~/ps5-payload-sdk
make            # builds the FreeBSD sysroot and helper scripts
```

The SDK will be at `~/ps5-payload-sdk`. Override with:
```bash
export PS5_PAYLOAD_SDK=/your/custom/path
```

---

## 3 — Clone this project

```bash
git clone https://github.com/yourhandle/mo_library_elf.git
cd mo_library_elf
```

---

## 4 — Vendor third-party libraries

```bash
make vendor
```

This downloads:
- `third_party/cjson/cJSON.{h,c}` — cJSON v1.7.17 (MIT)
- `third_party/miniz/miniz.{h,c}` — miniz 3.0.2 (MIT / Unlicense)

Both are self-contained single-file libraries. No `cmake`, no configure.

---

## 5 — Build

```bash
make            # produces payload.elf
make strip      # strips debug symbols (~30% smaller)
```

Build output:
```
[CC] src/main.c
[CC] src/util/mo_types.c
[CC] src/util/mo_log.c
[CC] src/catalog/catalog.c
[CC] src/catalog/builtin_titles.c
[CC] src/dns/dns_server.c
[CC] src/archive/archive_engine.c
[CC] src/http/download_manager.c
[CC] src/http/http_server.c
[CC] third_party/cjson/cJSON.c
[CC] third_party/miniz/miniz.c
[LD] payload.elf
[OK] payload.elf built
```

---

## 6 — Deploy to PS5

1. Copy `payload.elf` to your payload loader (GoldHEN, kstuff, etc.)
2. The payload starts automatically and binds on port **8855**
3. Open the PS5 browser and navigate to `http://<ps5-ip>:8855/`

### DNS Sinkhole setup

The embedded DNS server needs to bind port 53. Either:

**Option A — Run as root inside the payload (recommended):**
The PS5 kernel exploit typically grants elevated privileges.

**Option B — Port redirect (if port 53 is restricted):**
```sh
# On FreeBSD/PS5, redirect port 53 → 5353 via pf(4):
echo 'rdr pass on lo0 proto udp from any to any port 53 -> 127.0.0.1 port 5353' \
  | pfctl -f -
```
Then set `dns_cfg.listen_port = 5353` in `main.c`.

**Configure the PS5 network DNS manually:**
Set the PS5's DNS server to `127.0.0.1` (itself) so queries hit the sinkhole.

---

## 7 — Adding external game catalogs

Drop a `mo_library.json` on a USB drive:
```
/mnt/usb0/mo_library.json
```
The payload loads it automatically on startup. Schema:

```json
{
  "schemaVersion": "1.0",
  "library": {
    "id": "my-collection",
    "name": "My Collection",
    "author": "owner",
    "updatedAt": "2026-08-30T00:00:00Z"
  },
  "titles": [
    {
      "id": "CUSA-XX-00001",
      "title": "Example Game",
      "region": "US",
      "requiredFirmware": "10.01",
      "category": "game",
      "description": "A great game.",
      "publisher": "Studio",
      "releaseYear": 2025,
      "variants": [
        {
          "format": "FPKG",
          "sizeBytes": 48318382080,
          "version": "1.00",
          "url": "http://192.168.1.100/games/example.fpkg",
          "compressed": false
        }
      ],
      "dlcs": [],
      "updates": [],
      "backports": []
    }
  ]
}
```

Or POST it live:
```bash
curl -X POST http://<ps5-ip>:8855/api/v1/catalog/import \
     -H "Content-Type: application/json" \
     -d @my_catalog.json
```

---

## 8 — Manual archive extraction

```bash
# Extract a downloaded archive from the REST API:
curl -X POST http://<ps5-ip>:8855/api/v1/queue \
     -H "Content-Type: application/json" \
     -d '{"titleId":"CUSA-MO-00001","variantId":"CUSA-MO-00001-zip","destPath":"/data"}'
```

The payload automatically:
1. Downloads the `.zip`
2. Decompresses to `/data`
3. Installs via DPIv2

For **auto-extract mode**, drop archives into `/data/tmp/` — the background monitor
extracts any file that has been stable for > 5 seconds.

---

## REST API Quick Reference

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/v1/status` | Service status, storage, queue |
| `GET` | `/api/v1/catalog` | Full merged catalog JSON |
| `POST` | `/api/v1/catalog/import` | Import library JSON body |
| `POST` | `/api/v1/catalog/refresh` | Re-fetch remote URL libraries |
| `POST` | `/api/v1/queue` | Enqueue `{titleId, variantId, destPath}` |
| `POST` | `/api/v1/queue/:id/pause` | Pause job |
| `POST` | `/api/v1/queue/:id/resume` | Resume job |
| `POST` | `/api/v1/queue/:id/cancel` | Cancel job |
| `POST` | `/api/v1/queue/:id/priority` | Set `{priority: 0-9}` |
| `GET` | `/api/v1/logs` | Structured log ring buffer |
| `POST` | `/api/v1/service/stop` | Pause all downloads |
| `POST` | `/api/v1/service/start` | Resume service |
| `GET` | `/ws` | WebSocket: live events |

---

## WebSocket Events

Connect to `ws://<ps5-ip>:8855/ws`

```json
// On connect:
{"event":"hello","protocol":"1.0","port":8855,"payloadVersion":"1.0.1-elf","firmware":"10.01"}

// Download progress (every 500 ms):
{"event":"queue.update","job":{"id":"job-abc","status":"downloading","progress":0.42,"speedBps":45088000,"stage":1}}

// Storage update (every 2 s):
{"event":"storage","internalUsed":214748364800,"internalTotal":885654700032,"usbMounted":false}
```

---

## Bug Fixes vs. Original Web App

| # | Location | Bug | Fix |
|---|----------|-----|-----|
| 1 | `store.ts tick()` | Storage delta applied inside per-job loop — rapid completions could apply it multiple times, causing negative free space | Applied once per tick under lock after all jobs iterate |
| 2 | `store.ts uninstall()` | `Math.max(40*GB, used-size)` — arbitrary 40 GB floor prevented counter from reaching 0 | `Math.max(0, used-size)` |
| 3 | `store.ts pauseJob()` | Allowed pause during `stage==3` (installing), which could corrupt DPIv2 install state | Reject pause when `status == JOB_INSTALLING` |
| 4 | `store.ts resumeJob()` | Called without checking `serviceRunning`, restarting downloads when service was stopped | Check `dl_manager.running` before resuming |
| 5 | `schema.ts` | `expandRatio` defaulted to `1` for compressed formats when omitted | Default is `2.0` for compressed, `1.0` otherwise |
| 6 | `utils.ts demoTotp()` | Single-window TOTP — vulnerable to timing attacks and clock skew | Constant-time comparison; ±1 window drift tolerance |
| 7 | `auth login()` | `password !== adminPassword` — string equality is vulnerable to timing oracle | Byte-by-byte constant-time compare (`strcmp` replacement) |

---

## Project Layout

```
mo_library_elf/
├── Makefile
├── BUILD.md
├── include/
│   ├── mo_types.h          ← Core enums, structs, constants
│   ├── mo_log.h            ← Logger + TOTP + Auth
│   ├── catalog.h           ← Game library manager
│   ├── builtin_titles.h    ← Built-in catalog accessor
│   ├── dns_server.h        ← DNS sinkhole
│   ├── archive_engine.h    ← ZIP/7z extraction engine
│   ├── download_manager.h  ← 3-stage download queue
│   └── http_server.h       ← HTTP/1.1 + WebSocket
├── src/
│   ├── main.c              ← Entry point, boot sequence
│   ├── util/
│   │   ├── mo_types.c
│   │   └── mo_log.c
│   ├── catalog/
│   │   ├── catalog.c
│   │   └── builtin_titles.c
│   ├── dns/
│   │   └── dns_server.c
│   ├── archive/
│   │   └── archive_engine.c
│   └── http/
│       ├── download_manager.c
│       └── http_server.c
└── third_party/
    ├── cjson/
    │   ├── cJSON.h         ← run `make vendor`
    │   └── cJSON.c
    └── miniz/
        ├── miniz.h         ← run `make vendor`
        └── miniz.c
```
