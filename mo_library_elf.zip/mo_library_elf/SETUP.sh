#!/bin/bash
# ============================================================
# mo_library.elf v1.0.2 — Auto Setup
# Catalog + Downloads + Mods + PKG Installer + DNS Sinkhole
# Run: bash SETUP.sh
# ============================================================
set -e
cd "$(dirname "$0")"

echo "================================================"
echo " mo_library.elf v1.0.2 — Building..."
echo "================================================"

sudo apt-get install -y -qq gcc libz-dev 2>/dev/null || true

gcc -std=c11 -Wno-format-truncation -Wno-implicit-function-declaration \
  -Iinclude -Ithird_party/cjson -Ithird_party/miniz \
  -D_GNU_SOURCE \
  src/main.c \
  src/util/mo_types.c \
  src/util/mo_log.c \
  src/util/fs_util.c \
  src/catalog/catalog.c \
  src/catalog/builtin_titles.c \
  src/dns/dns_server.c \
  src/archive/archive_engine.c \
  src/http/download_manager.c \
  src/http/http_server.c \
  src/mods/mod_manager.c \
  src/pkg/pkg_installer.c \
  third_party/cjson/cJSON.c \
  third_party/miniz/miniz.c \
  -lpthread -lm -lz \
  -o payload_test

echo "Build OK ✅"

pkill payload_test 2>/dev/null || true
sleep 1
./payload_test &
sleep 4

STATUS=$(curl -s --max-time 5 http://localhost:8855/api/v1/status)
MODS=$(curl -s --max-time 5 http://localhost:8855/api/v1/mods)
PKGJOBS=$(curl -s --max-time 5 http://localhost:8855/api/v1/pkg/jobs)

echo ""
echo "================================================"
echo " ALL SYSTEMS ONLINE ✅"
echo ""
echo " ENDPOINTS:"
echo "   Status   : http://localhost:8855/api/v1/status"
echo "   Catalog  : http://localhost:8855/api/v1/catalog"
echo "   Logs     : http://localhost:8855/api/v1/logs"
echo "   Mods     : http://localhost:8855/api/v1/mods"
echo "   Mod/Title: http://localhost:8855/api/v1/mods/title/<titleId>"
echo "   PKG Jobs : http://localhost:8855/api/v1/pkg/jobs"
echo "   PKG Scan : http://localhost:8855/api/v1/pkg/scan"
echo "   WebSocket: ws://localhost:8855/ws"
echo ""
echo " INSTALL PKG FROM URL:"
echo "   curl -X POST http://localhost:8855/api/v1/pkg/install \\"
echo "        -H 'Content-Type: application/json' \\"
echo "        -d '{\"url\":\"http://server/game.pkg\",\"dest\":\"/data\"}'"
echo ""
echo " INSTALL PKG FROM USB:"
echo "   curl -X POST http://localhost:8855/api/v1/pkg/install \\"
echo "        -H 'Content-Type: application/json' \\"
echo "        -d '{\"path\":\"/mnt/usb0/game.pkg\",\"dest\":\"/data\"}'"
echo ""
echo " INSTALL MOD:"
echo "   curl -X POST http://localhost:8855/api/v1/mods/<mod_id>/install"
echo ""
echo " IMPORT MOD CATALOG:"
echo "   curl -X POST http://localhost:8855/api/v1/mods/import \\"
echo "        -H 'Content-Type: application/json' \\"
echo "        -d @/mnt/usb0/mo_mods.json"
echo "================================================"
echo ""
echo "Press Ctrl+C to stop."
wait
