#pragma once
/*
 * archive_engine.h — Zip/7z/RAR decompression for PS5 payload
 *
 * Two modes:
 *   MANUAL   — caller picks archive, calls archive_extract_sync()
 *   AUTO     — background monitor thread detects completed downloads
 *               and extracts + optionally deletes the archive
 */

#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>

/* ── Supported archive formats ─────────────────────────────────────────────── */
typedef enum {
    ARCH_ZIP = 0,
    ARCH_7Z,
    ARCH_RAR,
    ARCH_UNKNOWN
} mo_arch_format_t;

mo_arch_format_t arch_detect_format(const char *path);

/* ── Progress callback ─────────────────────────────────────────────────────── */
typedef void (*arch_progress_cb)(const char *entry_name,
                                  uint64_t    bytes_done,
                                  uint64_t    bytes_total,
                                  void       *userdata);

/* ── Synchronous (manual) extraction ──────────────────────────────────────── */

typedef struct {
    char      src_path[1024];   /* path to archive */
    char      dst_path[1024];   /* destination directory */
    bool      delete_after;     /* delete archive when done */
    bool      overwrite;        /* overwrite existing files */
    arch_progress_cb cb;
    void     *cb_userdata;
} mo_arch_options_t;

typedef struct {
    bool     success;
    int      files_extracted;
    uint64_t bytes_extracted;
    char     error[256];
} mo_arch_result_t;

/*
 * Synchronously extract archive.
 * Blocks until complete or error. Thread-safe (uses its own file handles).
 */
mo_arch_result_t archive_extract_sync(const mo_arch_options_t *opts);

/* ── Automatic extraction monitor ─────────────────────────────────────────── */

typedef struct {
    char    watch_dir[1024];    /* directory to watch for finished archives  */
    char    dest_dir[1024];     /* where to extract (relative or absolute)   */
    bool    delete_after;       /* delete archive after successful extraction */
    bool    overwrite;
    int     poll_interval_ms;   /* how often to scan watch_dir (default 2000)*/
} mo_arch_monitor_cfg_t;

/*
 * Start background monitor thread.
 * The monitor scans watch_dir for .zip / .7z / .rar files and extracts
 * any that have not been modified in > 5 s (i.e. download complete).
 *
 * Returns true if thread started.
 */
bool archive_monitor_start(const mo_arch_monitor_cfg_t *cfg);

/* Stop the monitor thread and wait for it */
void archive_monitor_stop(void);

bool archive_monitor_running(void);

/* ── Utility ───────────────────────────────────────────────────────────────── */

/* Estimate uncompressed size without full extraction (ZIP central directory) */
uint64_t archive_estimate_size(const char *path);
