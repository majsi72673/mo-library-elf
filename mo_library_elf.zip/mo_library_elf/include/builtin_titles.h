#pragma once
/*
 * builtin_titles.h — Static built-in game catalog
 * Translated from: src/lib/catalog.ts  BUILTIN_TITLES[]
 *
 * Accessed via:
 *   int             mo_builtin_title_count(void);
 *   const mo_title_t *mo_builtin_title(int index);
 */
#include "mo_types.h"

int               mo_builtin_title_count(void);
const mo_title_t *mo_builtin_title(int index);
