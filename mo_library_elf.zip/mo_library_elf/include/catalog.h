#pragma once
/*
 * catalog.h — Game library catalog: load, parse, merge, query
 * Combines logic from: catalog.ts, schema.ts, store.ts (catalog slice)
 */

#include "mo_types.h"
#include <stdbool.h>

/* ── Catalog database ─────────────────────────────────────────────────────── */

typedef struct mo_catalog mo_catalog_t;

mo_catalog_t *catalog_new(void);
void          catalog_free(mo_catalog_t *cat);

/* Load the built-in title list compiled into the binary */
void          catalog_load_builtin(mo_catalog_t *cat);

/*
 * Import a library from a JSON string.
 * Returns: library id string (static per-call buffer) or NULL on parse error.
 * 'name_hint' overrides the library name from JSON (may be NULL).
 */
const char   *catalog_import_json(mo_catalog_t *cat,
                                   const char   *json_text,
                                   size_t        json_len,
                                   const char   *name_hint);

/*
 * Load a JSON library file from a local path (USB / internal storage).
 * Returns true on success.
 */
bool          catalog_load_file(mo_catalog_t *cat,
                                 const char   *path,
                                 const char   *name_hint);

/*
 * Fetch and import a remote JSON library via HTTP GET.
 * Blocking. Returns true on success.
 */
bool          catalog_fetch_url(mo_catalog_t *cat,
                                 const char   *url,
                                 const char   *name_hint);

/* Remove a library and all its titles (cannot remove MO_MAIN_LIBRARY_ID) */
bool          catalog_remove_library(mo_catalog_t *cat, const char *lib_id);

/* Enable / disable a library (builtin always enabled) */
bool          catalog_toggle_library(mo_catalog_t *cat, const char *lib_id);

/* ── Query API ────────────────────────────────────────────────────────────── */

/* Returns pointer into internal array — valid until next catalog mutation */
const mo_title_t   *catalog_find_title(const mo_catalog_t *cat, const char *id);
const mo_variant_t *catalog_find_variant(const mo_catalog_t *cat,
                                          const char *title_id,
                                          const char *variant_id);

/*
 * Filter/sort titles into caller-supplied array.
 * Returns number of titles written (≤ max_out).
 *
 * Filters (pass NULL / 0 / "all" to skip):
 *   query        — case-insensitive substring in title / publisher / id
 *   category     — CAT_UNKNOWN = all
 *   region       — REGION_UNKNOWN = all
 *   format       — FMT_UNKNOWN = all
 *   firmware     — NULL/"all" = all, else exact match
 *   library_id   — NULL/"all" = all enabled libraries
 *   only_compressed — true = only compressed variants
 */
typedef struct {
    const char   *query;
    mo_category_t category;
    mo_region_t   region;
    mo_format_t   format;
    const char   *firmware;
    const char   *library_id;
    bool          only_compressed;
    enum { SORT_RECENT=0, SORT_NAME, SORT_SIZE, SORT_FIRMWARE } sort;
} mo_filter_t;

int catalog_filter(const mo_catalog_t *cat,
                    const mo_filter_t  *f,
                    const mo_title_t  **out,
                    int                 max_out);

/* Total titles across all enabled libraries */
int catalog_total_count(const mo_catalog_t *cat);

/* Serialize merged catalog to a JSON string (caller must free) */
char *catalog_to_json(const mo_catalog_t *cat);

/* Library listing */
int catalog_list_libraries(const mo_catalog_t    *cat,
                            mo_library_source_t   *out,
                            int                    max_out);
