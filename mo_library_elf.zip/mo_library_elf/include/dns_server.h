#pragma once
/*
 * dns_server.h — Nano DNS sinkhole / update blocker
 *
 * Binds a UDP/53 listener (or redirected port via pf/ipfw).
 * Answers NXDOMAIN for Sony OTA/telemetry domains.
 * Forwards all other queries to an upstream resolver.
 *
 * Sony OTA domains sinked (non-exhaustive, see dns_server.c for full list):
 *   *.playstation.net   — PSN infrastructure
 *   fus01.ps5.*         — firmware update service
 *   *.dl.playstation.net
 *   *.sonyentertainmentnetwork.com
 *   *.sonyinteractive.com
 *   np.*.playstation.com
 *   *.update.playstation.com
 *   telemetry.*.sony.com
 */

#include <stdbool.h>
#include <stdint.h>

/* ── Configuration ─────────────────────────────────────────────────────────── */
#define DNS_LISTEN_PORT   53
#define DNS_UPSTREAM_IP   "1.1.1.1"   /* Cloudflare, overridable */
#define DNS_UPSTREAM_PORT 53
#define DNS_BUF_SIZE      512          /* RFC 1035 UDP limit */
#define DNS_TIMEOUT_MS    3000

typedef struct {
    uint16_t    listen_port;           /* default DNS_LISTEN_PORT */
    char        upstream_ip[64];       /* upstream resolver */
    uint16_t    upstream_port;
    bool        log_queries;           /* log every DNS query */
    bool        log_sinks;             /* log every sinkholed query */
} mo_dns_config_t;

/* ── Lifecycle ─────────────────────────────────────────────────────────────── */

/*
 * Start the DNS server in a background thread.
 * Returns true on success (socket bound, thread running).
 * 'cfg' may be NULL to use defaults.
 */
bool dns_server_start(const mo_dns_config_t *cfg);

/* Signal the DNS server thread to stop and wait for it */
void dns_server_stop(void);

/* True if server thread is running */
bool dns_server_running(void);

/* ── Domain management ─────────────────────────────────────────────────────── */

/*
 * Add a domain suffix to the sinkhole list at runtime.
 * Suffix matching: "playstation.net" matches "fus01.ps5.playstation.net".
 */
bool dns_sinkhole_add(const char *suffix);

/* Remove a suffix from the sinkhole list. Returns false if not found. */
bool dns_sinkhole_remove(const char *suffix);

/* Check if a FQDN would be sinkholed */
bool dns_would_sinkhole(const char *fqdn);

/* ── Statistics ─────────────────────────────────────────────────────────────── */
typedef struct {
    uint64_t queries_total;
    uint64_t queries_sinkholed;
    uint64_t queries_forwarded;
    uint64_t queries_failed;
} mo_dns_stats_t;

void dns_get_stats(mo_dns_stats_t *out);
void dns_reset_stats(void);
