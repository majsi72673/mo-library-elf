#pragma once
/*
 * download_manager.h — Multi-stage download queue
 *
 * Stage 1: HTTP GET download to temp file
 * Stage 2: in-place decompression (zip/7z/rar)
 * Stage 3: DPIv2 package install into /data|/mnt|/mnt/usb0
 *
 * Max MO_MAX_ACTIVE_JOBS concurrent downloads.
 * Priority queue: lower priority value = runs first.
 */

#include "mo_types.h"
#include "catalog.h"
#include <stdbool.h>

typedef struct mo_dl_manager mo_dl_manager_t;

/* Callback fired on job state changes — called from worker thread */
typedef void (*dl_event_cb)(const mo_job_t *job, void *userdata);

mo_dl_manager_t *dl_manager_new(mo_catalog_t *catalog);
void             dl_manager_free(mo_dl_manager_t *mgr);

bool dl_manager_start(mo_dl_manager_t *mgr,
                       dl_event_cb      cb,
                       void            *userdata);
void dl_manager_stop(mo_dl_manager_t *mgr);

/* ── Queue operations ───────────────────────────────────────────────────────── */

/*
 * Enqueue a variant download. Returns job id or NULL if:
 *   - variant not found
 *   - insufficient storage space
 *   - already queued/running for same variant
 */
const char *dl_enqueue(mo_dl_manager_t   *mgr,
                        const char        *title_id,
                        const char        *variant_id,
                        mo_install_path_t  dest);

bool dl_pause(mo_dl_manager_t *mgr, const char *job_id);
bool dl_resume(mo_dl_manager_t *mgr, const char *job_id);
bool dl_cancel(mo_dl_manager_t *mgr, const char *job_id);
bool dl_set_priority(mo_dl_manager_t *mgr, const char *job_id, int priority);

void dl_pause_all(mo_dl_manager_t *mgr);
void dl_resume_all(mo_dl_manager_t *mgr);
void dl_cancel_all(mo_dl_manager_t *mgr);
void dl_clear_completed(mo_dl_manager_t *mgr);

/* ── Snapshot / query ───────────────────────────────────────────────────────── */

/* Copy current job list into caller-supplied array. Returns count. */
int dl_snapshot(const mo_dl_manager_t *mgr, mo_job_t *out, int max_out);

/* Get single job by id. Returns false if not found. */
bool dl_get_job(const mo_dl_manager_t *mgr,
                 const char            *job_id,
                 mo_job_t              *out);

/* ── Storage helpers ────────────────────────────────────────────────────────── */
uint64_t dl_storage_used(const mo_dl_manager_t *mgr, mo_install_path_t p);
uint64_t dl_storage_free(const mo_dl_manager_t *mgr, mo_install_path_t p);
bool     dl_usb_mounted(const mo_dl_manager_t *mgr);
void     dl_toggle_usb(mo_dl_manager_t *mgr);
