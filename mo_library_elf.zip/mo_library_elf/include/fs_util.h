#pragma once
/*
 * fs_util.h — Filesystem helpers shared across modules
 */
#include <stdbool.h>
#include <stdint.h>

/*
 * Recursively create directories (like mkdir -p).
 * Returns true on success or if path already exists.
 */
bool fs_mkdirs(const char *path);

/* Returns true if path exists and is a regular file */
bool fs_file_exists(const char *path);

/* Returns file size in bytes, or 0 if not found */
uint64_t fs_file_size(const char *path);

/* Last modification time in ms since epoch, or 0 */
uint64_t fs_mtime_ms(const char *path);
