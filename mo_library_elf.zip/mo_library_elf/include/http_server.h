#pragma once
/*
 * http_server.h — Minimal HTTP/1.1 + WebSocket server for mo_library.elf
 *
 * Routes (from protocol.ts HTTP_ROUTES):
 *   GET  /api/v1/status
 *   POST /api/v1/service/start|stop|restart
 *   GET  /api/v1/catalog
 *   POST /api/v1/catalog/refresh
 *   POST /api/v1/catalog/import
 *   POST /api/v1/queue
 *   POST /api/v1/queue/:id/pause|resume|cancel|priority
 *   POST /api/v1/install
 *   GET  /api/v1/logs
 *   POST /api/v1/payload
 *   GET  /ws          (WebSocket upgrade)
 */

#include "mo_types.h"
#include "catalog.h"
#include "download_manager.h"
#include "mod_manager.h"
#include "pkg_installer.h"
#include <stdbool.h>
#include <stdint.h>

/* ── Server context ─────────────────────────────────────────────────────────── */

typedef struct mo_http_server mo_http_server_t;

typedef struct {
    uint16_t             port;
    char                 password[256];
    bool                 two_factor;
    char                 totp_secret[64];
    mo_catalog_t        *catalog;
    mo_dl_manager_t     *dl_manager;
    mo_mod_manager_t    *mod_manager;
    mo_pkg_installer_t  *pkg_installer;
} mo_http_config_t;

mo_http_server_t *http_server_new(const mo_http_config_t *cfg);
void              http_server_free(mo_http_server_t *srv);

bool http_server_start(mo_http_server_t *srv);
void http_server_stop(mo_http_server_t *srv);
bool http_server_running(const mo_http_server_t *srv);

uint16_t http_server_port(const mo_http_server_t *srv);
int      http_server_client_count(const mo_http_server_t *srv);

/* Broadcast a JSON event to all connected WebSocket clients */
void http_server_broadcast(mo_http_server_t *srv,
                            const char       *event_json);
