#pragma once
/*
 * mo_log.h — Ring-buffer logger and TOTP-based auth
 */

#include "mo_types.h"
#include <stdbool.h>

/* ── Logger ─────────────────────────────────────────────────────────────────── */

void mo_log_init(void);
void mo_log(mo_log_level_t level, const char *source, const char *fmt, ...)
    __attribute__((format(printf, 3, 4)));

#define LOGI(src, ...) mo_log(LOG_INFO,  src, __VA_ARGS__)
#define LOGW(src, ...) mo_log(LOG_WARN,  src, __VA_ARGS__)
#define LOGE(src, ...) mo_log(LOG_ERROR, src, __VA_ARGS__)

/* Copy ring buffer into caller-supplied array. Returns count copied. */
int  mo_log_snapshot(mo_log_entry_t *out, int max_out);

/* Export logs as newline-delimited text (caller must free) */
char *mo_log_export(void);

void mo_log_clear(void);

/* ── TOTP (lightweight software token) ─────────────────────────────────────── */

/*
 * FNV-1a based TOTP compatible with the web app's demoTotp():
 *   window  = floor(epoch_ms / 30000)
 *   hash    = fnv32a( secret + ":" + window )
 *   code    = zero-padded 6-digit  (hash % 1000000)
 */
void mo_totp_generate(const char *secret, uint64_t epoch_ms,
                       char out[7]);   /* "XXXXXX\0" */

int  mo_totp_remaining_seconds(uint64_t epoch_ms);

/* ── Auth ────────────────────────────────────────────────────────────────────── */

typedef struct {
    char password[256];
    bool two_factor_enabled;
    char totp_secret[64];
    bool authed;
} mo_auth_t;

void mo_auth_init(mo_auth_t *a,
                   const char *password,
                   const char *totp_secret);

typedef enum { AUTH_OK=0, AUTH_BAD_PASSWORD, AUTH_BAD_TOTP } mo_auth_result_t;

mo_auth_result_t mo_auth_login(mo_auth_t  *a,
                                const char *password,
                                const char *totp_code);   /* NULL if 2FA off */

void mo_auth_logout(mo_auth_t *a);
void mo_auth_set_password(mo_auth_t *a, const char *new_pw);
void mo_auth_set_two_factor(mo_auth_t *a, bool enabled);
