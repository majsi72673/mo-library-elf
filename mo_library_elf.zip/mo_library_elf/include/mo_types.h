#pragma once
/*
 * mo_types.h — Core type definitions for mo_library.elf
 * Translated from TypeScript src/lib/types.ts
 */

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <time.h>

/* ── Constants ───────────────────────────────────────────────────────────── */
#define MO_VERSION          "1.0.1-elf"
#define MO_FIRMWARE_TARGET  "10.01"
#define MO_MAIN_LIBRARY_ID  "mo-main"
#define MO_DEFAULT_PORT     8855
#define MO_DEFAULT_PASSWORD "crimson-8855"
#define MO_TOTP_SECRET      "MO-LIBRARY-OWNER"
#define MO_PROTOCOL_VERSION "1.0"
#define MO_MAX_LOGS         250
#define MO_MAX_TOASTS       6
#define MO_MAX_ACTIVE_JOBS  2
#define MO_MAX_VARIANTS     8
#define MO_MAX_ID_LEN       64
#define MO_MAX_STR_LEN      512
#define MO_MAX_URL_LEN      2048
#define MO_MAX_TITLES       4096
#define MO_MAX_JOBS         256
#define MO_GB               (1024ULL * 1024ULL * 1024ULL)
#define MO_MB               (1024ULL * 1024ULL)
#define MO_INTERNAL_TOTAL   (825ULL * MO_GB)
#define MO_USB_TOTAL        (1024ULL * MO_GB)

/* ── Enumerations ─────────────────────────────────────────────────────────── */
typedef enum {
    FMT_FPKG  = 0,
    FMT_FFPKG,
    FMT_EXFAT,
    FMT_FFPFS,
    FMT_DUMP,
    FMT_ZIP,
    FMT_7Z,
    FMT_RAR,
    FMT_UNKNOWN
} mo_format_t;

typedef enum {
    CAT_GAME = 0,
    CAT_DLC,
    CAT_UPDATE,
    CAT_BACKPORT,
    CAT_PACKAGE,
    CAT_UNKNOWN
} mo_category_t;

typedef enum {
    REGION_US = 0,
    REGION_EU,
    REGION_JP,
    REGION_ASIA,
    REGION_UNKNOWN
} mo_region_t;

typedef enum {
    JOB_QUEUED = 0,
    JOB_DOWNLOADING,
    JOB_DECOMPRESSING,
    JOB_INSTALLING,
    JOB_PAUSED,
    JOB_COMPLETED,
    JOB_FAILED,
    JOB_CANCELLED
} mo_job_status_t;

typedef enum {
    LOG_INFO = 0,
    LOG_WARN,
    LOG_ERROR
} mo_log_level_t;

typedef enum {
    INSTALL_DATA   = 0,  /* /data     */
    INSTALL_MNT    = 1,  /* /mnt      */
    INSTALL_USB    = 2   /* /mnt/usb0 */
} mo_install_path_t;

typedef enum {
    LIB_BUILTIN = 0,
    LIB_URL,
    LIB_JSON
} mo_lib_type_t;

/* ── Structures ───────────────────────────────────────────────────────────── */

typedef struct {
    char        id[MO_MAX_ID_LEN];
    mo_format_t format;
    uint64_t    size_bytes;
    char        version[32];
    char        url[MO_MAX_URL_LEN];
    bool        compressed;
    double      expand_ratio;
} mo_variant_t;

typedef struct {
    char            id[MO_MAX_ID_LEN];
    char            title[MO_MAX_STR_LEN];
    char            cover_url[MO_MAX_URL_LEN];
    char            cover_seed[MO_MAX_ID_LEN];
    mo_region_t     region;
    char            required_firmware[16];
    mo_category_t   category;
    char            description[MO_MAX_STR_LEN];
    char            publisher[MO_MAX_STR_LEN];
    int             release_year;
    mo_variant_t    variants[MO_MAX_VARIANTS];
    int             variant_count;
    char            dlcs[16][MO_MAX_ID_LEN];
    int             dlc_count;
    char            updates[16][MO_MAX_ID_LEN];
    int             update_count;
    char            backports[16][MO_MAX_ID_LEN];
    int             backport_count;
    char            parent_id[MO_MAX_ID_LEN];
    uint64_t        added_at;
    char            library_id[MO_MAX_ID_LEN];
} mo_title_t;

typedef struct {
    char            id[MO_MAX_ID_LEN];
    char            name[MO_MAX_STR_LEN];
    mo_lib_type_t   type;
    char            url[MO_MAX_URL_LEN];
    bool            enabled;
    int             title_count;
} mo_library_source_t;

typedef struct {
    char                id[MO_MAX_ID_LEN];
    char                title_id[MO_MAX_ID_LEN];
    char                variant_id[MO_MAX_ID_LEN];
    mo_job_status_t     status;
    double              progress;      /* 0.0 – 1.0 */
    uint64_t            speed_bps;
    int                 priority;      /* 0 = highest */
    int                 stage;         /* 1=dl 2=decomp 3=install */
    char                error[256];
    mo_install_path_t   dest_path;
    uint64_t            started_at;    /* ms epoch */
    uint64_t            finished_at;
    uint64_t            bytes_done;
    uint64_t            elapsed_ms;
    int                 sock_fd;       /* active download socket, -1 if none */
} mo_job_t;

typedef struct {
    char            id[MO_MAX_ID_LEN];
    uint64_t        ts;
    mo_log_level_t  level;
    char            source[32];
    char            message[MO_MAX_STR_LEN];
} mo_log_entry_t;

typedef struct {
    char            variant_id[MO_MAX_ID_LEN];
    mo_install_path_t path;
    uint64_t        at;
    uint64_t        size_bytes;
} mo_installed_record_t;

/* ── String helpers ───────────────────────────────────────────────────────── */
const char *mo_format_str(mo_format_t f);
const char *mo_category_str(mo_category_t c);
const char *mo_region_str(mo_region_t r);
const char *mo_job_status_str(mo_job_status_t s);
const char *mo_log_level_str(mo_log_level_t l);
const char *mo_install_path_str(mo_install_path_t p);

mo_format_t   mo_format_from_str(const char *s);
mo_category_t mo_category_from_str(const char *s);
mo_region_t   mo_region_from_str(const char *s);

/* ── Utility ──────────────────────────────────────────────────────────────── */
uint64_t mo_needed_bytes(const mo_variant_t *v);
void     mo_uid(char *out, size_t len, const char *prefix);
uint64_t mo_now_ms(void);
void     mo_format_bytes(char *out, size_t len, uint64_t bytes);
void     mo_format_speed(char *out, size_t len, uint64_t bps);
