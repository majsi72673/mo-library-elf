#pragma once
/*
 * mod_manager.h — PS5 Mod Manager
 *
 * Manages mods per game title:
 *   - Load mod catalogs from JSON (USB / URL)
 *   - Install mods to correct game directory
 *   - Enable / disable without deleting
 *   - Track installed mods per title
 */

#include "mo_types.h"
#include <stdbool.h>
#include <stdint.h>

/* ── Constants ───────────────────────────────────────────────────────────── */
#define MOD_MAX_NAME     128
#define MOD_MAX_ID       64
#define MOD_MAX_VERSION  32
#define MOD_MAX_URL      2048
#define MOD_MAX_PATH     512
#define MOD_MAX_ENTRIES  1024
#define MOD_MAX_TAGS     8

/* ── Mod types ───────────────────────────────────────────────────────────── */
typedef enum {
    MOD_TYPE_TEXTURE = 0,   /* Texture replacement        */
    MOD_TYPE_SCRIPT,        /* Game script / lua mod      */
    MOD_TYPE_AUDIO,         /* Audio replacement          */
    MOD_TYPE_SAVE,          /* Save game modification     */
    MOD_TYPE_CHEAT,         /* Cheat / trainer            */
    MOD_TYPE_PATCH,         /* Binary patch               */
    MOD_TYPE_MISC           /* Other                      */
} mo_mod_type_t;

typedef enum {
    MOD_STATE_AVAILABLE = 0,
    MOD_STATE_DOWNLOADING,
    MOD_STATE_INSTALLED,
    MOD_STATE_ENABLED,
    MOD_STATE_DISABLED,
    MOD_STATE_ERROR
} mo_mod_state_t;

/* ── Mod entry ───────────────────────────────────────────────────────────── */
typedef struct {
    char            id[MOD_MAX_ID];
    char            title_id[MO_MAX_ID_LEN];   /* linked game title ID */
    char            name[MOD_MAX_NAME];
    char            author[MOD_MAX_NAME];
    char            version[MOD_MAX_VERSION];
    char            description[MO_MAX_STR_LEN];
    mo_mod_type_t   type;
    mo_mod_state_t  state;
    uint64_t        size_bytes;
    char            url[MOD_MAX_URL];
    char            install_path[MOD_MAX_PATH]; /* where it lives on PS5 */
    char            tags[MOD_MAX_TAGS][32];
    int             tag_count;
    uint64_t        installed_at;
    bool            enabled;
    char            source_lib[MOD_MAX_ID];     /* which mod library */
} mo_mod_t;

/* ── Mod library source ──────────────────────────────────────────────────── */
typedef struct {
    char    id[MOD_MAX_ID];
    char    name[MOD_MAX_NAME];
    char    url[MOD_MAX_URL];
    bool    enabled;
    int     mod_count;
} mo_mod_library_t;

/* ── Manager ─────────────────────────────────────────────────────────────── */
typedef struct mo_mod_manager mo_mod_manager_t;

mo_mod_manager_t *mod_manager_new(void);
void              mod_manager_free(mo_mod_manager_t *mgr);

/* Load mod catalog from JSON string */
bool mod_import_json(mo_mod_manager_t *mgr, const char *json, size_t len);

/* Load from USB file */
bool mod_load_file(mo_mod_manager_t *mgr, const char *path);

/* Fetch from URL */
bool mod_fetch_url(mo_mod_manager_t *mgr, const char *url);

/* ── Query ───────────────────────────────────────────────────────────────── */

/* Get mods for a specific title_id — returns count */
int mod_get_for_title(const mo_mod_manager_t *mgr,
                       const char *title_id,
                       mo_mod_t *out, int max_out);

/* Get all mods with optional type filter (MOD_TYPE_MISC = all) */
int mod_get_all(const mo_mod_manager_t *mgr,
                 mo_mod_type_t type_filter,
                 mo_mod_t *out, int max_out);

/* Find mod by id */
const mo_mod_t *mod_find(const mo_mod_manager_t *mgr, const char *id);

/* ── Install / Enable / Disable ─────────────────────────────────────────── */

/*
 * Install a mod:
 *   1. Download from mod->url to /data/mods/<title_id>/<mod_id>/
 *   2. Extract if compressed
 *   3. Register as installed + enabled
 */
bool mod_install(mo_mod_manager_t *mgr, const char *mod_id);

/* Enable an installed mod (creates symlinks / activates patches) */
bool mod_enable(mo_mod_manager_t *mgr, const char *mod_id);

/* Disable without deleting (removes symlinks / reverts patches) */
bool mod_disable(mo_mod_manager_t *mgr, const char *mod_id);

/* Uninstall and delete mod files */
bool mod_uninstall(mo_mod_manager_t *mgr, const char *mod_id);

/* ── Serialization ───────────────────────────────────────────────────────── */
char *mod_catalog_to_json(const mo_mod_manager_t *mgr);
char *mod_installed_to_json(const mo_mod_manager_t *mgr);

const char *mo_mod_type_str(mo_mod_type_t t);
const char *mo_mod_state_str(mo_mod_state_t s);
mo_mod_type_t mo_mod_type_from_str(const char *s);
