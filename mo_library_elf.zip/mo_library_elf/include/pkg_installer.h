#pragma once
/*
 * pkg_installer.h — PS5 PKG Installer
 *
 * Handles:
 *   - Direct PKG download from URL
 *   - PKG scan from USB / internal storage
 *   - PKG info extraction (title, version, content type)
 *   - Install queue with progress tracking
 *   - Fake PKG + Official PKG support
 */

#include "mo_types.h"
#include <stdbool.h>
#include <stdint.h>

/* ── PKG content types ───────────────────────────────────────────────────── */
typedef enum {
    PKG_TYPE_GAME      = 0x1A,
    PKG_TYPE_PATCH     = 0x1B,
    PKG_TYPE_DLC       = 0x1C,
    PKG_TYPE_APP       = 0x1F,
    PKG_TYPE_THEME     = 0x20,
    PKG_TYPE_UNKNOWN   = 0xFF
} mo_pkg_type_t;

typedef enum {
    PKG_STATE_IDLE = 0,
    PKG_STATE_SCANNING,
    PKG_STATE_DOWNLOADING,
    PKG_STATE_INSTALLING,
    PKG_STATE_DONE,
    PKG_STATE_FAILED
} mo_pkg_state_t;

/* ── PKG info (read from PKG header) ─────────────────────────────────────── */
typedef struct {
    char          path[1024];          /* local path or URL          */
    char          title_id[16];        /* e.g. CUSA00001             */
    char          title[128];          /* game title from SFO        */
    char          version[16];         /* e.g. 01.00                 */
    char          required_fw[16];     /* minimum PS5 firmware       */
    mo_pkg_type_t type;
    uint64_t      pkg_size;            /* compressed PKG size        */
    uint64_t      install_size;        /* size after install         */
    bool          is_fake;             /* fake/homebrew PKG          */
    bool          is_encrypted;        /* needs decryption key       */
    char          content_id[48];      /* full content ID string     */
} mo_pkg_info_t;

/* ── Install job ─────────────────────────────────────────────────────────── */
typedef struct {
    char            id[MO_MAX_ID_LEN];
    mo_pkg_info_t   info;
    mo_pkg_state_t  state;
    double          progress;
    uint64_t        speed_bps;
    char            error[256];
    mo_install_path_t dest;
    uint64_t        started_at;
    uint64_t        finished_at;
} mo_pkg_job_t;

/* ── Event callback ──────────────────────────────────────────────────────── */
typedef void (*pkg_event_cb)(const mo_pkg_job_t *job, void *userdata);

/* ── Manager ─────────────────────────────────────────────────────────────── */
typedef struct mo_pkg_installer mo_pkg_installer_t;

mo_pkg_installer_t *pkg_installer_new(void);
void                pkg_installer_free(mo_pkg_installer_t *inst);

bool pkg_installer_start(mo_pkg_installer_t *inst,
                          pkg_event_cb cb, void *userdata);
void pkg_installer_stop(mo_pkg_installer_t *inst);

/* ── PKG info extraction ─────────────────────────────────────────────────── */

/*
 * Read PKG header and SFO to extract title, version, type.
 * Works on local file paths.
 */
bool pkg_read_info(const char *path, mo_pkg_info_t *out);

/*
 * Scan a directory for .pkg files and return their info.
 * Returns count found.
 */
int pkg_scan_dir(const char *dir_path, mo_pkg_info_t *out, int max_out);

/* ── Install operations ──────────────────────────────────────────────────── */

/*
 * Queue a PKG from a URL for download + install.
 * Returns job ID or NULL on error.
 */
const char *pkg_queue_url(mo_pkg_installer_t *inst,
                           const char *url,
                           mo_install_path_t dest);

/*
 * Queue a local PKG file for install.
 * Returns job ID or NULL on error.
 */
const char *pkg_queue_local(mo_pkg_installer_t *inst,
                             const char *path,
                             mo_install_path_t dest);

/*
 * Install a PKG directly from USB scan result.
 */
const char *pkg_queue_info(mo_pkg_installer_t *inst,
                            const mo_pkg_info_t *info,
                            mo_install_path_t dest);

bool pkg_cancel(mo_pkg_installer_t *inst, const char *job_id);
void pkg_cancel_all(mo_pkg_installer_t *inst);
void pkg_clear_done(mo_pkg_installer_t *inst);

/* ── Query ───────────────────────────────────────────────────────────────── */
int  pkg_snapshot(const mo_pkg_installer_t *inst,
                   mo_pkg_job_t *out, int max_out);
bool pkg_get_job(const mo_pkg_installer_t *inst,
                  const char *job_id, mo_pkg_job_t *out);

/* ── Helpers ─────────────────────────────────────────────────────────────── */
const char *mo_pkg_type_str(mo_pkg_type_t t);
const char *mo_pkg_state_str(mo_pkg_state_t s);
char       *pkg_jobs_to_json(const mo_pkg_installer_t *inst);
char       *pkg_info_to_json(const mo_pkg_info_t *info);

/* USB scan → JSON */
char *pkg_scan_to_json(const char *dir_path);
