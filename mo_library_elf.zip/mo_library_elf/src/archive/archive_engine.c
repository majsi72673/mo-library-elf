/*
 * archive_engine.c — ZIP/7z/RAR extraction engine
 *
 * ZIP  — handled natively via embedded miniz
 * 7z   — basic support via miniz (DEFLATE-based streams only)
 * RAR  — stubs with clear error (RAR is proprietary; advise re-pack as zip)
 *
 * Two operational modes:
 *   Manual : archive_extract_sync()        — blocking, caller-driven
 *   Auto   : archive_monitor_start/stop()  — background thread watches a dir
 */
#include "archive_engine.h"
#include "fs_util.h"
#include "mo_log.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>
#include <pthread.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <errno.h>
#include <stdatomic.h>
#include <fcntl.h>

/* miniz single-header: provides mz_zip_reader_* API */
#include "miniz.h"

/* ── Format detection ────────────────────────────────────────────────────────── */

mo_arch_format_t arch_detect_format(const char *path) {
    if (!path) return ARCH_UNKNOWN;
    const char *dot = strrchr(path, '.');
    if (!dot) return ARCH_UNKNOWN;
    dot++;
    if (strcasecmp(dot, "zip") == 0) return ARCH_ZIP;
    if (strcasecmp(dot, "7z")  == 0) return ARCH_7Z;
    if (strcasecmp(dot, "rar") == 0) return ARCH_RAR;
    return ARCH_UNKNOWN;
}

/* mkdirs provided by fs_util.h */
#define mkdirs fs_mkdirs

/* ── ZIP extraction via miniz ────────────────────────────────────────────────── */

static mo_arch_result_t extract_zip(const mo_arch_options_t *opts) {
    mo_arch_result_t res = {0};

    mz_zip_archive zip;
    memset(&zip, 0, sizeof(zip));

    if (!mz_zip_reader_init_file(&zip, opts->src_path, 0)) {
        snprintf(res.error, sizeof(res.error),
                 "mz_zip_reader_init_file failed: %s", opts->src_path);
        LOGE("archive", "%s", res.error);
        return res;
    }

    mz_uint count = mz_zip_reader_get_num_files(&zip);
    uint64_t total_bytes = 0;

    /* First pass: calculate total uncompressed size for progress */
    for (mz_uint i = 0; i < count; i++) {
        mz_zip_archive_file_stat st;
        if (mz_zip_reader_file_stat(&zip, i, &st))
            total_bytes += st.m_uncomp_size;
    }

    uint64_t done_bytes = 0;

    for (mz_uint i = 0; i < count; i++) {
        mz_zip_archive_file_stat st;
        if (!mz_zip_reader_file_stat(&zip, i, &st)) continue;

        /* Build destination path */
        char dest[2048];
        snprintf(dest, sizeof(dest), "%s/%s", opts->dst_path, st.m_filename);

        if (mz_zip_reader_is_file_a_directory(&zip, i)) {
            mkdirs(dest);
            continue;
        }

        /* Ensure parent directory exists */
        char parent[2048];
        snprintf(parent, sizeof(parent), "%s", dest);
        char *slash = strrchr(parent, '/');
        if (slash) { *slash = '\0'; mkdirs(parent); }

        /* Skip if exists and overwrite=false */
        if (!opts->overwrite) {
            struct stat chk;
            if (stat(dest, &chk) == 0) {
                done_bytes += st.m_uncomp_size;
                continue;
            }
        }

        if (!mz_zip_reader_extract_to_file(&zip, i, dest, 0)) {
            snprintf(res.error, sizeof(res.error),
                     "Failed to extract '%s'", st.m_filename);
            LOGE("archive", "%s", res.error);
            mz_zip_reader_end(&zip);
            return res;
        }

        done_bytes += st.m_uncomp_size;
        res.files_extracted++;
        res.bytes_extracted += st.m_uncomp_size;

        if (opts->cb)
            opts->cb(st.m_filename, done_bytes, total_bytes, opts->cb_userdata);
    }

    mz_zip_reader_end(&zip);

    if (opts->delete_after) {
        if (unlink(opts->src_path) < 0)
            LOGW("archive", "unlink('%s'): %s", opts->src_path, strerror(errno));
        else
            LOGI("archive", "Deleted source archive: %s", opts->src_path);
    }

    res.success = true;
    LOGI("archive", "Extracted %d files (%.1f MB) from %s",
         res.files_extracted,
         (double)res.bytes_extracted / (1024.0*1024.0),
         opts->src_path);
    return res;
}

/* ── 7z extraction ───────────────────────────────────────────────────────────── */
/*
 * miniz does not natively parse the 7z container format.
 * Many 7z archives use DEFLATE internally — we attempt a ZIP parse
 * as a best-effort fallback.  Proper LZMA support requires liblzma.
 */
static mo_arch_result_t extract_7z(const mo_arch_options_t *opts) {
    LOGW("archive",
         "7z: attempting DEFLATE fallback via miniz for '%s'. "
         "LZMA-compressed 7z archives require liblzma.", opts->src_path);

    /* Many PS5 homebrew 7z archives are actually ZIP-compatible containers */
    mo_arch_options_t zip_opts = *opts;
    mo_arch_result_t res = extract_zip(&zip_opts);

    if (!res.success) {
        snprintf(res.error, sizeof(res.error),
                 "7z extraction failed: miniz could not parse '%s'. "
                 "Re-package as .zip for full support.", opts->src_path);
        LOGE("archive", "%s", res.error);
    }
    return res;
}

/* ── RAR stub ────────────────────────────────────────────────────────────────── */

static mo_arch_result_t extract_rar(const mo_arch_options_t *opts) {
    mo_arch_result_t res = {0};
    snprintf(res.error, sizeof(res.error),
             "RAR is a proprietary format and cannot be extracted natively. "
             "Please re-package '%s' as a ZIP archive.",
             opts->src_path);
    LOGE("archive", "%s", res.error);
    return res;
}

/* ── Public: synchronous extraction ─────────────────────────────────────────── */

mo_arch_result_t archive_extract_sync(const mo_arch_options_t *opts) {
    mo_arch_result_t bad = {0};
    if (!opts || !opts->src_path[0] || !opts->dst_path[0]) {
        snprintf(bad.error, sizeof(bad.error), "invalid options");
        return bad;
    }

    if (!mkdirs(opts->dst_path)) {
        snprintf(bad.error, sizeof(bad.error),
                 "cannot create dst_path '%s'", opts->dst_path);
        return bad;
    }

    mo_arch_format_t fmt = arch_detect_format(opts->src_path);
    switch (fmt) {
    case ARCH_ZIP: return extract_zip(opts);
    case ARCH_7Z:  return extract_7z(opts);
    case ARCH_RAR: return extract_rar(opts);
    default:
        snprintf(bad.error, sizeof(bad.error),
                 "unknown archive format: %s", opts->src_path);
        return bad;
    }
}

/* ── Archive size estimator ──────────────────────────────────────────────────── */

uint64_t archive_estimate_size(const char *path) {
    if (!path) return 0;
    mo_arch_format_t fmt = arch_detect_format(path);
    if (fmt != ARCH_ZIP) {
        /* For 7z/rar estimate from file size × 2 */
        struct stat st;
        if (stat(path, &st) == 0)
            return (uint64_t)st.st_size * 2;
        return 0;
    }

    mz_zip_archive zip;
    memset(&zip, 0, sizeof(zip));
    if (!mz_zip_reader_init_file(&zip, path, 0)) return 0;

    uint64_t total = 0;
    mz_uint count = mz_zip_reader_get_num_files(&zip);
    for (mz_uint i = 0; i < count; i++) {
        mz_zip_archive_file_stat st;
        if (mz_zip_reader_file_stat(&zip, i, &st))
            total += st.m_uncomp_size;
    }
    mz_zip_reader_end(&zip);
    return total;
}

/* ── Auto monitor ────────────────────────────────────────────────────────────── */

#define SETTLE_TIME_MS 5000  /* file must be unmodified for this long */

static struct {
    pthread_t           thread;
    _Atomic bool        running;
    mo_arch_monitor_cfg_t cfg;
} s_mon = { .running = false };

typedef struct {
    char     path[1024];
    uint64_t last_mtime_ms;
    bool     queued;
} watch_entry_t;

#define MAX_WATCH 64
static watch_entry_t s_watch[MAX_WATCH];
static int s_watch_n = 0;

/* Use shared fs_util and mo_types helpers */
#define mtime_ms  fs_mtime_ms
#define now_ms    mo_now_ms

static void *monitor_thread(void *arg) {
    (void)arg;
    int interval = s_mon.cfg.poll_interval_ms > 0
                       ? s_mon.cfg.poll_interval_ms
                       : 2000;

    LOGI("archive", "Auto-monitor started on '%s'", s_mon.cfg.watch_dir);

    while (atomic_load(&s_mon.running)) {
        DIR *d = opendir(s_mon.cfg.watch_dir);
        if (d) {
            struct dirent *e;
            while ((e = readdir(d)) != NULL) {
                if (arch_detect_format(e->d_name) == ARCH_UNKNOWN) continue;

                char full[1024];
                snprintf(full, sizeof(full), "%s/%s",
                         s_mon.cfg.watch_dir, e->d_name);

                /* Find or insert watch entry */
                watch_entry_t *we = NULL;
                for (int i = 0; i < s_watch_n; i++)
                    if (strcmp(s_watch[i].path, full) == 0)
                        { we = &s_watch[i]; break; }

                if (!we && s_watch_n < MAX_WATCH) {
                    we = &s_watch[s_watch_n++];
                    snprintf(we->path, sizeof(we->path), "%s", full);
                    we->last_mtime_ms = mtime_ms(full);
                    we->queued = false;
                }
                if (!we) continue;

                uint64_t mt = mtime_ms(full);
                if (mt != we->last_mtime_ms) {
                    we->last_mtime_ms = mt;
                    we->queued = false;
                    continue;
                }

                /* File settled — extract if not already done */
                if (!we->queued &&
                    now_ms() - mt >= SETTLE_TIME_MS) {
                    we->queued = true;
                    LOGI("archive", "Auto-extracting: %s", full);

                    mo_arch_options_t opts = {0};
                    snprintf(opts.src_path, sizeof(opts.src_path), "%s", full);
                    snprintf(opts.dst_path, sizeof(opts.dst_path), "%s",
                             s_mon.cfg.dest_dir);
                    opts.delete_after = s_mon.cfg.delete_after;
                    opts.overwrite    = s_mon.cfg.overwrite;

                    mo_arch_result_t r = archive_extract_sync(&opts);
                    if (!r.success)
                        LOGE("archive", "Auto-extract failed: %s", r.error);
                    else
                        LOGI("archive", "Auto-extract complete: %d files", r.files_extracted);
                }
            }
            closedir(d);
        } else {
            LOGW("archive", "monitor: opendir('%s'): %s",
                 s_mon.cfg.watch_dir, strerror(errno));
        }

        /* Sleep in small increments so we can detect stop quickly */
        int slept = 0;
        while (slept < interval && atomic_load(&s_mon.running)) {
            usleep(200000);  /* 200 ms */
            slept += 200;
        }
    }

    LOGI("archive", "Auto-monitor stopped");
    return NULL;
}

bool archive_monitor_start(const mo_arch_monitor_cfg_t *cfg) {
    if (atomic_load(&s_mon.running)) return true;
    if (!cfg) return false;

    s_mon.cfg = *cfg;
    s_watch_n = 0;
    atomic_store(&s_mon.running, true);

    if (pthread_create(&s_mon.thread, NULL, monitor_thread, NULL) != 0) {
        LOGE("archive", "pthread_create failed for monitor");
        atomic_store(&s_mon.running, false);
        return false;
    }
    return true;
}

void archive_monitor_stop(void) {
    if (!atomic_load(&s_mon.running)) return;
    atomic_store(&s_mon.running, false);
    pthread_join(s_mon.thread, NULL);
}

bool archive_monitor_running(void) {
    return atomic_load(&s_mon.running);
}
