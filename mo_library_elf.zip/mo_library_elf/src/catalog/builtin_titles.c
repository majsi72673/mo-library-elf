/*
 * builtin_titles.c — Static catalog translated from catalog.ts
 *
 * All sizes are in bytes. T0 = 2026-08-01T00:00:00Z = 1753920000000 ms
 */
#include "builtin_titles.h"
#include "mo_types.h"
#include <string.h>

#define T0  1753920000000ULL
#define GB  MO_GB
#define MB  MO_MB

/* Helper macro: declare a single-variant game */
#define V1(vid, fmt, sz, ver)   \
    .variants = {{ .id=vid, .format=fmt, .size_bytes=(uint64_t)(sz), \
                   .version=ver, .url="mo://payload/"vid,            \
                   .compressed=(fmt==FMT_ZIP||fmt==FMT_7Z||fmt==FMT_RAR), \
                   .expand_ratio=1.0 }},                              \
    .variant_count = 1

#define V2(vid,fmt,sz,ver, vid2,fmt2,sz2,ver2,comp2,er2)             \
    .variants = {                                                       \
        { .id=vid,  .format=fmt,  .size_bytes=(uint64_t)(sz),         \
          .version=ver,  .url="mo://payload/"vid,                      \
          .compressed=(fmt==FMT_ZIP||fmt==FMT_7Z||fmt==FMT_RAR),      \
          .expand_ratio=1.0 },                                          \
        { .id=vid2, .format=fmt2, .size_bytes=(uint64_t)(sz2),        \
          .version=ver2, .url="mo://payload/"vid2,                     \
          .compressed=comp2, .expand_ratio=er2 }                       \
    },                                                                  \
    .variant_count = 2

static const mo_title_t s_titles[] = {
  /* ─── Aetherfall ─────────────────────────────────────────────────── */
  {
    .id="CUSA-MO-00001", .title="Aetherfall", .cover_seed="CUSA-MO-00001",
    .region=REGION_US, .required_firmware="10.01", .category=CAT_GAME,
    .publisher="Red Meridian", .release_year=2025,
    .description="An open-sky odyssey across floating continents.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+1,
    .dlcs={"CUSA-MO-00001-dlc1"}, .dlc_count=1,
    .updates={"CUSA-MO-00001-upd"}, .update_count=1,
    V2("CUSA-MO-00001-fpkg",FMT_FPKG,(uint64_t)(84.2*(double)GB),"1.04",
       "CUSA-MO-00001-zip", FMT_ZIP, (uint64_t)(41.6*(double)GB),"1.04",true,2.02)
  },
  {
    .id="CUSA-MO-00001-dlc1", .title="Aetherfall — Skyforge Expanse",
    .cover_seed="CUSA-MO-00001-dlc1", .parent_id="CUSA-MO-00001",
    .region=REGION_US, .required_firmware="10.01", .category=CAT_DLC,
    .publisher="Red Meridian", .release_year=2026,
    .description="Northern archipelago, new storm-class weapons, and a co-op raid.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+2,
    V1("CUSA-MO-00001-dlc1-fpkg",FMT_FPKG,(uint64_t)(9.4*(double)GB),"1.00")
  },
  {
    .id="CUSA-MO-00001-upd", .title="Aetherfall Update 1.04",
    .cover_seed="CUSA-MO-00001-upd", .parent_id="CUSA-MO-00001",
    .region=REGION_US, .required_firmware="10.01", .category=CAT_UPDATE,
    .publisher="Red Meridian", .release_year=2026,
    .description="Traversal polish, photo mode, and crash fixes for 10.01.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+3,
    V1("CUSA-MO-00001-upd-fpkg",FMT_FPKG,(uint64_t)(6.1*(double)GB),"1.04")
  },
  /* ─── Crimson Protocol ────────────────────────────────────────────── */
  {
    .id="CUSA-MO-00002", .title="Crimson Protocol",
    .cover_seed="CUSA-MO-00002",
    .region=REGION_EU, .required_firmware="9.00", .category=CAT_GAME,
    .publisher="Nocturne Atelier", .release_year=2024,
    .description="Infiltrate a city that forgets you every dawn.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+4,
    .dlcs={"CUSA-MO-00002-dlc1"}, .dlc_count=1,
    .backports={"CUSA-MO-00002-bp"}, .backport_count=1,
    V2("CUSA-MO-00002-fpkg",FMT_FPKG,(uint64_t)(38.6*(double)GB),"1.12",
       "CUSA-MO-00002-ffpkg",FMT_FFPKG,(uint64_t)(38.6*(double)GB),"1.12",false,1.0)
  },
  {
    .id="CUSA-MO-00002-bp", .title="Crimson Protocol Backport 10.01",
    .cover_seed="CUSA-MO-00002-bp", .parent_id="CUSA-MO-00002",
    .region=REGION_EU, .required_firmware="10.01", .category=CAT_BACKPORT,
    .publisher="MO Labs", .release_year=2026,
    .description="Backport patch enabling 9.00 dump on firmware 10.01.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+5,
    V1("CUSA-MO-00002-bp-fpkg",FMT_FPKG,(uint64_t)(180*(double)MB),"10.01")
  },
  {
    .id="CUSA-MO-00002-dlc1", .title="Crimson Protocol — Glass District",
    .cover_seed="CUSA-MO-00002-dlc1", .parent_id="CUSA-MO-00002",
    .region=REGION_EU, .required_firmware="9.00", .category=CAT_DLC,
    .publisher="Nocturne Atelier", .release_year=2025,
    .description="A vertical heist through a mirrored embassy.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+6,
    V1("CUSA-MO-00002-dlc1-fpkg",FMT_FPKG,(uint64_t)(4.8*(double)GB),"1.00")
  },
  /* ─── Driftline: Apex ────────────────────────────────────────────── */
  {
    .id="CUSA-MO-00003", .title="Driftline: Apex",
    .cover_seed="CUSA-MO-00003",
    .region=REGION_US, .required_firmware="10.01", .category=CAT_GAME,
    .publisher="Apex Circuit", .release_year=2025,
    .description="Tire-smoke poetry on illegal mountain passes.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+7,
    .updates={"CUSA-MO-00003-upd"}, .update_count=1,
    V2("CUSA-MO-00003-fpkg",FMT_FPKG,(uint64_t)(52.1*(double)GB),"1.02",
       "CUSA-MO-00003-exfat",FMT_EXFAT,(uint64_t)(52.1*(double)GB),"1.02",false,1.0)
  },
  {
    .id="CUSA-MO-00003-upd", .title="Driftline: Apex Update 1.02",
    .cover_seed="CUSA-MO-00003-upd", .parent_id="CUSA-MO-00003",
    .region=REGION_US, .required_firmware="10.01", .category=CAT_UPDATE,
    .publisher="Apex Circuit", .release_year=2026,
    .description="Night weather cycle and 8 extra mountain routes.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+8,
    V1("CUSA-MO-00003-upd-fpkg",FMT_FPKG,(uint64_t)(3.2*(double)GB),"1.02")
  },
  /* ─── Hollow Circuit ─────────────────────────────────────────────── */
  {
    .id="CUSA-MO-00004", .title="Hollow Circuit",
    .cover_seed="CUSA-MO-00004",
    .region=REGION_JP, .required_firmware="8.00", .category=CAT_GAME,
    .publisher="Kuro Line", .release_year=2023,
    .description="A neon detective story inside a city-sized processor.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+9,
    .backports={"CUSA-MO-00004-bp"}, .backport_count=1,
    V2("CUSA-MO-00004-fpkg",FMT_FPKG,(uint64_t)(71.4*(double)GB),"1.30",
       "CUSA-MO-00004-7z",FMT_7Z,(uint64_t)(33.8*(double)GB),"1.30",true,2.11)
  },
  {
    .id="CUSA-MO-00004-bp", .title="Hollow Circuit Backport 10.01",
    .cover_seed="CUSA-MO-00004-bp", .parent_id="CUSA-MO-00004",
    .region=REGION_JP, .required_firmware="10.01", .category=CAT_BACKPORT,
    .publisher="MO Labs", .release_year=2026,
    .description="Kernel shim and trophy remap for 10.01.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+10,
    V1("CUSA-MO-00004-bp-fpkg",FMT_FPKG,(uint64_t)(240*(double)MB),"10.01")
  },
  /* ─── Tide of Kings ──────────────────────────────────────────────── */
  {
    .id="CUSA-MO-00005", .title="Tide of Kings",
    .cover_seed="CUSA-MO-00005",
    .region=REGION_EU, .required_firmware="10.01", .category=CAT_GAME,
    .publisher="Salt & Banner", .release_year=2024,
    .description="Turn-based naval empire. Starve ports, forge truces.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+11,
    .dlcs={"CUSA-MO-00005-dlc1"}, .dlc_count=1,
    V1("CUSA-MO-00005-fpkg",FMT_FPKG,(uint64_t)(12.8*(double)GB),"1.08")
  },
  {
    .id="CUSA-MO-00005-dlc1", .title="Tide of Kings — Ivory Coast",
    .cover_seed="CUSA-MO-00005-dlc1", .parent_id="CUSA-MO-00005",
    .region=REGION_EU, .required_firmware="10.01", .category=CAT_DLC,
    .publisher="Salt & Banner", .release_year=2025,
    .description="Westward campaign with monsoon seasons and privateers.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+12,
    V1("CUSA-MO-00005-dlc1-fpkg",FMT_FPKG,(uint64_t)(2.6*(double)GB),"1.00")
  },
  /* ─── Nightshade Opera ────────────────────────────────────────────── */
  {
    .id="CUSA-MO-00006", .title="Nightshade Opera",
    .cover_seed="CUSA-MO-00006",
    .region=REGION_US, .required_firmware="10.01", .category=CAT_GAME,
    .publisher="Velvet Room", .release_year=2025,
    .description="A branching tragedy in a theatre that restages your regrets.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+13,
    V1("CUSA-MO-00006-fpkg",FMT_FPKG,(uint64_t)(28.3*(double)GB),"1.01")
  },
  /* ─── Iron Meridian ──────────────────────────────────────────────── */
  {
    .id="CUSA-MO-00007", .title="Iron Meridian",
    .cover_seed="CUSA-MO-00007",
    .region=REGION_US, .required_firmware="10.01", .category=CAT_GAME,
    .publisher="Red Meridian", .release_year=2025,
    .description="Squad FPS through a collapsing equatorial fortress.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+14,
    .updates={"CUSA-MO-00007-upd"}, .update_count=1,
    V2("CUSA-MO-00007-fpkg",FMT_FPKG,(uint64_t)(91.7*(double)GB),"1.00",
       "CUSA-MO-00007-dump",FMT_DUMP,(uint64_t)(94.1*(double)GB),"1.00",false,1.0)
  },
  {
    .id="CUSA-MO-00007-upd", .title="Iron Meridian Update 1.10",
    .cover_seed="CUSA-MO-00007-upd", .parent_id="CUSA-MO-00007",
    .region=REGION_US, .required_firmware="10.01", .category=CAT_UPDATE,
    .publisher="Red Meridian", .release_year=2026,
    .description="Co-op 4-player and anti-cheat-free LAN.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+15,
    V1("CUSA-MO-00007-upd-fpkg",FMT_FPKG,(uint64_t)(8.9*(double)GB),"1.10")
  },
  /* ─── Sakura Protocol ────────────────────────────────────────────── */
  {
    .id="CUSA-MO-00008", .title="Sakura Protocol",
    .cover_seed="CUSA-MO-00008",
    .region=REGION_JP, .required_firmware="7.61", .category=CAT_GAME,
    .publisher="Kuro Line", .release_year=2022,
    .description="JRPG of sworn blades and silent servers.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+16,
    .dlcs={"CUSA-MO-00008-dlc1"}, .dlc_count=1,
    .backports={"CUSA-MO-00008-bp"}, .backport_count=1,
    V2("CUSA-MO-00008-fpkg",FMT_FPKG,(uint64_t)(45.2*(double)GB),"1.22",
       "CUSA-MO-00008-rar",FMT_RAR,(uint64_t)(21.4*(double)GB),"1.22",true,2.11)
  },
  {
    .id="CUSA-MO-00008-bp", .title="Sakura Protocol Backport 10.01",
    .cover_seed="CUSA-MO-00008-bp", .parent_id="CUSA-MO-00008",
    .region=REGION_JP, .required_firmware="10.01", .category=CAT_BACKPORT,
    .publisher="MO Labs", .release_year=2026,
    .description="7.61 -> 10.01 backport with DualSense haptics restored.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+17,
    V1("CUSA-MO-00008-bp-fpkg",FMT_FPKG,(uint64_t)(310*(double)MB),"10.01")
  },
  {
    .id="CUSA-MO-00008-dlc1", .title="Sakura Protocol — Winter Kernel",
    .cover_seed="CUSA-MO-00008-dlc1", .parent_id="CUSA-MO-00008",
    .region=REGION_JP, .required_firmware="7.61", .category=CAT_DLC,
    .publisher="Kuro Line", .release_year=2023,
    .description="Post-game dungeon and new party member.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+18,
    V1("CUSA-MO-00008-dlc1-fpkg",FMT_FPKG,(uint64_t)(5.5*(double)GB),"1.00")
  },
  /* ─── Sandveil ───────────────────────────────────────────────────── */
  {
    .id="CUSA-MO-00009", .title="Sandveil",
    .cover_seed="CUSA-MO-00009",
    .region=REGION_US, .required_firmware="9.00", .category=CAT_GAME,
    .publisher="Mirage Works", .release_year=2024,
    .description="Survive a desert that edits itself overnight.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+19,
    .backports={"CUSA-MO-00009-bp"}, .backport_count=1,
    V1("CUSA-MO-00009-fpkg",FMT_FPKG,(uint64_t)(33.9*(double)GB),"1.05")
  },
  {
    .id="CUSA-MO-00009-bp", .title="Sandveil Backport 10.01",
    .cover_seed="CUSA-MO-00009-bp", .parent_id="CUSA-MO-00009",
    .region=REGION_US, .required_firmware="10.01", .category=CAT_BACKPORT,
    .publisher="MO Labs", .release_year=2026,
    .description="9.00 dump backport for 10.01 with save conversion.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+20,
    V1("CUSA-MO-00009-bp-fpkg",FMT_FPKG,(uint64_t)(95*(double)MB),"10.01")
  },
  /* ─── Remaining titles (Zero Atelier through System Rescue Pack) ── */
  {
    .id="CUSA-MO-00010", .title="Zero Atelier", .cover_seed="CUSA-MO-00010",
    .region=REGION_EU, .required_firmware="10.01", .category=CAT_GAME,
    .publisher="Quiet Grid", .release_year=2025,
    .description="Minimalist gallery puzzles. One room, one rule, one lie.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+21,
    V1("CUSA-MO-00010-fpkg",FMT_FPKG,(uint64_t)(4.2*(double)GB),"1.00")
  },
  {
    .id="CUSA-MO-00011", .title="Vesper Raid", .cover_seed="CUSA-MO-00011",
    .region=REGION_US, .required_firmware="10.01", .category=CAT_GAME,
    .publisher="Night Cohort", .release_year=2025,
    .description="Three-player heist FPS. Plan in silence, execute in 90 seconds.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+22,
    .dlcs={"CUSA-MO-00011-dlc1"}, .dlc_count=1,
    V2("CUSA-MO-00011-fpkg",FMT_FPKG,(uint64_t)(48.6*(double)GB),"1.03",
       "CUSA-MO-00011-ffpfs",FMT_FFPFS,(uint64_t)(48.6*(double)GB),"1.03",false,1.0)
  },
  {
    .id="CUSA-MO-00011-dlc1", .title="Vesper Raid — Embassy Set",
    .cover_seed="CUSA-MO-00011-dlc1", .parent_id="CUSA-MO-00011",
    .region=REGION_US, .required_firmware="10.01", .category=CAT_DLC,
    .publisher="Night Cohort", .release_year=2026,
    .description="Four new maps and a silent-drill gadget.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+23,
    V1("CUSA-MO-00011-dlc1-fpkg",FMT_FPKG,(uint64_t)(7.1*(double)GB),"1.00")
  },
  {
    .id="CUSA-MO-00012", .title="Lunar Forge", .cover_seed="CUSA-MO-00012",
    .region=REGION_ASIA, .required_firmware="10.01", .category=CAT_GAME,
    .publisher="Orbit Kiln", .release_year=2024,
    .description="Craft colony tools from moon-dust alloys.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+24,
    V1("CUSA-MO-00012-fpkg",FMT_FPKG,(uint64_t)(22.1*(double)GB),"1.07")
  },
  {
    .id="CUSA-MO-00013", .title="Blackwater Legacy",
    .cover_seed="CUSA-MO-00013",
    .region=REGION_EU, .required_firmware="10.01", .category=CAT_GAME,
    .publisher="Salt & Banner", .release_year=2025,
    .description="Folk horror on a flooded estate.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+25,
    V2("CUSA-MO-00013-fpkg",FMT_FPKG,(uint64_t)(31.5*(double)GB),"1.00",
       "CUSA-MO-00013-zip",FMT_ZIP,(uint64_t)(14.8*(double)GB),"1.00",true,2.13)
  },
  {
    .id="CUSA-MO-00014", .title="Pulse Racer", .cover_seed="CUSA-MO-00014",
    .region=REGION_US, .required_firmware="10.01", .category=CAT_GAME,
    .publisher="Apex Circuit", .release_year=2026,
    .description="Arcade anti-grav sprints. Tracks fold.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+26,
    V1("CUSA-MO-00014-fpkg",FMT_FPKG,(uint64_t)(8.7*(double)GB),"1.00")
  },
  {
    .id="CUSA-MO-00015", .title="Crownbreaker", .cover_seed="CUSA-MO-00015",
    .region=REGION_EU, .required_firmware="9.00", .category=CAT_GAME,
    .publisher="Ash Liturgy", .release_year=2024,
    .description="A brutal pilgrimage through a kingdom that crowns whoever survives.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+27,
    .backports={"CUSA-MO-00015-bp"}, .backport_count=1,
    V1("CUSA-MO-00015-fpkg",FMT_FPKG,(uint64_t)(62.4*(double)GB),"1.18")
  },
  {
    .id="CUSA-MO-00015-bp", .title="Crownbreaker Backport 10.01",
    .cover_seed="CUSA-MO-00015-bp", .parent_id="CUSA-MO-00015",
    .region=REGION_EU, .required_firmware="10.01", .category=CAT_BACKPORT,
    .publisher="MO Labs", .release_year=2026,
    .description="9.00 -> 10.01 backport. Adaptive triggers remapped.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+28,
    V1("CUSA-MO-00015-bp-fpkg",FMT_FPKG,(uint64_t)(210*(double)MB),"10.01")
  },
  {
    .id="CUSA-MO-00016", .title="Echoes of Riyadh",
    .cover_seed="CUSA-MO-00016",
    .region=REGION_ASIA, .required_firmware="10.01", .category=CAT_GAME,
    .publisher="Mirage Works", .release_year=2025,
    .description="A night walk through a city of courtyards and radio ghosts.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+29,
    V1("CUSA-MO-00016-fpkg",FMT_FPKG,(uint64_t)(19.8*(double)GB),"1.02")
  },
  {
    .id="CUSA-MO-00017", .title="Amazonas", .cover_seed="CUSA-MO-00017",
    .region=REGION_US, .required_firmware="10.01", .category=CAT_GAME,
    .publisher="Canopy North", .release_year=2025,
    .description="River expedition sim. Chart unmapped forks.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+30,
    V1("CUSA-MO-00017-fpkg",FMT_FPKG,(uint64_t)(41.3*(double)GB),"1.00")
  },
  {
    .id="CUSA-MO-00018", .title="Neon Shibuya", .cover_seed="CUSA-MO-00018",
    .region=REGION_JP, .required_firmware="10.01", .category=CAT_GAME,
    .publisher="Kuro Line", .release_year=2026,
    .description="Street-level brawler through a crossing that never empties.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+31,
    V2("CUSA-MO-00018-fpkg",FMT_FPKG,(uint64_t)(55.0*(double)GB),"1.00",
       "CUSA-MO-00018-ffpkg",FMT_FFPKG,(uint64_t)(55.0*(double)GB),"1.00",false,1.0)
  },
  {
    .id="CUSA-MO-00019", .title="Frostbound", .cover_seed="CUSA-MO-00019",
    .region=REGION_EU, .required_firmware="10.01", .category=CAT_GAME,
    .publisher="Quiet Grid", .release_year=2025,
    .description="Survival on a research ice-shelf. The storm is a character.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+32,
    .updates={"CUSA-MO-00019-upd"}, .update_count=1,
    V1("CUSA-MO-00019-fpkg",FMT_FPKG,(uint64_t)(36.2*(double)GB),"1.06")
  },
  {
    .id="CUSA-MO-00019-upd", .title="Frostbound Update 1.06",
    .cover_seed="CUSA-MO-00019-upd", .parent_id="CUSA-MO-00019",
    .region=REGION_EU, .required_firmware="10.01", .category=CAT_UPDATE,
    .publisher="Quiet Grid", .release_year=2026,
    .description="Co-op two-player and aurora photo mode.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+33,
    V1("CUSA-MO-00019-upd-fpkg",FMT_FPKG,(uint64_t)(1.9*(double)GB),"1.06")
  },
  {
    .id="CUSA-MO-00020", .title="Solaris Command",
    .cover_seed="CUSA-MO-00020",
    .region=REGION_US, .required_firmware="8.00", .category=CAT_GAME,
    .publisher="Orbit Kiln", .release_year=2023,
    .description="Fleet tactics in a dying solar system. Panic is physics.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+34,
    .backports={"CUSA-MO-00020-bp"}, .backport_count=1,
    V2("CUSA-MO-00020-fpkg",FMT_FPKG,(uint64_t)(67.8*(double)GB),"1.40",
       "CUSA-MO-00020-7z",FMT_7Z,(uint64_t)(29.9*(double)GB),"1.40",true,2.27)
  },
  {
    .id="CUSA-MO-00020-bp", .title="Solaris Command Backport 10.01",
    .cover_seed="CUSA-MO-00020-bp", .parent_id="CUSA-MO-00020",
    .region=REGION_US, .required_firmware="10.01", .category=CAT_BACKPORT,
    .publisher="MO Labs", .release_year=2026,
    .description="8.00 -> 10.01 backport. 120 Hz output unlocked.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+35,
    V1("CUSA-MO-00020-bp-fpkg",FMT_FPKG,(uint64_t)(420*(double)MB),"10.01")
  },
  {
    .id="CUSA-MO-00021", .title="Red Monolith", .cover_seed="CUSA-MO-00021",
    .region=REGION_US, .required_firmware="10.01", .category=CAT_GAME,
    .publisher="Ash Liturgy", .release_year=2026,
    .description="A short, sharp indie about a tower that only exists while you look at it.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+36,
    V1("CUSA-MO-00021-fpkg",FMT_FPKG,(uint64_t)(2.1*(double)GB),"1.00")
  },
  {
    .id="CUSA-MO-00022", .title="Kite & Cannon",
    .cover_seed="CUSA-MO-00022",
    .region=REGION_EU, .required_firmware="10.01", .category=CAT_GAME,
    .publisher="Apex Circuit", .release_year=2025,
    .description="Aerial sports with siege weapons.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+37,
    V1("CUSA-MO-00022-fpkg",FMT_FPKG,(uint64_t)(29.4*(double)GB),"1.01")
  },
  {
    .id="CUSA-MO-00023", .title="System Rescue Pack",
    .cover_seed="CUSA-MO-00023",
    .region=REGION_US, .required_firmware="10.01", .category=CAT_PACKAGE,
    .publisher="MO Labs", .release_year=2026,
    .description="Homebrew utilities: cover cache rebuild, DPI helper, USB formatter.",
    .library_id=MO_MAIN_LIBRARY_ID, .added_at=T0+38,
    V1("CUSA-MO-00023-fpkg",FMT_FPKG,(uint64_t)(84*(double)MB),"1.0.1")
  },
};

#define TITLE_COUNT ((int)(sizeof(s_titles)/sizeof(s_titles[0])))

int mo_builtin_title_count(void) { return TITLE_COUNT; }

const mo_title_t *mo_builtin_title(int index) {
    if (index < 0 || index >= TITLE_COUNT) return NULL;
    return &s_titles[index];
}
