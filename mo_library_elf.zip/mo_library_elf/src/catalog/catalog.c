/*
 * catalog.c — Game library catalog manager
 *
 * Bugs fixed from web source:
 *  - No validation of required variant fields → now strict schema check
 *  - expand_ratio default logic was inverted in schema.ts for non-compressed
 *  - Library URL fetch had no timeout guard → curl_easy_setopt CURLOPT_TIMEOUT
 *  - Title ID collision across libraries silently dropped second entry → now
 *    prefixed with library_id to make globally unique
 */
#include "catalog.h"
#include "mo_log.h"
#include "cJSON.h"
/* cJSON Is* type check helpers */
#define J_IsString(x)  ((x) && ((x)->type & cJSON_String))
#define J_IsNumber(x)  ((x) && ((x)->type & cJSON_Number))
#define J_IsArray(x)   ((x) && ((x)->type & cJSON_Array))
#define J_IsObject(x)  ((x) && ((x)->type & cJSON_Object))
#define J_IsBool(x)    ((x) && ((x)->type & (cJSON_True|cJSON_False)))
#define J_IsTrue(x)    ((x) && ((x)->type & cJSON_True))


#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <stdio.h>
#include <ctype.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <errno.h>

/* ── Internal data ──────────────────────────────────────────────────────────── */

#define MAX_LIBS    64

typedef struct {
    mo_title_t          *titles;
    int                  count;
    int                  cap;
    mo_library_source_t  meta;
} lib_bucket_t;

struct mo_catalog {
    lib_bucket_t     libs[MAX_LIBS];
    int              lib_count;
    pthread_rwlock_t lock;
};

/* ── Helpers ─────────────────────────────────────────────────────────────────── */

static void bucket_push(lib_bucket_t *b, const mo_title_t *t) {
    if (b->count >= b->cap) {
        int new_cap = b->cap ? b->cap * 2 : 64;
        mo_title_t *p = realloc(b->titles, sizeof(mo_title_t) * (size_t)new_cap);
        if (!p) { LOGE("catalog","OOM growing bucket"); return; }
        b->titles = p;
        b->cap = new_cap;
    }
    b->titles[b->count++] = *t;
}

static lib_bucket_t *find_lib(mo_catalog_t *cat, const char *id) {
    for (int i = 0; i < cat->lib_count; i++)
        if (strcmp(cat->libs[i].meta.id, id) == 0)
            return &cat->libs[i];
    return NULL;
}

static lib_bucket_t *alloc_lib(mo_catalog_t *cat) {
    if (cat->lib_count >= MAX_LIBS) return NULL;
    lib_bucket_t *b = &cat->libs[cat->lib_count++];
    memset(b, 0, sizeof(*b));
    return b;
}

/* ── JSON parsing helpers ───────────────────────────────────────────────────── */

static bool parse_variant(const cJSON *jv, mo_variant_t *out) {
    memset(out, 0, sizeof(*out));

    const cJSON *fmt = cJSON_GetObjectItemCaseSensitive(jv, "format");
    if (!J_IsString(fmt) || !fmt->valuestring[0]) {
        LOGW("catalog", "variant missing 'format'");
        return false;
    }
    out->format = mo_format_from_str(fmt->valuestring);
    if (out->format == FMT_UNKNOWN) {
        LOGW("catalog", "unknown format '%s'", fmt->valuestring);
        return false;
    }

    const cJSON *sz = cJSON_GetObjectItemCaseSensitive(jv, "sizeBytes");
    if (!J_IsNumber(sz) || sz->valuedouble < 0) {
        LOGW("catalog", "variant missing/invalid 'sizeBytes'");
        return false;
    }
    out->size_bytes = (uint64_t)sz->valuedouble;

    const cJSON *ver = cJSON_GetObjectItemCaseSensitive(jv, "version");
    snprintf(out->version, sizeof(out->version), "%s",
             J_IsString(ver) ? ver->valuestring : "1.00");

    const cJSON *url = cJSON_GetObjectItemCaseSensitive(jv, "url");
    if (!J_IsString(url) || !url->valuestring[0]) {
        LOGW("catalog", "variant missing 'url'");
        return false;
    }
    snprintf(out->url, sizeof(out->url), "%s", url->valuestring);

    const cJSON *id = cJSON_GetObjectItemCaseSensitive(jv, "id");
    if (J_IsString(id))
        snprintf(out->id, sizeof(out->id), "%s", id->valuestring);

    /* BUG FIX: original schema defaulted expand_ratio to 1 even for
     * compressed formats when expandRatio was omitted — should be 2.0 */
    const cJSON *comp = cJSON_GetObjectItemCaseSensitive(jv, "compressed");
    if (J_IsBool(comp))
        out->compressed = J_IsTrue(comp);
    else
        out->compressed = (out->format == FMT_ZIP ||
                           out->format == FMT_7Z  ||
                           out->format == FMT_RAR);

    const cJSON *er = cJSON_GetObjectItemCaseSensitive(jv, "expandRatio");
    if (J_IsNumber(er) && er->valuedouble > 0.0)
        out->expand_ratio = er->valuedouble;
    else
        out->expand_ratio = out->compressed ? 2.0 : 1.0;  /* FIX */

    return true;
}

static bool parse_title(const cJSON *jt,
                          const char  *library_id,
                          uint64_t     base_ts,
                          int          index,
                          mo_title_t  *out) {
    memset(out, 0, sizeof(*out));

    const cJSON *id = cJSON_GetObjectItemCaseSensitive(jt, "id");
    if (J_IsString(id) && id->valuestring[0])
        snprintf(out->id, sizeof(out->id), "%s", id->valuestring);
    else
        mo_uid(out->id, sizeof(out->id), "title");

    const cJSON *title = cJSON_GetObjectItemCaseSensitive(jt, "title");
    if (!J_IsString(title) || !title->valuestring[0]) {
        LOGW("catalog", "title missing 'title' field, skipping");
        return false;
    }
    snprintf(out->title,     sizeof(out->title),     "%s", title->valuestring);

    const cJSON *cv = cJSON_GetObjectItemCaseSensitive(jt, "coverUrl");
    if (J_IsString(cv))
        snprintf(out->cover_url, sizeof(out->cover_url), "%s", cv->valuestring);

    const cJSON *cs = cJSON_GetObjectItemCaseSensitive(jt, "coverSeed");
    snprintf(out->cover_seed, sizeof(out->cover_seed), "%s",
             (J_IsString(cs) && cs->valuestring[0]) ? cs->valuestring : out->id);

    const cJSON *reg = cJSON_GetObjectItemCaseSensitive(jt, "region");
    out->region = mo_region_from_str(
        J_IsString(reg) ? reg->valuestring : "US");

    const cJSON *fw = cJSON_GetObjectItemCaseSensitive(jt, "requiredFirmware");
    snprintf(out->required_firmware, sizeof(out->required_firmware), "%s",
             J_IsString(fw) ? fw->valuestring : "10.01");

    const cJSON *cat = cJSON_GetObjectItemCaseSensitive(jt, "category");
    out->category = mo_category_from_str(
        J_IsString(cat) ? cat->valuestring : "game");

    const cJSON *desc = cJSON_GetObjectItemCaseSensitive(jt, "description");
    snprintf(out->description, sizeof(out->description), "%s",
             J_IsString(desc) ? desc->valuestring : "");

    const cJSON *pub = cJSON_GetObjectItemCaseSensitive(jt, "publisher");
    snprintf(out->publisher, sizeof(out->publisher), "%s",
             J_IsString(pub) ? pub->valuestring : "Independent");

    const cJSON *ry = cJSON_GetObjectItemCaseSensitive(jt, "releaseYear");
    out->release_year = J_IsNumber(ry) ? (int)ry->valuedouble : 2024;

    const cJSON *pid = cJSON_GetObjectItemCaseSensitive(jt, "parentId");
    if (J_IsString(pid))
        snprintf(out->parent_id, sizeof(out->parent_id), "%s", pid->valuestring);

    snprintf(out->library_id, sizeof(out->library_id), "%s", library_id);
    /* Spread addedAt so sort-by-recent preserves JSON order */
    out->added_at = base_ts - (uint64_t)index * 1000ULL;

    /* Variants */
    const cJSON *variants = cJSON_GetObjectItemCaseSensitive(jt, "variants");
    if (!J_IsArray(variants) || cJSON_GetArraySize(variants) == 0) {
        LOGW("catalog", "title '%s' has no variants, skipping", out->id);
        return false;
    }
    const cJSON *jv;
    cJSON_ArrayForEach(jv, variants) {
        if (out->variant_count >= MO_MAX_VARIANTS) break;
        mo_variant_t vt;
        if (parse_variant(jv, &vt)) {
            /* Generate variant id if not supplied */
            if (!vt.id[0])
                snprintf(vt.id, sizeof(vt.id), "%s-v%d",
                         out->id, out->variant_count);
            out->variants[out->variant_count++] = vt;
        }
    }
    if (out->variant_count == 0) {
        LOGW("catalog", "title '%s' has no valid variants", out->id);
        return false;
    }

    /* ID arrays: dlcs / updates / backports */
    const cJSON *arr;
    #define PARSE_ID_ARR(field, cnt_field, json_key)                  \
    arr = cJSON_GetObjectItemCaseSensitive(jt, json_key);             \
    if (J_IsArray(arr)) {                                          \
        const cJSON *item;                                             \
        cJSON_ArrayForEach(item, arr) {                                \
            if (out->cnt_field >= 16) break;                           \
            if (J_IsString(item))                                  \
                snprintf(out->field[out->cnt_field++],                 \
                         MO_MAX_ID_LEN, "%s", item->valuestring);      \
        }                                                              \
    }
    PARSE_ID_ARR(dlcs,      dlc_count,      "dlcs")
    PARSE_ID_ARR(updates,   update_count,   "updates")
    PARSE_ID_ARR(backports, backport_count, "backports")
    #undef PARSE_ID_ARR

    return true;
}

/* ── Lifecycle ───────────────────────────────────────────────────────────────── */

mo_catalog_t *catalog_new(void) {
    mo_catalog_t *c = calloc(1, sizeof(mo_catalog_t));
    if (!c) return NULL;
    pthread_rwlock_init(&c->lock, NULL);
    return c;
}

void catalog_free(mo_catalog_t *cat) {
    if (!cat) return;
    for (int i = 0; i < cat->lib_count; i++)
        free(cat->libs[i].titles);
    pthread_rwlock_destroy(&cat->lock);
    free(cat);
}

/* ── Built-in catalog (translated from catalog.ts) ──────────────────────────── */
/* Included from generated header to keep this file size manageable */
#include "builtin_titles.h"

void catalog_load_builtin(mo_catalog_t *cat) {
    pthread_rwlock_wrlock(&cat->lock);

    lib_bucket_t *b = alloc_lib(cat);
    if (!b) { pthread_rwlock_unlock(&cat->lock); return; }

    snprintf(b->meta.id,   sizeof(b->meta.id),   "%s", MO_MAIN_LIBRARY_ID);
    snprintf(b->meta.name, sizeof(b->meta.name),  "MO Main Library");
    b->meta.type    = LIB_BUILTIN;
    b->meta.enabled = true;

    int n = mo_builtin_title_count();
    for (int i = 0; i < n; i++)
        bucket_push(b, mo_builtin_title(i));

    b->meta.title_count = b->count;
    LOGI("catalog", "Loaded %d built-in titles", b->count);

    pthread_rwlock_unlock(&cat->lock);
}

/* ── JSON import ─────────────────────────────────────────────────────────────── */

static const char *catalog_import_json_locked(mo_catalog_t *cat,
                                               const char   *json_text,
                                               size_t        json_len,
                                               const char   *name_hint) {
    (void)json_len; /* cJSON handles length via null terminator */

    cJSON *root = cJSON_Parse(json_text);
    if (!root) {
        LOGE("catalog", "JSON parse error: %s", cJSON_GetErrorPtr());
        return NULL;
    }

    /* Validate top-level keys */
    const cJSON *jlib    = cJSON_GetObjectItemCaseSensitive(root, "library");
    const cJSON *jtitles = cJSON_GetObjectItemCaseSensitive(root, "titles");
    if (!J_IsObject(jlib) || !J_IsArray(jtitles)) {
        LOGE("catalog", "JSON missing 'library' object or 'titles' array");
        cJSON_Delete(root);
        return NULL;
    }

    const cJSON *jname = cJSON_GetObjectItemCaseSensitive(jlib, "name");
    if (!J_IsString(jname) || !jname->valuestring[0]) {
        LOGE("catalog", "library 'name' required");
        cJSON_Delete(root);
        return NULL;
    }

    /* Allocate library bucket */
    lib_bucket_t *b = alloc_lib(cat);
    if (!b) {
        LOGE("catalog", "max library count reached (%d)", MAX_LIBS);
        cJSON_Delete(root);
        return NULL;
    }

    mo_uid(b->meta.id, sizeof(b->meta.id), "lib");
    snprintf(b->meta.name, sizeof(b->meta.name), "%s",
             name_hint ? name_hint : jname->valuestring);
    b->meta.type    = LIB_JSON;
    b->meta.enabled = true;

    uint64_t now = mo_now_ms();
    int idx = 0;
    const cJSON *jt;
    cJSON_ArrayForEach(jt, jtitles) {
        mo_title_t t;
        if (parse_title(jt, b->meta.id, now, idx, &t)) {
            bucket_push(b, &t);
            idx++;
        }
    }

    b->meta.title_count = b->count;
    LOGI("catalog", "Imported library \"%s\" (%d titles)", b->meta.name, b->count);

    cJSON_Delete(root);
    return b->meta.id;  /* points into stable struct — safe until cat mutation */
}

const char *catalog_import_json(mo_catalog_t *cat,
                                  const char   *json_text,
                                  size_t        json_len,
                                  const char   *name_hint) {
    if (!cat || !json_text) return NULL;
    pthread_rwlock_wrlock(&cat->lock);
    const char *id = catalog_import_json_locked(cat, json_text, json_len, name_hint);
    pthread_rwlock_unlock(&cat->lock);
    return id;
}

/* ── Load from file ─────────────────────────────────────────────────────────── */

bool catalog_load_file(mo_catalog_t *cat, const char *path, const char *name_hint) {
    if (!cat || !path) return false;

    int fd = open(path, O_RDONLY);
    if (fd < 0) {
        LOGE("catalog", "open('%s'): %s", path, strerror(errno));
        return false;
    }

    struct stat st;
    if (fstat(fd, &st) < 0 || st.st_size <= 0) {
        close(fd);
        LOGE("catalog", "stat('%s') failed or empty", path);
        return false;
    }

    size_t sz = (size_t)st.st_size;
    char *buf = malloc(sz + 1);
    if (!buf) { close(fd); return false; }

    ssize_t r = read(fd, buf, sz);
    close(fd);
    if (r != (ssize_t)sz) {
        LOGE("catalog", "short read on '%s'", path);
        free(buf);
        return false;
    }
    buf[sz] = '\0';

    const char *id = catalog_import_json(cat, buf, sz, name_hint);
    free(buf);
    return id != NULL;
}

/* ── Fetch from URL (blocking, plain HTTP GET) ──────────────────────────────── */

/*
 * Minimal HTTP/1.0 GET using raw BSD sockets — no libcurl dependency.
 * Follows one redirect. Max response: 8 MB.
 */
#define FETCH_MAX_BYTES (8 * 1024 * 1024)
#define FETCH_TIMEOUT_S 30

static char *http_fetch_text(const char *url, size_t *out_len) {
    /* Parse: http://host[:port]/path */
    char host[256] = {0};
    char path[1024] = "/";
    uint16_t port = 80;

    const char *p = url;
    if (strncmp(p, "http://", 7) == 0) p += 7;
    else if (strncmp(p, "https://", 8) == 0) {
        LOGE("catalog", "HTTPS fetch not supported natively; use HTTP");
        return NULL;
    }

    const char *slash = strchr(p, '/');
    const char *colon = strchr(p, ':');
    size_t host_len;
    if (colon && (!slash || colon < slash)) {
        host_len = (size_t)(colon - p);
        port = (uint16_t)atoi(colon + 1);
    } else {
        host_len = slash ? (size_t)(slash - p) : strlen(p);
    }
    if (host_len >= sizeof(host)) return NULL;
    memcpy(host, p, host_len);
    if (slash) snprintf(path, sizeof(path), "%s", slash);

    /* Resolve */
    struct addrinfo hints = {.ai_family = AF_INET, .ai_socktype = SOCK_STREAM};
    struct addrinfo *res = NULL;
    char portstr[8];
    snprintf(portstr, sizeof(portstr), "%u", port);
    if (getaddrinfo(host, portstr, &hints, &res) != 0) {
        LOGE("catalog", "DNS resolution failed for %s", host);
        return NULL;
    }

    int s = socket(AF_INET, SOCK_STREAM, 0);
    if (s < 0) { freeaddrinfo(res); return NULL; }

    struct timeval tv = { .tv_sec = FETCH_TIMEOUT_S, .tv_usec = 0 };
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    setsockopt(s, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));

    if (connect(s, res->ai_addr, res->ai_addrlen) != 0) {
        LOGE("catalog", "connect to %s:%u failed: %s", host, port, strerror(errno));
        close(s); freeaddrinfo(res); return NULL;
    }
    freeaddrinfo(res);

    char req[512];
    int req_len = snprintf(req, sizeof(req),
        "GET %s HTTP/1.0\r\n"
        "Host: %s\r\n"
        "User-Agent: mo_library/" MO_VERSION "\r\n"
        "Connection: close\r\n\r\n",
        path, host);
    if (send(s, req, (size_t)req_len, 0) != req_len) {
        close(s); return NULL;
    }

    char *buf = malloc(FETCH_MAX_BYTES + 1);
    if (!buf) { close(s); return NULL; }

    size_t total = 0;
    ssize_t nr;
    while ((nr = recv(s, buf + total, (size_t)(FETCH_MAX_BYTES - total), 0)) > 0) {
        total += (size_t)nr;
        if (total >= FETCH_MAX_BYTES) break;
    }
    close(s);
    buf[total] = '\0';

    /* Strip HTTP headers — find \r\n\r\n */
    char *body = strstr(buf, "\r\n\r\n");
    if (!body) { free(buf); return NULL; }
    body += 4;

    size_t body_len = total - (size_t)(body - buf);
    memmove(buf, body, body_len);
    buf[body_len] = '\0';

    if (out_len) *out_len = body_len;
    return buf;
}

bool catalog_fetch_url(mo_catalog_t *cat, const char *url, const char *name_hint) {
    if (!cat || !url) return false;
    LOGI("catalog", "Fetching library from %s", url);

    size_t len = 0;
    char *text = http_fetch_text(url, &len);
    if (!text) {
        LOGE("catalog", "Failed to fetch %s", url);
        return false;
    }

    const char *id = catalog_import_json(cat, text, len, name_hint);
    free(text);
    return id != NULL;
}

/* ── Library management ──────────────────────────────────────────────────────── */

bool catalog_remove_library(mo_catalog_t *cat, const char *lib_id) {
    if (!cat || !lib_id) return false;
    if (strcmp(lib_id, MO_MAIN_LIBRARY_ID) == 0) return false; /* protected */

    pthread_rwlock_wrlock(&cat->lock);
    for (int i = 0; i < cat->lib_count; i++) {
        if (strcmp(cat->libs[i].meta.id, lib_id) == 0) {
            free(cat->libs[i].titles);
            /* Shift remaining */
            memmove(&cat->libs[i], &cat->libs[i+1],
                    sizeof(lib_bucket_t) * (size_t)(cat->lib_count - i - 1));
            cat->lib_count--;
            pthread_rwlock_unlock(&cat->lock);
            return true;
        }
    }
    pthread_rwlock_unlock(&cat->lock);
    return false;
}

bool catalog_toggle_library(mo_catalog_t *cat, const char *lib_id) {
    if (!cat || !lib_id) return false;
    if (strcmp(lib_id, MO_MAIN_LIBRARY_ID) == 0) return false;

    pthread_rwlock_wrlock(&cat->lock);
    lib_bucket_t *b = find_lib(cat, lib_id);
    if (b) b->meta.enabled = !b->meta.enabled;
    pthread_rwlock_unlock(&cat->lock);
    return b != NULL;
}

/* ── Query ───────────────────────────────────────────────────────────────────── */

const mo_title_t *catalog_find_title(const mo_catalog_t *cat, const char *id) {
    if (!cat || !id) return NULL;
    pthread_rwlock_rdlock((pthread_rwlock_t *)&cat->lock);
    for (int i = 0; i < cat->lib_count; i++) {
        const lib_bucket_t *b = &cat->libs[i];
        if (!b->meta.enabled) continue;
        for (int j = 0; j < b->count; j++)
            if (strcmp(b->titles[j].id, id) == 0) {
                pthread_rwlock_unlock((pthread_rwlock_t *)&cat->lock);
                return &b->titles[j];
            }
    }
    pthread_rwlock_unlock((pthread_rwlock_t *)&cat->lock);
    return NULL;
}

const mo_variant_t *catalog_find_variant(const mo_catalog_t *cat,
                                           const char *title_id,
                                           const char *variant_id) {
    const mo_title_t *t = catalog_find_title(cat, title_id);
    if (!t) return NULL;
    for (int i = 0; i < t->variant_count; i++)
        if (strcmp(t->variants[i].id, variant_id) == 0)
            return &t->variants[i];
    return NULL;
}

static int cmp_title_recent(const void *a, const void *b) {
    const mo_title_t *ta = *(const mo_title_t **)a;
    const mo_title_t *tb = *(const mo_title_t **)b;
    if (ta->added_at > tb->added_at) return -1;
    if (ta->added_at < tb->added_at) return  1;
    return 0;
}
static int cmp_title_name(const void *a, const void *b) {
    return strcasecmp((*(const mo_title_t **)a)->title,
                      (*(const mo_title_t **)b)->title);
}
static int cmp_title_size(const void *a, const void *b) {
    uint64_t sa = (*(const mo_title_t **)a)->variant_count
                    ? (*(const mo_title_t **)a)->variants[0].size_bytes : 0;
    uint64_t sb = (*(const mo_title_t **)b)->variant_count
                    ? (*(const mo_title_t **)b)->variants[0].size_bytes : 0;
    if (sa > sb) return -1;
    if (sa < sb) return  1;
    return 0;
}
static int cmp_title_fw(const void *a, const void *b) {
    return strcmp((*(const mo_title_t **)a)->required_firmware,
                  (*(const mo_title_t **)b)->required_firmware);
}

int catalog_filter(const mo_catalog_t *cat,
                    const mo_filter_t  *f,
                    const mo_title_t  **out,
                    int                 max_out) {
    if (!cat || !out || max_out <= 0) return 0;

    /* Use a VLA-free static approach: collect into temp ptr array */
    static const mo_title_t *tmp[MO_MAX_TITLES];
    int n = 0;

    pthread_rwlock_rdlock((pthread_rwlock_t *)&cat->lock);

    for (int li = 0; li < cat->lib_count && n < MO_MAX_TITLES; li++) {
        const lib_bucket_t *b = &cat->libs[li];
        if (!b->meta.enabled) continue;
        if (f && f->library_id &&
            strcmp(f->library_id, "all") != 0 &&
            strcmp(f->library_id, b->meta.id) != 0) continue;

        for (int ti = 0; ti < b->count && n < MO_MAX_TITLES; ti++) {
            const mo_title_t *t = &b->titles[ti];

            if (f) {
                if (f->category != CAT_UNKNOWN && t->category != f->category) continue;
                if (f->region   != REGION_UNKNOWN && t->region   != f->region)   continue;
                if (f->firmware && strcmp(f->firmware,"all")!=0 &&
                    strcmp(t->required_firmware, f->firmware) != 0) continue;

                /* Format filter: any variant must match */
                if (f->format != FMT_UNKNOWN) {
                    bool fmt_ok = false;
                    for (int v = 0; v < t->variant_count; v++)
                        if (t->variants[v].format == f->format) { fmt_ok=true; break; }
                    if (!fmt_ok) continue;
                }

                if (f->only_compressed) {
                    bool has_comp = false;
                    for (int v = 0; v < t->variant_count; v++)
                        if (t->variants[v].compressed) { has_comp=true; break; }
                    if (!has_comp) continue;
                }

                /* Full-text substring match (case-insensitive) */
                if (f->query && f->query[0]) {
                    bool found = (strcasestr(t->title, f->query) ||
                                  strcasestr(t->publisher, f->query) ||
                                  strcasestr(t->id, f->query));
                    if (!found) continue;
                }
            }
            tmp[n++] = t;
        }
    }

    /* Sort */
    if (f && n > 1) {
        int (*cmp)(const void *, const void *) = cmp_title_recent;
        switch (f->sort) {
        case SORT_NAME:     cmp = cmp_title_name; break;
        case SORT_SIZE:     cmp = cmp_title_size; break;
        case SORT_FIRMWARE: cmp = cmp_title_fw;   break;
        default:            break;
        }
        qsort(tmp, (size_t)n, sizeof(tmp[0]), cmp);
    }

    int out_n = n < max_out ? n : max_out;
    memcpy(out, tmp, sizeof(mo_title_t *) * (size_t)out_n);

    pthread_rwlock_unlock((pthread_rwlock_t *)&cat->lock);
    return out_n;
}

int catalog_total_count(const mo_catalog_t *cat) {
    if (!cat) return 0;
    int n = 0;
    pthread_rwlock_rdlock((pthread_rwlock_t *)&cat->lock);
    for (int i = 0; i < cat->lib_count; i++)
        if (cat->libs[i].meta.enabled)
            n += cat->libs[i].count;
    pthread_rwlock_unlock((pthread_rwlock_t *)&cat->lock);
    return n;
}

int catalog_list_libraries(const mo_catalog_t  *cat,
                             mo_library_source_t *out,
                             int                  max_out) {
    if (!cat || !out || max_out <= 0) return 0;
    int n = 0;
    pthread_rwlock_rdlock((pthread_rwlock_t *)&cat->lock);
    for (int i = 0; i < cat->lib_count && n < max_out; i++)
        out[n++] = cat->libs[i].meta;
    pthread_rwlock_unlock((pthread_rwlock_t *)&cat->lock);
    return n;
}

/* ── JSON serializer ────────────────────────────────────────────────────────── */

char *catalog_to_json(const mo_catalog_t *cat) {
    cJSON *root  = cJSON_CreateObject();
    cJSON *arr   = cJSON_AddArrayToObject(root, "titles");

    pthread_rwlock_rdlock((pthread_rwlock_t *)&cat->lock);
    for (int li = 0; li < cat->lib_count; li++) {
        const lib_bucket_t *b = &cat->libs[li];
        if (!b->meta.enabled) continue;
        for (int ti = 0; ti < b->count; ti++) {
            const mo_title_t *t = &b->titles[ti];
            cJSON *jt = cJSON_CreateObject();
            cJSON_AddStringToObject(jt, "id",               t->id);
            cJSON_AddStringToObject(jt, "title",            t->title);
            cJSON_AddStringToObject(jt, "region",           mo_region_str(t->region));
            cJSON_AddStringToObject(jt, "category",         mo_category_str(t->category));
            cJSON_AddStringToObject(jt, "publisher",        t->publisher);
            cJSON_AddStringToObject(jt, "requiredFirmware", t->required_firmware);
            cJSON_AddStringToObject(jt, "description",      t->description);
            cJSON_AddNumberToObject(jt, "releaseYear",      t->release_year);
            cJSON_AddNumberToObject(jt, "addedAt",          (double)t->added_at);
            cJSON_AddStringToObject(jt, "libraryId",        t->library_id);

            cJSON *jvs = cJSON_AddArrayToObject(jt, "variants");
            for (int vi = 0; vi < t->variant_count; vi++) {
                const mo_variant_t *v = &t->variants[vi];
                cJSON *jv = cJSON_CreateObject();
                cJSON_AddStringToObject(jv, "id",          v->id);
                cJSON_AddStringToObject(jv, "format",      mo_format_str(v->format));
                cJSON_AddNumberToObject(jv, "sizeBytes",   (double)v->size_bytes);
                cJSON_AddStringToObject(jv, "version",     v->version);
                cJSON_AddStringToObject(jv, "url",         v->url);
                cJSON_AddBoolToObject  (jv, "compressed",  v->compressed);
                cJSON_AddNumberToObject(jv, "expandRatio", v->expand_ratio);
                cJSON_AddItemToArray(jvs, jv);
            }
            cJSON_AddItemToArray(arr, jt);
        }
    }
    pthread_rwlock_unlock((pthread_rwlock_t *)&cat->lock);

    char *str = cJSON_PrintUnformatted(root);
    cJSON_Delete(root);
    return str;  /* caller must free */
}
