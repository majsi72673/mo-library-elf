/*
 * dns_server.c — Nano DNS sinkhole / update blocker
 *
 * RFC 1035 UDP DNS server running on port 53 (or DNS_LISTEN_PORT).
 * Answers NXDOMAIN for Sony OTA/telemetry domains.
 * Forwards everything else to the configured upstream resolver.
 *
 * Thread safety: all public functions are safe to call from any thread.
 * The sinkhole list is protected by a rwlock.
 */
#include "dns_server.h"
#include "mo_log.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <errno.h>
#include <sys/time.h>
#include <stdatomic.h>

/* ── DNS wire-format structures ─────────────────────────────────────────────── */

#pragma pack(push,1)
typedef struct {
    uint16_t id;
    uint16_t flags;
    uint16_t qdcount;
    uint16_t ancount;
    uint16_t nscount;
    uint16_t arcount;
} dns_hdr_t;
#pragma pack(pop)

/* Flags bit positions */
#define DNS_FLAG_QR      (1 << 15)   /* Query(0) / Response(1) */
#define DNS_FLAG_AA      (1 << 10)   /* Authoritative */
#define DNS_FLAG_TC      (1 << 9)    /* Truncated */
#define DNS_FLAG_RD      (1 << 8)    /* Recursion desired */
#define DNS_FLAG_RA      (1 << 7)    /* Recursion available */
#define DNS_RCODE_NXDOMAIN 3

/* ── Sinkhole list ───────────────────────────────────────────────────────────── */

#define MAX_SINKHOLE_ENTRIES 256
#define MAX_SUFFIX_LEN       128

static char             s_sinks[MAX_SINKHOLE_ENTRIES][MAX_SUFFIX_LEN];
static int              s_sink_count = 0;
static pthread_rwlock_t s_sink_lock  = PTHREAD_RWLOCK_INITIALIZER;

/* Sony OTA / telemetry / PSN update domains — curated list */
static const char *DEFAULT_SINKS[] = {
    /* Firmware update service */
    "fus01.ps5.playstation.net",
    "fus02.ps5.playstation.net",
    "fus03.ps5.playstation.net",
    /* Generic OTA endpoints */
    "ips.playstation.net",
    "iku.us.playstation.net",
    "iku.eu.playstation.net",
    "iku.jp.playstation.net",
    /* Download & update CDN */
    "dl.playstation.net",
    "gs-sec.ww.dl.playstation.net",
    "gs2.ww.dl.playstation.net",
    /* PSN auth / account (block OTA probes, not full PSN) */
    "ps5-update.playstation.net",
    "update.playstation.net",
    "system-update.playstation.net",
    /* Analytics / telemetry */
    "telemetry.playstation.com",
    "analytics.playstation.com",
    "collector.playstation.com",
    /* OCSP / cert checks that trigger update detection */
    "ocsp.sca1b.amazontrust.com",  /* only block PS-specific OCSP? */
    /* Sony corporate telemetry */
    "qos.prod.playstation.com",
    "beacon.playstation.com",
    NULL
};

static void load_default_sinks(void) {
    pthread_rwlock_wrlock(&s_sink_lock);
    for (int i = 0; DEFAULT_SINKS[i] && s_sink_count < MAX_SINKHOLE_ENTRIES; i++) {
        snprintf(s_sinks[s_sink_count++], MAX_SUFFIX_LEN, "%s", DEFAULT_SINKS[i]);
    }
    pthread_rwlock_unlock(&s_sink_lock);
}

/* ── Server state ────────────────────────────────────────────────────────────── */

static struct {
    pthread_t           thread;
    _Atomic bool        running;
    int                 sock_fd;
    mo_dns_config_t     cfg;

    /* Stats (relaxed — approximate is fine) */
    _Atomic uint64_t    queries_total;
    _Atomic uint64_t    queries_sinkholed;
    _Atomic uint64_t    queries_forwarded;
    _Atomic uint64_t    queries_failed;
} s_srv = { .running = false, .sock_fd = -1 };

/* ── DNS label decoder (name → dotted string) ───────────────────────────────── */

static int decode_name(const uint8_t *pkt, int pkt_len,
                        int offset, char *out, int out_sz) {
    int pos = offset;
    int written = 0;
    int loops = 0;

    while (pos < pkt_len && loops++ < 128) {
        uint8_t len = pkt[pos];

        if (len == 0) { pos++; break; }

        /* Pointer (compression) */
        if ((len & 0xC0) == 0xC0) {
            if (pos + 1 >= pkt_len) return -1;
            int ptr = ((len & 0x3F) << 8) | pkt[pos+1];
            pos += 2;
            decode_name(pkt, pkt_len, ptr, out + written, out_sz - written);
            return pos;  /* no further advance after pointer */
        }

        pos++;
        if (pos + len > pkt_len) return -1;
        if (written > 0 && written < out_sz - 1)
            out[written++] = '.';
        for (int i = 0; i < len && written < out_sz - 1; i++)
            out[written++] = (char)pkt[pos + i];
        pos += len;
    }
    if (written < out_sz) out[written] = '\0';
    return pos;
}

/* ── Sinkhole check ──────────────────────────────────────────────────────────── */

bool dns_would_sinkhole(const char *fqdn) {
    if (!fqdn) return false;
    pthread_rwlock_rdlock(&s_sink_lock);
    bool hit = false;
    for (int i = 0; i < s_sink_count && !hit; i++) {
        const char *suffix = s_sinks[i];
        size_t sf = strlen(suffix);
        size_t qf = strlen(fqdn);
        /* Exact match */
        if (strcasecmp(fqdn, suffix) == 0) { hit = true; break; }
        /* Suffix match: query ends with ".suffix" */
        if (qf > sf && fqdn[qf - sf - 1] == '.' &&
            strcasecmp(fqdn + qf - sf, suffix) == 0)
            hit = true;
    }
    pthread_rwlock_unlock(&s_sink_lock);
    return hit;
}

/* ── Build NXDOMAIN response ────────────────────────────────────────────────── */

static int build_nxdomain(const uint8_t *query, int qlen,
                            uint8_t *resp, int resp_sz) {
    if (qlen < (int)sizeof(dns_hdr_t) || resp_sz < qlen) return -1;

    memcpy(resp, query, (size_t)qlen);
    dns_hdr_t *hdr = (dns_hdr_t *)resp;

    uint16_t flags = ntohs(hdr->flags);
    flags |= DNS_FLAG_QR;   /* response */
    flags |= DNS_FLAG_AA;   /* authoritative */
    flags |= DNS_FLAG_RA;
    flags &= ~0x000F;       /* clear RCODE */
    flags |= DNS_RCODE_NXDOMAIN;
    hdr->flags   = htons(flags);
    hdr->ancount = 0;
    hdr->nscount = 0;
    hdr->arcount = 0;

    return qlen;
}

/* ── Forward query to upstream resolver ─────────────────────────────────────── */

static int forward_query(const uint8_t *query, int qlen,
                           uint8_t *resp, int resp_sz,
                           const char *upstream_ip, uint16_t upstream_port) {
    int s = socket(AF_INET, SOCK_DGRAM, 0);
    if (s < 0) return -1;

    struct timeval tv = { .tv_sec = DNS_TIMEOUT_MS / 1000,
                          .tv_usec = (DNS_TIMEOUT_MS % 1000) * 1000 };
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    setsockopt(s, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));

    struct sockaddr_in up = {
        .sin_family      = AF_INET,
        .sin_port        = htons(upstream_port),
    };
    if (inet_pton(AF_INET, upstream_ip, &up.sin_addr) != 1) {
        close(s); return -1;
    }

    if (sendto(s, query, (size_t)qlen, 0,
               (struct sockaddr *)&up, sizeof(up)) != qlen) {
        close(s); return -1;
    }

    socklen_t slen = sizeof(up);
    int n = (int)recvfrom(s, resp, (size_t)resp_sz, 0,
                           (struct sockaddr *)&up, &slen);
    close(s);
    return n;
}

/* ── Server main loop ────────────────────────────────────────────────────────── */

static void *dns_thread(void *arg) {
    (void)arg;

    uint8_t   buf[DNS_BUF_SIZE];
    uint8_t   resp[DNS_BUF_SIZE];
    char      qname[256];

    while (atomic_load(&s_srv.running)) {
        struct sockaddr_in cli;
        socklen_t cli_len = sizeof(cli);

        int n = (int)recvfrom(s_srv.sock_fd, buf, sizeof(buf), 0,
                               (struct sockaddr *)&cli, &cli_len);
        if (n < (int)sizeof(dns_hdr_t)) continue;

        atomic_fetch_add(&s_srv.queries_total, 1);

        /* Decode question name */
        qname[0] = '\0';
        decode_name(buf, n, (int)sizeof(dns_hdr_t), qname, sizeof(qname));

        int resp_len;

        if (dns_would_sinkhole(qname)) {
            if (s_srv.cfg.log_sinks)
                LOGW("dns", "SINKHOLE %s", qname);
            resp_len = build_nxdomain(buf, n, resp, sizeof(resp));
            atomic_fetch_add(&s_srv.queries_sinkholed, 1);
        } else {
            if (s_srv.cfg.log_queries)
                LOGI("dns", "FWD %s", qname);
            resp_len = forward_query(buf, n, resp, sizeof(resp),
                                      s_srv.cfg.upstream_ip,
                                      s_srv.cfg.upstream_port);
            if (resp_len < 0) {
                atomic_fetch_add(&s_srv.queries_failed, 1);
                continue;
            }
            atomic_fetch_add(&s_srv.queries_forwarded, 1);
        }

        if (resp_len > 0)
            sendto(s_srv.sock_fd, resp, (size_t)resp_len, 0,
                   (struct sockaddr *)&cli, cli_len);
    }

    close(s_srv.sock_fd);
    s_srv.sock_fd = -1;
    return NULL;
}

/* ── Public API ──────────────────────────────────────────────────────────────── */

bool dns_server_start(const mo_dns_config_t *cfg) {
    if (atomic_load(&s_srv.running)) return true;

    /* Defaults */
    if (cfg)
        s_srv.cfg = *cfg;
    else {
        s_srv.cfg.listen_port   = DNS_LISTEN_PORT;
        s_srv.cfg.upstream_port = DNS_UPSTREAM_PORT;
        s_srv.cfg.log_queries   = false;
        s_srv.cfg.log_sinks     = true;
        snprintf(s_srv.cfg.upstream_ip, sizeof(s_srv.cfg.upstream_ip),
                 "%s", DNS_UPSTREAM_IP);
    }

    load_default_sinks();

    s_srv.sock_fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (s_srv.sock_fd < 0) {
        LOGE("dns", "socket(): %s", strerror(errno));
        return false;
    }

    int one = 1;
    setsockopt(s_srv.sock_fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));

    struct sockaddr_in sa = {
        .sin_family      = AF_INET,
        .sin_port        = htons(s_srv.cfg.listen_port),
        .sin_addr.s_addr = INADDR_ANY,
    };

    if (bind(s_srv.sock_fd, (struct sockaddr *)&sa, sizeof(sa)) < 0) {
        LOGE("dns", "bind(:%u): %s", s_srv.cfg.listen_port, strerror(errno));
        close(s_srv.sock_fd); s_srv.sock_fd = -1;
        return false;
    }

    /* Set receive timeout so thread can check running flag */
    struct timeval tv = { .tv_sec = 1, .tv_usec = 0 };
    setsockopt(s_srv.sock_fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

    atomic_store(&s_srv.running, true);

    if (pthread_create(&s_srv.thread, NULL, dns_thread, NULL) != 0) {
        LOGE("dns", "pthread_create failed");
        atomic_store(&s_srv.running, false);
        close(s_srv.sock_fd); s_srv.sock_fd = -1;
        return false;
    }

    LOGI("dns", "DNS sinkhole running on :%u → upstream %s:%u",
         s_srv.cfg.listen_port,
         s_srv.cfg.upstream_ip,
         s_srv.cfg.upstream_port);
    return true;
}

void dns_server_stop(void) {
    if (!atomic_load(&s_srv.running)) return;
    atomic_store(&s_srv.running, false);
    pthread_join(s_srv.thread, NULL);
    LOGI("dns", "DNS server stopped");
}

bool dns_server_running(void) {
    return atomic_load(&s_srv.running);
}

bool dns_sinkhole_add(const char *suffix) {
    if (!suffix) return false;
    pthread_rwlock_wrlock(&s_sink_lock);
    if (s_sink_count >= MAX_SINKHOLE_ENTRIES) {
        pthread_rwlock_unlock(&s_sink_lock);
        return false;
    }
    snprintf(s_sinks[s_sink_count++], MAX_SUFFIX_LEN, "%s", suffix);
    pthread_rwlock_unlock(&s_sink_lock);
    LOGI("dns", "Sinkhole added: %s", suffix);
    return true;
}

bool dns_sinkhole_remove(const char *suffix) {
    if (!suffix) return false;
    bool found = false;
    pthread_rwlock_wrlock(&s_sink_lock);
    for (int i = 0; i < s_sink_count; i++) {
        if (strcasecmp(s_sinks[i], suffix) == 0) {
            memmove(s_sinks[i], s_sinks[i+1],
                    sizeof(s_sinks[0]) * (size_t)(s_sink_count - i - 1));
            s_sink_count--;
            found = true;
            break;
        }
    }
    pthread_rwlock_unlock(&s_sink_lock);
    return found;
}

void dns_get_stats(mo_dns_stats_t *out) {
    if (!out) return;
    out->queries_total     = atomic_load(&s_srv.queries_total);
    out->queries_sinkholed = atomic_load(&s_srv.queries_sinkholed);
    out->queries_forwarded = atomic_load(&s_srv.queries_forwarded);
    out->queries_failed    = atomic_load(&s_srv.queries_failed);
}

void dns_reset_stats(void) {
    atomic_store(&s_srv.queries_total,     0);
    atomic_store(&s_srv.queries_sinkholed, 0);
    atomic_store(&s_srv.queries_forwarded, 0);
    atomic_store(&s_srv.queries_failed,    0);
}
