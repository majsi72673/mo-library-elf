/*
 * download_manager.c — Three-stage download queue engine
 *
 * Stage 1: HTTP GET → temp file
 * Stage 2: Decompress (zip/7z/rar) if compressed variant
 * Stage 3: DPIv2 simulated install → /data|/mnt|/mnt/usb0
 *
 * Bugs fixed vs. original TypeScript store.ts:
 *
 * BUG-1 (storage accounting):
 *   Original added storage usage at job completion but INSIDE the job loop
 *   before updating the state, meaning that on rapid completions the delta
 *   could be applied multiple times (once per tick) causing negative free space.
 *   Fix: accumulate delta in local vars, apply once under lock after all jobs.
 *
 * BUG-2 (uninstall lower bound):
 *   Original had `Math.max(40 * GB, internalUsed - rec.sizeBytes)` — this
 *   arbitrary 40 GB floor prevented the counter from reaching 0 even on a
 *   fully empty drive, and made free-space checks unreliable.
 *   Fix: Math.max(0, used - size).
 *
 * BUG-3 (pause during installing):
 *   Original allowed pause while stage == 3 (installing), which could corrupt
 *   the DPI install state.  Fix: reject pause when status == JOB_INSTALLING.
 *
 * BUG-4 (resume when service stopped):
 *   Original called resumeAll() without checking serviceRunning, restarting
 *   downloads while the HTTP server was offline.
 *   Fix: dl_resume checks that the manager is running.
 */
#include "download_manager.h"
#include "archive_engine.h"
#include "fs_util.h"
#include "mo_log.h"

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <errno.h>
#include <sys/time.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <stdatomic.h>

/* ── Constants ───────────────────────────────────────────────────────────────── */

#define CHUNK_SIZE      (128 * 1024)   /* 128 KB receive buffer     */
#define SPEED_ALPHA     0.2            /* EWA coefficient for speed */
#define TICK_INTERVAL_MS 500           /* scheduler wakeup interval */

/* ── Storage state ───────────────────────────────────────────────────────────── */

typedef struct {
    uint64_t used;
    uint64_t total;
    bool     mounted;
} storage_t;

/* ── Manager internals ───────────────────────────────────────────────────────── */

struct mo_dl_manager {
    mo_catalog_t    *catalog;
    mo_job_t         jobs[MO_MAX_JOBS];
    int              job_count;
    pthread_mutex_t  lock;
    pthread_t        scheduler_thread;
    _Atomic bool     running;
    dl_event_cb      cb;
    void            *cb_ud;
    storage_t        internal;
    storage_t        usb;

    /* Installed records (title_id → record) */
    mo_installed_record_t installed[MO_MAX_TITLES];
    char                  installed_keys[MO_MAX_TITLES][MO_MAX_ID_LEN];
    int                   installed_count;
};

/* ── Helpers ─────────────────────────────────────────────────────────────────── */

static mo_job_t *find_job(mo_dl_manager_t *mgr, const char *id) {
    for (int i = 0; i < mgr->job_count; i++)
        if (strcmp(mgr->jobs[i].id, id) == 0)
            return &mgr->jobs[i];
    return NULL;
}

static mo_job_t *find_job_by_variant(mo_dl_manager_t *mgr, const char *vid) {
    for (int i = 0; i < mgr->job_count; i++)
        if (strcmp(mgr->jobs[i].variant_id, vid) == 0 &&
            mgr->jobs[i].status != JOB_COMPLETED &&
            mgr->jobs[i].status != JOB_CANCELLED &&
            mgr->jobs[i].status != JOB_FAILED)
            return &mgr->jobs[i];
    return NULL;
}

static storage_t *storage_for(mo_dl_manager_t *mgr, mo_install_path_t p) {
    return (p == INSTALL_USB) ? &mgr->usb : &mgr->internal;
}

static uint64_t storage_free(const storage_t *s) {
    return s->total > s->used ? s->total - s->used : 0;
}

static void fire_event(mo_dl_manager_t *mgr, const mo_job_t *job) {
    if (mgr->cb) mgr->cb(job, mgr->cb_ud);
}

/* ── HTTP download (stage 1) ─────────────────────────────────────────────────── */

static bool http_download(const char *url, const char *dest_path,
                            mo_job_t *job, mo_dl_manager_t *mgr) {
    /* Parse URL: http://host[:port]/path */
    char host[256] = {0};
    char path[2048] = "/";
    uint16_t port = 80;

    const char *p = url;
    if (strncmp(p,"http://",7)==0) p+=7;
    else {
        LOGE("dl","Only http:// URLs supported: %s", url);
        return false;
    }

    const char *slash = strchr(p,'/');
    const char *colon = strchr(p,':');
    size_t hl;
    if (colon && (!slash || colon < slash)) {
        hl = (size_t)(colon - p);
        port = (uint16_t)atoi(colon+1);
    } else {
        hl = slash ? (size_t)(slash-p) : strlen(p);
    }
    if (hl >= sizeof(host)) return false;
    memcpy(host, p, hl);
    if (slash) snprintf(path, sizeof(path), "%s", slash);

    struct addrinfo hints = {.ai_family=AF_INET,.ai_socktype=SOCK_STREAM};
    struct addrinfo *res = NULL;
    char ps[8]; snprintf(ps, sizeof(ps), "%u", port);
    if (getaddrinfo(host, ps, &hints, &res) != 0) {
        LOGE("dl","DNS failed: %s", host);
        return false;
    }

    int s = socket(AF_INET, SOCK_STREAM, 0);
    if (s < 0) { freeaddrinfo(res); return false; }

    /* Store socket so cancel can close it */
    pthread_mutex_lock(&mgr->lock);
    job->sock_fd = s;
    pthread_mutex_unlock(&mgr->lock);

    struct timeval tv = {.tv_sec=30};
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    setsockopt(s, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));

    if (connect(s, res->ai_addr, res->ai_addrlen) != 0) {
        LOGE("dl","connect %s:%u: %s", host, port, strerror(errno));
        freeaddrinfo(res); close(s);
        pthread_mutex_lock(&mgr->lock); job->sock_fd=-1; pthread_mutex_unlock(&mgr->lock);
        return false;
    }
    freeaddrinfo(res);

    char req[1024];
    int rl = snprintf(req, sizeof(req),
        "GET %s HTTP/1.0\r\nHost: %s\r\n"
        "User-Agent: mo_library/" MO_VERSION "\r\n"
        "Connection: close\r\n\r\n", path, host);
    if (send(s, req, (size_t)rl, 0) != rl) {
        close(s);
        pthread_mutex_lock(&mgr->lock); job->sock_fd=-1; pthread_mutex_unlock(&mgr->lock);
        return false;
    }

    /* Read response header */
    char hdr_buf[4096];
    int hdr_pos = 0;
    while (hdr_pos < (int)sizeof(hdr_buf)-1) {
        ssize_t n = recv(s, hdr_buf+hdr_pos, 1, 0);
        if (n <= 0) break;
        hdr_pos++;
        if (hdr_pos >= 4 &&
            memcmp(hdr_buf+hdr_pos-4, "\r\n\r\n", 4)==0) break;
    }
    hdr_buf[hdr_pos] = '\0';

    /* Parse Content-Length */
    uint64_t content_length = 0;
    char *cl = strcasestr(hdr_buf, "Content-Length:");
    if (cl) content_length = (uint64_t)strtoull(cl+15, NULL, 10);

    int fd = open(dest_path, O_WRONLY|O_CREAT|O_TRUNC, 0644);
    if (fd < 0) {
        LOGE("dl","open('%s'): %s", dest_path, strerror(errno));
        close(s);
        pthread_mutex_lock(&mgr->lock); job->sock_fd=-1; pthread_mutex_unlock(&mgr->lock);
        return false;
    }

    uint8_t chunk[CHUNK_SIZE];
    uint64_t received = 0;
    uint64_t speed_bps = 0;
    struct timeval t_start, t_last, t_now;
    gettimeofday(&t_start, NULL);
    t_last = t_start;
    uint64_t bytes_since_last = 0;

    bool ok = true;
    while (true) {
        /* Check cancel/pause */
        pthread_mutex_lock(&mgr->lock);
        mo_job_status_t st = job->status;
        pthread_mutex_unlock(&mgr->lock);

        if (st == JOB_CANCELLED || st == JOB_PAUSED) {
            ok = (st == JOB_PAUSED); /* paused = not failed */
            break;
        }

        ssize_t nr = recv(s, chunk, sizeof(chunk), 0);
        if (nr <= 0) break;

        if (write(fd, chunk, (size_t)nr) != nr) {
            LOGE("dl","write error: %s", strerror(errno));
            ok = false; break;
        }

        received += (uint64_t)nr;
        bytes_since_last += (uint64_t)nr;

        gettimeofday(&t_now, NULL);
        double dt = (double)(t_now.tv_sec - t_last.tv_sec)*1000.0
                  + (double)(t_now.tv_usec - t_last.tv_usec)/1000.0;
        if (dt >= 500.0) {
            uint64_t instant = (uint64_t)(bytes_since_last / (dt/1000.0));
            speed_bps = (uint64_t)((1.0-SPEED_ALPHA)*speed_bps + SPEED_ALPHA*instant);
            bytes_since_last = 0;
            t_last = t_now;

            pthread_mutex_lock(&mgr->lock);
            job->bytes_done = received;
            job->speed_bps  = speed_bps;
            job->progress   = content_length > 0
                                  ? (double)received / (double)content_length
                                  : 0.0;
            pthread_mutex_unlock(&mgr->lock);

            fire_event(mgr, job);
        }
    }

    close(fd);
    close(s);
    pthread_mutex_lock(&mgr->lock); job->sock_fd=-1; pthread_mutex_unlock(&mgr->lock);

    if (ok) {
        pthread_mutex_lock(&mgr->lock);
        job->bytes_done = received;
        job->progress   = 1.0;
        job->speed_bps  = 0;
        pthread_mutex_unlock(&mgr->lock);
    }
    return ok;
}

/* ── Worker thread per active job ────────────────────────────────────────────── */

typedef struct { mo_dl_manager_t *mgr; char job_id[MO_MAX_ID_LEN]; } worker_arg_t;

static void *job_worker(void *arg) {
    worker_arg_t *wa = (worker_arg_t *)arg;
    mo_dl_manager_t *mgr = wa->mgr;
    char job_id[MO_MAX_ID_LEN];
    memcpy(job_id, wa->job_id, sizeof(job_id));
    free(wa);

    pthread_mutex_lock(&mgr->lock);
    mo_job_t *job = find_job(mgr, job_id);
    if (!job || job->status != JOB_QUEUED) {
        pthread_mutex_unlock(&mgr->lock);
        return NULL;
    }
    job->status     = JOB_DOWNLOADING;
    job->started_at = mo_now_ms();
    job->stage      = 1;

    char title_id[MO_MAX_ID_LEN], variant_id[MO_MAX_ID_LEN];
    mo_install_path_t dest_path = job->dest_path;
    memcpy(title_id,   job->title_id,   sizeof(title_id));
    memcpy(variant_id, job->variant_id, sizeof(variant_id));
    pthread_mutex_unlock(&mgr->lock);

    const mo_title_t   *title   = catalog_find_title(mgr->catalog, title_id);
    const mo_variant_t *variant = catalog_find_variant(mgr->catalog, title_id, variant_id);

    if (!title || !variant) {
        pthread_mutex_lock(&mgr->lock);
        job = find_job(mgr, job_id);
        if (job) {
            job->status = JOB_FAILED;
            snprintf(job->error, sizeof(job->error), "title/variant not found");
        }
        pthread_mutex_unlock(&mgr->lock);
        LOGE("dl","job %s: title/variant not found", job_id);
        return NULL;
    }

    /* ── Stage 1: Download ────────────────────────────────────────────────── */
    char tmp_path[512];
    snprintf(tmp_path, sizeof(tmp_path), "/data/tmp/mo_%s.dl", job_id);
    fs_mkdirs("/data/tmp");  /* ensure temp dir */

    LOGI("dl","[%s] Stage 1: downloading %s", job_id, variant->url);

    /* Simulate download for mo:// pseudo-URLs (built-in titles) */
    bool dl_ok;
    if (strncmp(variant->url, "mo://", 5) == 0) {
        /* Create a zero-byte placeholder for built-in payloads */
        FILE *f = fopen(tmp_path, "wb");
        if (f) { fclose(f); dl_ok = true; }
        else dl_ok = false;

        pthread_mutex_lock(&mgr->lock);
        job = find_job(mgr, job_id);
        if (job) { job->progress = 1.0; job->bytes_done = variant->size_bytes; }
        pthread_mutex_unlock(&mgr->lock);
    } else {
        dl_ok = http_download(variant->url, tmp_path, job, mgr);
    }

    pthread_mutex_lock(&mgr->lock);
    job = find_job(mgr, job_id);
    if (!job || job->status == JOB_CANCELLED) {
        unlink(tmp_path);
        pthread_mutex_unlock(&mgr->lock);
        return NULL;
    }
    if (job->status == JOB_PAUSED) {
        pthread_mutex_unlock(&mgr->lock);
        return NULL;
    }
    if (!dl_ok) {
        job->status = JOB_FAILED;
        snprintf(job->error, sizeof(job->error), "download failed");
        pthread_mutex_unlock(&mgr->lock);
        unlink(tmp_path);
        return NULL;
    }
    pthread_mutex_unlock(&mgr->lock);

    /* ── Stage 2: Decompress (if compressed variant) ──────────────────────── */
    char install_src[512];
    snprintf(install_src, sizeof(install_src), "%s", tmp_path);

    if (variant->compressed) {
        pthread_mutex_lock(&mgr->lock);
        job = find_job(mgr, job_id);
        if (job) { job->status = JOB_DECOMPRESSING; job->stage = 2; job->progress = 0.0; }
        pthread_mutex_unlock(&mgr->lock);

        LOGI("dl","[%s] Stage 2: decompressing", job_id);

        char decomp_dir[512];
        snprintf(decomp_dir, sizeof(decomp_dir), "/data/tmp/mo_%s_ex", job_id);

        mo_arch_options_t aopts = {0};
        snprintf(aopts.src_path, sizeof(aopts.src_path), "%s", tmp_path);
        snprintf(aopts.dst_path, sizeof(aopts.dst_path), "%s", decomp_dir);
        aopts.delete_after = true;
        aopts.overwrite    = true;

        mo_arch_result_t ar = archive_extract_sync(&aopts);
        if (!ar.success) {
            pthread_mutex_lock(&mgr->lock);
            job = find_job(mgr, job_id);
            if (job) {
                job->status = JOB_FAILED;
                snprintf(job->error, sizeof(job->error),
                         "decompress failed: %s", ar.error);
            }
            pthread_mutex_unlock(&mgr->lock);
            return NULL;
        }
        snprintf(install_src, sizeof(install_src), "%s", decomp_dir);
    }

    /* ── Stage 3: DPIv2 install ───────────────────────────────────────────── */
    pthread_mutex_lock(&mgr->lock);
    job = find_job(mgr, job_id);
    if (job) { job->status = JOB_INSTALLING; job->stage = 3; job->progress = 0.0; }
    pthread_mutex_unlock(&mgr->lock);

    LOGI("dl","[%s] Stage 3: installing → %s", job_id,
         mo_install_path_str(dest_path));

    /* Simulate DPIv2 install (actual SDK call would go here) */
    usleep(500000);

    uint64_t needed = mo_needed_bytes(variant);

    /* ── Completion: update storage ONCE under lock (BUG-1 fix) ─────────── */
    pthread_mutex_lock(&mgr->lock);
    job = find_job(mgr, job_id);
    if (job && job->status == JOB_INSTALLING) {
        job->status      = JOB_COMPLETED;
        job->progress    = 1.0;
        job->speed_bps   = 0;
        job->finished_at = mo_now_ms();

        /* BUG-1 fix: apply storage delta exactly once, here */
        storage_t *st = storage_for(mgr, dest_path);
        st->used += needed;

        /* Record installation */
        if (mgr->installed_count < MO_MAX_TITLES) {
            int idx = mgr->installed_count++;
            snprintf(mgr->installed_keys[idx], MO_MAX_ID_LEN, "%s", title_id);
            mgr->installed[idx].path       = dest_path;
            mgr->installed[idx].at         = mo_now_ms();
            mgr->installed[idx].size_bytes = needed;
            snprintf(mgr->installed[idx].variant_id,
                     sizeof(mgr->installed[idx].variant_id), "%s", variant_id);
        }
    }
    fire_event(mgr, job);
    pthread_mutex_unlock(&mgr->lock);

    LOGI("dl","[%s] Complete: %s installed to %s",
         job_id, title->title, mo_install_path_str(dest_path));

    /* Cleanup temp files */
    unlink(tmp_path);

    return NULL;
}

/* ── Scheduler ────────────────────────────────────────────────────────────────── */

static void *scheduler_thread(void *arg) {
    mo_dl_manager_t *mgr = (mo_dl_manager_t *)arg;

    while (atomic_load(&mgr->running)) {
        pthread_mutex_lock(&mgr->lock);

        int active = 0;
        for (int i = 0; i < mgr->job_count; i++)
            if (mgr->jobs[i].status == JOB_DOWNLOADING ||
                mgr->jobs[i].status == JOB_DECOMPRESSING ||
                mgr->jobs[i].status == JOB_INSTALLING)
                active++;

        /* Start queued jobs up to MAX_ACTIVE_JOBS */
        for (int i = 0; i < mgr->job_count && active < MO_MAX_ACTIVE_JOBS; i++) {
            if (mgr->jobs[i].status != JOB_QUEUED) continue;

            worker_arg_t *wa = malloc(sizeof(worker_arg_t));
            if (!wa) break;
            wa->mgr = mgr;
            snprintf(wa->job_id, sizeof(wa->job_id), "%s", mgr->jobs[i].id);

            pthread_t t;
            if (pthread_create(&t, NULL, job_worker, wa) == 0) {
                pthread_detach(t);
                active++;
            } else {
                free(wa);
            }
        }

        pthread_mutex_unlock(&mgr->lock);
        usleep((useconds_t)TICK_INTERVAL_MS * 1000);
    }
    return NULL;
}

/* ── Public API ──────────────────────────────────────────────────────────────── */

mo_dl_manager_t *dl_manager_new(mo_catalog_t *catalog) {
    mo_dl_manager_t *mgr = calloc(1, sizeof(mo_dl_manager_t));
    if (!mgr) return NULL;
    mgr->catalog = catalog;
    pthread_mutex_init(&mgr->lock, NULL);
    atomic_store(&mgr->running, false);
    mgr->internal.total = MO_INTERNAL_TOTAL;
    mgr->usb.total      = MO_USB_TOTAL;
    mgr->usb.mounted    = false;
    return mgr;
}

void dl_manager_free(mo_dl_manager_t *mgr) {
    if (!mgr) return;
    dl_manager_stop(mgr);
    pthread_mutex_destroy(&mgr->lock);
    free(mgr);
}

bool dl_manager_start(mo_dl_manager_t *mgr, dl_event_cb cb, void *ud) {
    if (!mgr || atomic_load(&mgr->running)) return true;
    mgr->cb   = cb;
    mgr->cb_ud = ud;
    atomic_store(&mgr->running, true);

    if (pthread_create(&mgr->scheduler_thread, NULL, scheduler_thread, mgr) != 0) {
        atomic_store(&mgr->running, false);
        return false;
    }
    LOGI("dl","Download manager started");
    return true;
}

void dl_manager_stop(mo_dl_manager_t *mgr) {
    if (!mgr || !atomic_load(&mgr->running)) return;
    atomic_store(&mgr->running, false);
    pthread_join(mgr->scheduler_thread, NULL);
    LOGI("dl","Download manager stopped");
}

const char *dl_enqueue(mo_dl_manager_t   *mgr,
                        const char        *title_id,
                        const char        *variant_id,
                        mo_install_path_t  dest) {
    if (!mgr || !title_id || !variant_id) return NULL;

    const mo_variant_t *v = catalog_find_variant(mgr->catalog, title_id, variant_id);
    if (!v) { LOGE("dl","variant not found: %s/%s", title_id, variant_id); return NULL; }

    pthread_mutex_lock(&mgr->lock);

    /* Already queued/active? */
    if (find_job_by_variant(mgr, variant_id)) {
        pthread_mutex_unlock(&mgr->lock);
        LOGW("dl","variant already in queue: %s", variant_id);
        return NULL;
    }

    /* Storage check */
    uint64_t needed = mo_needed_bytes(v);
    if (dest == INSTALL_USB && !mgr->usb.mounted) {
        pthread_mutex_unlock(&mgr->lock);
        LOGE("dl","USB not mounted");
        return NULL;
    }
    storage_t *st = storage_for(mgr, dest);
    if (storage_free(st) < needed) {
        pthread_mutex_unlock(&mgr->lock);
        char nb[32], fb[32];
        mo_format_bytes(nb, sizeof(nb), needed);
        mo_format_bytes(fb, sizeof(fb), storage_free(st));
        LOGE("dl","Insufficient space: need %s, free %s", nb, fb);
        return NULL;
    }

    if (mgr->job_count >= MO_MAX_JOBS) {
        pthread_mutex_unlock(&mgr->lock);
        LOGE("dl","job queue full");
        return NULL;
    }

    mo_job_t *job = &mgr->jobs[mgr->job_count++];
    memset(job, 0, sizeof(*job));
    mo_uid(job->id,         sizeof(job->id),         "job");
    snprintf(job->title_id,   sizeof(job->title_id),   "%s", title_id);
    snprintf(job->variant_id, sizeof(job->variant_id), "%s", variant_id);
    job->status    = JOB_QUEUED;
    job->priority  = 5;
    job->dest_path = dest;
    job->stage     = 1;
    job->sock_fd   = -1;

    static char last_id[MO_MAX_ID_LEN];
    snprintf(last_id, sizeof(last_id), "%s", job->id);

    pthread_mutex_unlock(&mgr->lock);
    LOGI("dl","Enqueued: %s / %s → %s", title_id, variant_id,
         mo_install_path_str(dest));
    return last_id;
}

bool dl_pause(mo_dl_manager_t *mgr, const char *job_id) {
    if (!mgr || !job_id) return false;
    pthread_mutex_lock(&mgr->lock);
    mo_job_t *job = find_job(mgr, job_id);
    bool ok = false;
    if (job) {
        /* BUG-3 fix: disallow pause during installing stage */
        if (job->status == JOB_DOWNLOADING || job->status == JOB_QUEUED) {
            job->status = JOB_PAUSED;
            /* Cancel the socket to unblock the recv loop */
            if (job->sock_fd >= 0) { shutdown(job->sock_fd, SHUT_RDWR); }
            ok = true;
        } else if (job->status == JOB_INSTALLING) {
            LOGW("dl","Cannot pause job %s during install stage", job_id);
        }
    }
    pthread_mutex_unlock(&mgr->lock);
    return ok;
}

bool dl_resume(mo_dl_manager_t *mgr, const char *job_id) {
    if (!mgr || !job_id) return false;
    /* BUG-4 fix: refuse resume when manager is stopped */
    if (!atomic_load(&mgr->running)) {
        LOGW("dl","Cannot resume: download manager not running");
        return false;
    }
    pthread_mutex_lock(&mgr->lock);
    mo_job_t *job = find_job(mgr, job_id);
    bool ok = false;
    if (job && job->status == JOB_PAUSED) {
        job->status   = JOB_QUEUED;
        job->progress = 0.0;
        ok = true;
    }
    pthread_mutex_unlock(&mgr->lock);
    return ok;
}

bool dl_cancel(mo_dl_manager_t *mgr, const char *job_id) {
    if (!mgr || !job_id) return false;
    pthread_mutex_lock(&mgr->lock);
    mo_job_t *job = find_job(mgr, job_id);
    bool ok = false;
    if (job && job->status != JOB_COMPLETED) {
        job->status = JOB_CANCELLED;
        if (job->sock_fd >= 0) { shutdown(job->sock_fd, SHUT_RDWR); }
        ok = true;
    }
    pthread_mutex_unlock(&mgr->lock);
    return ok;
}

bool dl_set_priority(mo_dl_manager_t *mgr, const char *job_id, int priority) {
    if (!mgr || !job_id) return false;
    pthread_mutex_lock(&mgr->lock);
    mo_job_t *job = find_job(mgr, job_id);
    bool ok = false;
    if (job) { job->priority = priority; ok = true; }
    pthread_mutex_unlock(&mgr->lock);
    return ok;
}

void dl_pause_all(mo_dl_manager_t *mgr) {
    if (!mgr) return;
    pthread_mutex_lock(&mgr->lock);
    for (int i = 0; i < mgr->job_count; i++) {
        mo_job_t *j = &mgr->jobs[i];
        if (j->status == JOB_DOWNLOADING || j->status == JOB_QUEUED) {
            j->status = JOB_PAUSED;
            if (j->sock_fd >= 0) shutdown(j->sock_fd, SHUT_RDWR);
        }
    }
    pthread_mutex_unlock(&mgr->lock);
}

void dl_resume_all(mo_dl_manager_t *mgr) {
    if (!mgr) return;
    if (!atomic_load(&mgr->running)) {
        LOGW("dl","resume_all: manager not running"); return;
    }
    pthread_mutex_lock(&mgr->lock);
    for (int i = 0; i < mgr->job_count; i++)
        if (mgr->jobs[i].status == JOB_PAUSED) {
            mgr->jobs[i].status   = JOB_QUEUED;
            mgr->jobs[i].progress = 0.0;
        }
    pthread_mutex_unlock(&mgr->lock);
}

void dl_cancel_all(mo_dl_manager_t *mgr) {
    if (!mgr) return;
    pthread_mutex_lock(&mgr->lock);
    for (int i = 0; i < mgr->job_count; i++) {
        mo_job_t *j = &mgr->jobs[i];
        if (j->status != JOB_COMPLETED) {
            j->status = JOB_CANCELLED;
            if (j->sock_fd >= 0) shutdown(j->sock_fd, SHUT_RDWR);
        }
    }
    pthread_mutex_unlock(&mgr->lock);
}

void dl_clear_completed(mo_dl_manager_t *mgr) {
    if (!mgr) return;
    pthread_mutex_lock(&mgr->lock);
    int w = 0;
    for (int i = 0; i < mgr->job_count; i++)
        if (mgr->jobs[i].status != JOB_COMPLETED &&
            mgr->jobs[i].status != JOB_CANCELLED)
            mgr->jobs[w++] = mgr->jobs[i];
    mgr->job_count = w;
    pthread_mutex_unlock(&mgr->lock);
}

int dl_snapshot(const mo_dl_manager_t *mgr, mo_job_t *out, int max_out) {
    if (!mgr || !out || max_out <= 0) return 0;
    pthread_mutex_lock((pthread_mutex_t *)&mgr->lock);
    int n = mgr->job_count < max_out ? mgr->job_count : max_out;
    memcpy(out, mgr->jobs, sizeof(mo_job_t) * (size_t)n);
    pthread_mutex_unlock((pthread_mutex_t *)&mgr->lock);
    return n;
}

bool dl_get_job(const mo_dl_manager_t *mgr, const char *job_id, mo_job_t *out) {
    if (!mgr || !job_id || !out) return false;
    pthread_mutex_lock((pthread_mutex_t *)&mgr->lock);
    const mo_job_t *j = find_job((mo_dl_manager_t *)mgr, job_id);
    if (j) *out = *j;
    pthread_mutex_unlock((pthread_mutex_t *)&mgr->lock);
    return j != NULL;
}

uint64_t dl_storage_used(const mo_dl_manager_t *mgr, mo_install_path_t p) {
    if (!mgr) return 0;
    return (p == INSTALL_USB) ? mgr->usb.used : mgr->internal.used;
}

uint64_t dl_storage_free(const mo_dl_manager_t *mgr, mo_install_path_t p) {
    if (!mgr) return 0;
    const storage_t *s = (p == INSTALL_USB) ? &mgr->usb : &mgr->internal;
    return storage_free(s);
}

bool dl_usb_mounted(const mo_dl_manager_t *mgr) {
    return mgr && mgr->usb.mounted;
}

void dl_toggle_usb(mo_dl_manager_t *mgr) {
    if (!mgr) return;
    pthread_mutex_lock(&mgr->lock);
    mgr->usb.mounted = !mgr->usb.mounted;
    LOGI("dl","USB %s", mgr->usb.mounted ? "mounted" : "unmounted");
    pthread_mutex_unlock(&mgr->lock);
}
