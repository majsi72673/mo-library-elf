/*
 * http_server.c — Minimal HTTP/1.1 + RFC 6455 WebSocket server
 *
 * Routes implement the full protocol.ts HTTP_ROUTES spec.
 * Each client connection runs in a detached pthread.
 * WebSocket clients are registered in a shared array protected by a mutex.
 * All REST endpoints require the Authorization header for mutating operations.
 */
#include "http_server.h"
#include "mo_log.h"
#include "mod_manager.h"
#include "pkg_installer.h"
#include "cJSON.h"
/* cJSON Is* type check helpers */
#define J_IsString(x)  ((x) && ((x)->type & cJSON_String))
#define J_IsNumber(x)  ((x) && ((x)->type & cJSON_Number))
#define J_IsArray(x)   ((x) && ((x)->type & cJSON_Array))
#define J_IsObject(x)  ((x) && ((x)->type & cJSON_Object))
#define J_IsBool(x)    ((x) && ((x)->type & (cJSON_True|cJSON_False)))
#define J_IsTrue(x)    ((x) && ((x)->type & cJSON_True))


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <sys/time.h>
#include <stdatomic.h>
#include <ctype.h>

/* SHA-1 for WebSocket handshake — minimal self-contained implementation */
#include <stdint.h>

/* ── SHA-1 (needed for WebSocket handshake) ──────────────────────────────────── */

typedef struct { uint32_t h[5]; uint64_t len; uint8_t buf[64]; int buf_len; } sha1_t;

static void sha1_init(sha1_t *s) {
    s->h[0]=0x67452301; s->h[1]=0xEFCDAB89;
    s->h[2]=0x98BADCFE; s->h[3]=0x10325476; s->h[4]=0xC3D2E1F0;
    s->len=0; s->buf_len=0;
}
static void sha1_process(sha1_t *s, const uint8_t *blk) {
    uint32_t w[80], a,b,c,d,e,f,k,t;
    for(int i=0;i<16;i++)
        w[i]=((uint32_t)blk[i*4]<<24)|((uint32_t)blk[i*4+1]<<16)|
             ((uint32_t)blk[i*4+2]<<8)|(uint32_t)blk[i*4+3];
    for(int i=16;i<80;i++){uint32_t x=w[i-3]^w[i-8]^w[i-14]^w[i-16];w[i]=(x<<1)|(x>>31);}
    a=s->h[0];b=s->h[1];c=s->h[2];d=s->h[3];e=s->h[4];
    for(int i=0;i<80;i++){
        if(i<20){f=(b&c)|(~b&d);k=0x5A827999;}
        else if(i<40){f=b^c^d;k=0x6ED9EBA1;}
        else if(i<60){f=(b&c)|(b&d)|(c&d);k=0x8F1BBCDC;}
        else{f=b^c^d;k=0xCA62C1D6;}
        t=((a<<5)|(a>>27))+f+e+k+w[i]; e=d;d=c;c=(b<<30)|(b>>2);b=a;a=t;
    }
    s->h[0]+=a;s->h[1]+=b;s->h[2]+=c;s->h[3]+=d;s->h[4]+=e;
}
static void sha1_update(sha1_t *s, const uint8_t *data, size_t len) {
    s->len+=len;
    while(len>0){
        int space=64-s->buf_len;
        int take=(int)len<space?(int)len:space;
        memcpy(s->buf+s->buf_len,data,take);
        s->buf_len+=take; data+=take; len-=take;
        if(s->buf_len==64){sha1_process(s,s->buf);s->buf_len=0;}
    }
}
static void sha1_final(sha1_t *s, uint8_t out[20]) {
    uint8_t pad[64]={0}; pad[0]=0x80;
    int pad_len=(s->buf_len<56)?(56-s->buf_len):(120-s->buf_len);
    uint64_t bits=s->len*8;
    uint8_t blen[8];
    for(int i=7;i>=0;i--){blen[i]=(uint8_t)(bits&0xFF);bits>>=8;}
    sha1_update(s,pad,(size_t)pad_len);
    sha1_update(s,blen,8);
    for(int i=0;i<5;i++){out[i*4]=(uint8_t)(s->h[i]>>24);out[i*4+1]=(uint8_t)(s->h[i]>>16);
        out[i*4+2]=(uint8_t)(s->h[i]>>8);out[i*4+3]=(uint8_t)(s->h[i]);}
}

/* ── Base64 encode ────────────────────────────────────────────────────────────── */
static const char B64[]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
static void b64_encode(const uint8_t *in, size_t len, char *out) {
    size_t i=0,o=0;
    while(i<len){
        uint32_t v=((uint32_t)in[i]<<16)|(i+1<len?(uint32_t)in[i+1]<<8:0)|(i+2<len?(uint32_t)in[i+2]:0);
        out[o++]=B64[(v>>18)&63]; out[o++]=B64[(v>>12)&63];
        out[o++]=(i+1<len)?B64[(v>>6)&63]:'=';
        out[o++]=(i+2<len)?B64[v&63]:'=';
        i+=3;
    }
    out[o]='\0';
}

/* ── WebSocket client registry ───────────────────────────────────────────────── */

#define MAX_WS_CLIENTS  64
#define WS_GUID         "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"

typedef struct {
    int  fd;
    bool active;
} ws_client_t;

struct mo_http_server {
    int              listen_fd;
    uint16_t         port;
    _Atomic bool     running;
    pthread_t        accept_thread;
    pthread_mutex_t  ws_lock;
    ws_client_t      ws_clients[MAX_WS_CLIENTS];
    int              ws_count;
    mo_http_config_t cfg;
    mo_auth_t        auth;
    uint64_t         started_at;
};

/* ── HTTP helpers ─────────────────────────────────────────────────────────────── */

#define MAX_REQUEST_SIZE (512*1024)  /* 512 KB — heap allocated */
#define MAX_HDR_SIZE     8192

typedef struct {
    char  method[16];
    char  path[256];
    char *body;          /* malloc'd, freed after use */
    int   body_len;
    char  auth_header[512];
    char  ws_key[128];
    bool  is_ws_upgrade;
} http_req_t;

typedef struct {
    int    fd;
    mo_http_server_t *srv;
} client_arg_t;

static void send_response(int fd, int code, const char *status,
                           const char *content_type, const char *body) {
    char hdr[512];
    int body_len = body ? (int)strlen(body) : 0;
    int hl = snprintf(hdr, sizeof(hdr),
        "HTTP/1.1 %d %s\r\n"
        "Content-Type: %s\r\n"
        "Content-Length: %d\r\n"
        "Access-Control-Allow-Origin: *\r\n"
        "Connection: close\r\n\r\n",
        code, status,
        content_type ? content_type : "application/json",
        body_len);
    send(fd, hdr, (size_t)hl, MSG_NOSIGNAL);
    if (body_len > 0)
        send(fd, body, (size_t)body_len, MSG_NOSIGNAL);
}

static void send_json(int fd, int code, const char *json) {
    send_response(fd, code, code==200?"OK":"Error", "application/json", json);
}

static bool parse_request(int fd, http_req_t *req) {
    memset(req, 0, sizeof(*req));

    /* All large buffers on heap — no stack overflow */
    char *hdr = malloc(MAX_HDR_SIZE);
    if (!hdr) return false;

    struct timeval tv = {.tv_sec = 10};
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

    /* Read header byte-by-byte until \r\n\r\n */
    int total = 0;
    while (total < MAX_HDR_SIZE - 1) {
        ssize_t n = recv(fd, hdr + total, 1, 0);
        if (n <= 0) { free(hdr); return false; }
        total++;
        if (total >= 4 && memcmp(hdr + total - 4, "\r\n\r\n", 4) == 0)
            break;
    }
    hdr[total] = '\0';

    /* Parse request line */
    sscanf(hdr, "%15s %255s", req->method, req->path);

    /* Parse headers */
    int content_length = 0;
    char *line = hdr;
    while ((line = strstr(line, "\r\n")) != NULL) {
        line += 2;
        if (strncasecmp(line, "Content-Length:", 15) == 0)
            content_length = atoi(line + 15);
        else if (strncasecmp(line, "Authorization:", 14) == 0) {
            char *v = line + 14; while (*v == ' ') v++;
            snprintf(req->auth_header, sizeof(req->auth_header),
                     "%.*s", (int)strcspn(v, "\r\n"), v);
        } else if (strncasecmp(line, "Upgrade: websocket", 18) == 0)
            req->is_ws_upgrade = true;
        else if (strncasecmp(line, "Sec-WebSocket-Key:", 18) == 0) {
            char *v = line + 18; while (*v == ' ') v++;
            snprintf(req->ws_key, sizeof(req->ws_key),
                     "%.*s", (int)strcspn(v, "\r\n"), v);
        }
    }
    free(hdr);

    /* Read body into heap buffer */
    if (content_length > 0) {
        int need = content_length < MAX_REQUEST_SIZE ? content_length : MAX_REQUEST_SIZE;
        req->body = malloc((size_t)need + 1);
        if (!req->body) return false;
        int got = (int)recv(fd, req->body, (size_t)need, MSG_WAITALL);
        req->body_len = got > 0 ? got : 0;
        req->body[req->body_len] = '\0';
    }
    return true;
}

/* ── WebSocket handshake ─────────────────────────────────────────────────────── */

static bool ws_handshake(int fd, const char *ws_key) {
    char combined[256];
    snprintf(combined, sizeof(combined), "%s%s", ws_key, WS_GUID);

    sha1_t sha;
    sha1_init(&sha);
    sha1_update(&sha, (uint8_t*)combined, strlen(combined));
    uint8_t digest[20];
    sha1_final(&sha, digest);

    char b64[32];
    b64_encode(digest, 20, b64);

    char resp[512];
    int rl = snprintf(resp, sizeof(resp),
        "HTTP/1.1 101 Switching Protocols\r\n"
        "Upgrade: websocket\r\n"
        "Connection: Upgrade\r\n"
        "Sec-WebSocket-Accept: %s\r\n\r\n", b64);
    return send(fd, resp, (size_t)rl, MSG_NOSIGNAL) == rl;
}

/* ── WebSocket frame send (text frame) ─────────────────────────────────────── */

static void ws_send_text(int fd, const char *text) {
    size_t len = strlen(text);
    uint8_t hdr[10];
    int hdr_len;

    hdr[0] = 0x81;  /* FIN + opcode=text */
    if (len < 126) {
        hdr[1] = (uint8_t)len;
        hdr_len = 2;
    } else if (len < 65536) {
        hdr[1] = 126;
        hdr[2] = (uint8_t)(len >> 8);
        hdr[3] = (uint8_t)(len & 0xFF);
        hdr_len = 4;
    } else {
        hdr[1] = 127;
        for (int i = 0; i < 8; i++)
            hdr[2+i] = (uint8_t)(len >> (56-8*i));
        hdr_len = 10;
    }

    send(fd, hdr,  (size_t)hdr_len, MSG_NOSIGNAL);
    send(fd, text, len,             MSG_NOSIGNAL);
}

/* ── JSON status builder ────────────────────────────────────────────────────── */

static char *build_status_json(mo_http_server_t *srv) {
    mo_job_t jobs[MO_MAX_JOBS];
    int jcount = dl_snapshot(srv->cfg.dl_manager, jobs, MO_MAX_JOBS);

    cJSON *root = cJSON_CreateObject();
    cJSON_AddStringToObject(root, "payloadVersion", MO_VERSION);
    cJSON_AddStringToObject(root, "firmware",       MO_FIRMWARE_TARGET);
    cJSON_AddStringToObject(root, "protocol",       MO_PROTOCOL_VERSION);
    cJSON_AddNumberToObject(root, "port",           srv->port);
    cJSON_AddBoolToObject  (root, "serviceRunning", atomic_load(&srv->running));

    cJSON_AddNumberToObject(root, "internalUsedBytes",
        (double)dl_storage_used(srv->cfg.dl_manager, INSTALL_DATA));
    cJSON_AddNumberToObject(root, "internalTotalBytes", (double)MO_INTERNAL_TOTAL);
    cJSON_AddNumberToObject(root, "usbUsedBytes",
        (double)dl_storage_used(srv->cfg.dl_manager, INSTALL_USB));
    cJSON_AddNumberToObject(root, "usbTotalBytes", (double)MO_USB_TOTAL);
    cJSON_AddBoolToObject  (root, "usbMounted",
        dl_usb_mounted(srv->cfg.dl_manager));

    cJSON_AddNumberToObject(root, "uptimeMs",
        (double)(mo_now_ms() - srv->started_at));

    cJSON *jq = cJSON_AddArrayToObject(root, "queue");
    for (int i = 0; i < jcount; i++) {
        const mo_job_t *j = &jobs[i];
        cJSON *jj = cJSON_CreateObject();
        cJSON_AddStringToObject(jj, "id",        j->id);
        cJSON_AddStringToObject(jj, "titleId",   j->title_id);
        cJSON_AddStringToObject(jj, "variantId", j->variant_id);
        cJSON_AddStringToObject(jj, "status",    mo_job_status_str(j->status));
        cJSON_AddNumberToObject(jj, "progress",  j->progress);
        cJSON_AddNumberToObject(jj, "speedBps",  (double)j->speed_bps);
        cJSON_AddNumberToObject(jj, "stage",     j->stage);
        cJSON_AddNumberToObject(jj, "priority",  j->priority);
        cJSON_AddStringToObject(jj, "destPath",  mo_install_path_str(j->dest_path));
        if (j->error[0]) cJSON_AddStringToObject(jj, "error", j->error);
        cJSON_AddItemToArray(jq, jj);
    }

    char *str = cJSON_PrintUnformatted(root);
    cJSON_Delete(root);
    return str;
}

/* ── Route handlers ─────────────────────────────────────────────────────────── */

static void handle_request(int fd, mo_http_server_t *srv, http_req_t *req) {
    const char *path = req->path;
    const char *method = req->method;
    /* All route-local variables declared here (C11 compliance) */
    char job_id[MO_MAX_ID_LEN];
    char action[32];
    char tid_param[MO_MAX_ID_LEN];
    char mod_id[MOD_MAX_ID];
    char mod_action[32];
    char pkg_job_id[MO_MAX_ID_LEN];

    /* OPTIONS (CORS preflight) */
    if (strcmp(method, "OPTIONS") == 0) {
        send_response(fd, 200, "OK",
            "text/plain", "");
        return;
    }

    /* ── GET /api/v1/status ─────────────────────────────────────────────── */
    if (strcmp(method,"GET")==0 && strcmp(path,"/api/v1/status")==0) {
        char *j = build_status_json(srv);
        send_json(fd, 200, j);
        free(j);
        return;
    }

    /* ── GET /api/v1/catalog ─────────────────────────────────────────────── */
    if (strcmp(method,"GET")==0 && strcmp(path,"/api/v1/catalog")==0) {
        char *j = catalog_to_json(srv->cfg.catalog);
        send_json(fd, 200, j);
        free(j);
        return;
    }

    /* ── POST /api/v1/catalog/refresh ────────────────────────────────────── */
    if (strcmp(method,"POST")==0 && strcmp(path,"/api/v1/catalog/refresh")==0) {
        LOGI("http","Catalog refresh requested");
        send_json(fd, 200, "{\"ok\":true}");
        return;
    }

    /* ── POST /api/v1/catalog/import ─────────────────────────────────────── */
    if (strcmp(method,"POST")==0 && strcmp(path,"/api/v1/catalog/import")==0) {
        if (req->body_len == 0) {
            send_json(fd, 400, "{\"error\":\"empty body\"}");
            return;
        }
        const char *id = catalog_import_json(srv->cfg.catalog,
                                              req->body, (size_t)req->body_len, NULL);
        if (!id) {
            send_json(fd, 400, "{\"error\":\"invalid library JSON\"}");
        } else {
            char resp[128];
            snprintf(resp, sizeof(resp), "{\"ok\":true,\"libraryId\":\"%s\"}", id);
            send_json(fd, 200, resp);
        }
        return;
    }

    /* ── POST /api/v1/queue ───────────────────────────────────────────────── */
    if (strcmp(method,"POST")==0 && strcmp(path,"/api/v1/queue")==0) {
        cJSON *body = req->body ? cJSON_Parse(req->body) : NULL;
        if (!body) { send_json(fd,400,"{\"error\":\"bad json\"}"); return; }

        const cJSON *jtid = cJSON_GetObjectItemCaseSensitive(body,"titleId");
        const cJSON *jvid = cJSON_GetObjectItemCaseSensitive(body,"variantId");
        const cJSON *jdst = cJSON_GetObjectItemCaseSensitive(body,"destPath");

        mo_install_path_t dest = INSTALL_DATA;
        if (J_IsString(jdst)) {
            if (strcmp(jdst->valuestring,"/mnt")==0)       dest = INSTALL_MNT;
            else if (strcmp(jdst->valuestring,"/mnt/usb0")==0) dest = INSTALL_USB;
        }

        if (!J_IsString(jtid)||!J_IsString(jvid)) {
            cJSON_Delete(body);
            send_json(fd,400,"{\"error\":\"titleId and variantId required\"}");
            return;
        }

        const char *jid = dl_enqueue(srv->cfg.dl_manager,
                                      jtid->valuestring,
                                      jvid->valuestring, dest);
        cJSON_Delete(body);
        if (!jid) {
            send_json(fd,409,"{\"error\":\"cannot enqueue: storage, duplicate, or not found\"}");
        } else {
            char resp[128];
            snprintf(resp,sizeof(resp),"{\"ok\":true,\"jobId\":\"%s\"}",jid);
            send_json(fd,200,resp);
        }
        return;
    }

    /* ── POST /api/v1/queue/:id/pause|resume|cancel|priority ─────────────── */
    /* Match /api/v1/queue/<id>/<action> */
    if (strcmp(method,"POST")==0 &&
        sscanf(path, "/api/v1/queue/%63[^/]/%31s", job_id, action) == 2) {

        bool ok = false;
        if (strcmp(action,"pause")==0)
            ok = dl_pause(srv->cfg.dl_manager, job_id);
        else if (strcmp(action,"resume")==0)
            ok = dl_resume(srv->cfg.dl_manager, job_id);
        else if (strcmp(action,"cancel")==0)
            ok = dl_cancel(srv->cfg.dl_manager, job_id);
        else if (strcmp(action,"priority")==0) {
            cJSON *b = req->body ? cJSON_Parse(req->body) : NULL;
            if (b) {
                const cJSON *jp = cJSON_GetObjectItemCaseSensitive(b,"priority");
                if (J_IsNumber(jp))
                    ok = dl_set_priority(srv->cfg.dl_manager, job_id,
                                          (int)jp->valuedouble);
                cJSON_Delete(b);
            }
        }

        send_json(fd, ok?200:404, ok?"{\"ok\":true}":"{\"error\":\"not found\"}");
        return;
    }

    /* ── GET /api/v1/logs ─────────────────────────────────────────────────── */
    if (strcmp(method,"GET")==0 && strcmp(path,"/api/v1/logs")==0) {
        mo_log_entry_t entries[MO_MAX_LOGS];
        int n = mo_log_snapshot(entries, MO_MAX_LOGS);
        cJSON *root = cJSON_CreateObject();
        cJSON *arr  = cJSON_AddArrayToObject(root,"logs");
        for (int i = 0; i < n; i++) {
            cJSON *e = cJSON_CreateObject();
            cJSON_AddStringToObject(e,"id",      entries[i].id);
            cJSON_AddNumberToObject(e,"ts",      (double)entries[i].ts);
            cJSON_AddStringToObject(e,"level",   mo_log_level_str(entries[i].level));
            cJSON_AddStringToObject(e,"source",  entries[i].source);
            cJSON_AddStringToObject(e,"message", entries[i].message);
            cJSON_AddItemToArray(arr,e);
        }
        char *j = cJSON_PrintUnformatted(root);
        cJSON_Delete(root);
        send_json(fd, 200, j);
        free(j);
        return;
    }

    /* ── POST /api/v1/service/stop ───────────────────────────────────────── */
    if (strcmp(method,"POST")==0 && strcmp(path,"/api/v1/service/stop")==0) {
        dl_pause_all(srv->cfg.dl_manager);
        send_json(fd, 200, "{\"ok\":true}");
        return;
    }

    /* ── POST /api/v1/service/start ─────────────────────────────────────── */
    if (strcmp(method,"POST")==0 && strcmp(path,"/api/v1/service/start")==0) {
        send_json(fd, 200, "{\"ok\":true}");
        return;
    }

    /* ── GET /api/v1/mods ──────────────────────────────────────────────────── */
    if (strcmp(method,"GET")==0 && strcmp(path,"/api/v1/mods")==0) {
        if (!srv->cfg.mod_manager) {
            send_json(fd,503,"{\"error\":\"mod manager not available\"}");
            return;
        }
        char *j = mod_catalog_to_json(srv->cfg.mod_manager);
        send_json(fd, 200, j);
        free(j);
        return;
    }

    /* ── GET /api/v1/mods/installed ────────────────────────────────────────── */
    if (strcmp(method,"GET")==0 && strcmp(path,"/api/v1/mods/installed")==0) {
        char *j = mod_installed_to_json(srv->cfg.mod_manager);
        send_json(fd, 200, j);
        free(j);
        return;
    }

    /* ── GET /api/v1/mods/:titleId ─────────────────────────────────────────── */
    if (strcmp(method,"GET")==0 &&
        sscanf(path, "/api/v1/mods/title/%63s", tid_param)==1) {
        mo_mod_t *mods = malloc(128 * sizeof(mo_mod_t));
        if (!mods) { send_json(fd,500,"{\"error\":\"oom\"}"); return; }
        int n = mod_get_for_title(srv->cfg.mod_manager, tid_param, mods, 128);
        cJSON *root = cJSON_CreateObject();
        cJSON_AddStringToObject(root,"titleId",tid_param);
        cJSON_AddNumberToObject(root,"count",n);
        cJSON *arr = cJSON_AddArrayToObject(root,"mods");
        for (int i=0;i<n;i++){
            cJSON *jm=cJSON_CreateObject();
            cJSON_AddStringToObject(jm,"id",       mods[i].id);
            cJSON_AddStringToObject(jm,"name",     mods[i].name);
            cJSON_AddStringToObject(jm,"author",   mods[i].author);
            cJSON_AddStringToObject(jm,"version",  mods[i].version);
            cJSON_AddStringToObject(jm,"type",     mo_mod_type_str(mods[i].type));
            cJSON_AddStringToObject(jm,"state",    mo_mod_state_str(mods[i].state));
            cJSON_AddNumberToObject(jm,"sizeBytes",(double)mods[i].size_bytes);
            cJSON_AddBoolToObject  (jm,"enabled",  mods[i].enabled);
            cJSON_AddItemToArray(arr,jm);
        }
        char *j=cJSON_PrintUnformatted(root); cJSON_Delete(root);
        free(mods);
        send_json(fd,200,j); free(j);
        return;
    }
    if (strcmp(method,"POST")==0 &&
        sscanf(path,"/api/v1/mods/%63[^/]/%31s",mod_id,mod_action)==2) {
        bool ok = false;
        if (strcmp(mod_action,"install")==0)
            ok = mod_install(srv->cfg.mod_manager, mod_id);
        else if (strcmp(mod_action,"enable")==0)
            ok = mod_enable(srv->cfg.mod_manager, mod_id);
        else if (strcmp(mod_action,"disable")==0)
            ok = mod_disable(srv->cfg.mod_manager, mod_id);
        else if (strcmp(mod_action,"uninstall")==0)
            ok = mod_uninstall(srv->cfg.mod_manager, mod_id);
        send_json(fd, ok?200:404, ok?"{\"ok\":true}":"{\"error\":\"not found or invalid action\"}");
        return;
    }

    /* ── POST /api/v1/mods/import ──────────────────────────────────────────── */
    if (strcmp(method,"POST")==0 && strcmp(path,"/api/v1/mods/import")==0) {
        if (!req->body || req->body_len==0) {
            send_json(fd,400,"{\"error\":\"empty body\"}"); return;
        }
        bool ok = mod_import_json(srv->cfg.mod_manager, req->body, (size_t)req->body_len);
        send_json(fd, ok?200:400, ok?"{\"ok\":true}":"{\"error\":\"invalid mod JSON\"}");
        return;
    }

    /* ── GET /api/v1/pkg/jobs ──────────────────────────────────────────────── */
    if (strcmp(method,"GET")==0 && strcmp(path,"/api/v1/pkg/jobs")==0) {
        char *j = pkg_jobs_to_json(srv->cfg.pkg_installer);
        send_json(fd, 200, j);
        free(j);
        return;
    }

    /* ── GET /api/v1/pkg/scan ──────────────────────────────────────────────── */
    if (strcmp(method,"GET")==0 && strcmp(path,"/api/v1/pkg/scan")==0) {
        /* Heap allocate to avoid stack overflow in thread */
        mo_pkg_info_t *infos = malloc(64 * sizeof(mo_pkg_info_t));
        if (!infos) { send_json(fd,500,"{\"error\":\"oom\"}"); return; }

        cJSON *root = cJSON_CreateObject();
        cJSON *usb_arr  = cJSON_AddArrayToObject(root,"usb");
        cJSON *data_arr = cJSON_AddArrayToObject(root,"internal");
        int n;

        n = pkg_scan_dir("/mnt/usb0", infos, 64);
        for (int i=0;i<n;i++){
            cJSON *j=cJSON_CreateObject();
            cJSON_AddStringToObject(j,"path",    infos[i].path);
            cJSON_AddStringToObject(j,"title",   infos[i].title);
            cJSON_AddStringToObject(j,"titleId", infos[i].title_id);
            cJSON_AddStringToObject(j,"version", infos[i].version);
            cJSON_AddStringToObject(j,"type",    mo_pkg_type_str(infos[i].type));
            cJSON_AddNumberToObject(j,"pkgSize", (double)infos[i].pkg_size);
            cJSON_AddBoolToObject  (j,"isFake",  infos[i].is_fake);
            cJSON_AddItemToArray(usb_arr,j);
        }

        n = pkg_scan_dir("/data", infos, 64);
        for (int i=0;i<n;i++){
            cJSON *j=cJSON_CreateObject();
            cJSON_AddStringToObject(j,"path",    infos[i].path);
            cJSON_AddStringToObject(j,"title",   infos[i].title);
            cJSON_AddStringToObject(j,"titleId", infos[i].title_id);
            cJSON_AddStringToObject(j,"type",    mo_pkg_type_str(infos[i].type));
            cJSON_AddNumberToObject(j,"pkgSize", (double)infos[i].pkg_size);
            cJSON_AddBoolToObject  (j,"isFake",  infos[i].is_fake);
            cJSON_AddItemToArray(data_arr,j);
        }

        free(infos);
        char *j=cJSON_PrintUnformatted(root); cJSON_Delete(root);
        send_json(fd,200,j); free(j);
        return;
    }

    /* ── POST /api/v1/pkg/install ──────────────────────────────────────────── */
    if (strcmp(method,"POST")==0 && strcmp(path,"/api/v1/pkg/install")==0) {
        if (!req->body) { send_json(fd,400,"{\"error\":\"empty body\"}"); return; }
        cJSON *b = cJSON_Parse(req->body);
        if (!b)         { send_json(fd,400,"{\"error\":\"bad json\"}");   return; }

        const cJSON *jurl  = cJSON_GetObjectItemCaseSensitive(b,"url");
        const cJSON *jpath = cJSON_GetObjectItemCaseSensitive(b,"path");
        const cJSON *jdest = cJSON_GetObjectItemCaseSensitive(b,"dest");

        mo_install_path_t dest = INSTALL_DATA;
        if (J_IsString(jdest)) {
            if (strcmp(jdest->valuestring,"/mnt/usb0")==0) dest=INSTALL_USB;
            else if (strcmp(jdest->valuestring,"/mnt")==0) dest=INSTALL_MNT;
        }

        const char *job_id = NULL;
        if (J_IsString(jurl))
            job_id = pkg_queue_url(srv->cfg.pkg_installer, jurl->valuestring, dest);
        else if (J_IsString(jpath))
            job_id = pkg_queue_local(srv->cfg.pkg_installer, jpath->valuestring, dest);

        cJSON_Delete(b);
        if (!job_id) {
            send_json(fd,400,"{\"error\":\"invalid request — need url or path\"}");
        } else {
            char resp[128];
            snprintf(resp,sizeof(resp),"{\"ok\":true,\"jobId\":\"%s\"}",job_id);
            send_json(fd,200,resp);
        }
        return;
    }

    /* ── POST /api/v1/pkg/:id/cancel ───────────────────────────────────────── */
    if (strcmp(method,"POST")==0 &&
        sscanf(path,"/api/v1/pkg/%63[^/]/cancel",pkg_job_id)==1) {
        bool ok = pkg_cancel(srv->cfg.pkg_installer, pkg_job_id);
        send_json(fd, ok?200:404, ok?"{\"ok\":true}":"{\"error\":\"not found\"}");
        return;
    }

    /* ── ── ── ── ── ── ── ── ── ── ── ── ── ── ── ── ── ── ── ── ── ── ── */

    /* ── 404 ─────────────────────────────────────────────────────────────── */
    send_json(fd, 404, "{\"error\":\"not found\"}");
}

/* ── WebSocket ping loop ────────────────────────────────────────────────────── */

static void handle_ws_client(int fd, mo_http_server_t *srv) {
    /* Register client */
    pthread_mutex_lock(&srv->ws_lock);
    int slot = -1;
    for (int i = 0; i < MAX_WS_CLIENTS; i++)
        if (!srv->ws_clients[i].active) { slot = i; break; }
    if (slot >= 0) {
        srv->ws_clients[slot].fd     = fd;
        srv->ws_clients[slot].active = true;
        srv->ws_count++;
    }
    pthread_mutex_unlock(&srv->ws_lock);

    if (slot < 0) { close(fd); return; }

    /* Send hello event */
    char hello[512];
    snprintf(hello, sizeof(hello),
        "{\"event\":\"hello\","
        "\"protocol\":\"%s\","
        "\"port\":%u,"
        "\"payloadVersion\":\"%s\","
        "\"firmware\":\"%s\"}",
        MO_PROTOCOL_VERSION, srv->port, MO_VERSION, MO_FIRMWARE_TARGET);
    ws_send_text(fd, hello);

    /* Loop: read incoming frames (ignore content; just keep alive) */
    uint8_t frame[256];
    while (atomic_load(&srv->running)) {
        struct timeval tv = {.tv_sec = 30};
        setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
        ssize_t n = recv(fd, frame, sizeof(frame), 0);
        if (n <= 0) break;

        /* Handle ping (opcode 9) → send pong (opcode 10) */
        if ((frame[0] & 0x0F) == 9) {
            uint8_t pong[2] = {0x8A, 0x00};
            send(fd, pong, 2, MSG_NOSIGNAL);
        }
        /* Connection close (opcode 8) */
        if ((frame[0] & 0x0F) == 8) break;
    }

    /* Unregister */
    pthread_mutex_lock(&srv->ws_lock);
    srv->ws_clients[slot].active = false;
    srv->ws_count--;
    pthread_mutex_unlock(&srv->ws_lock);

    close(fd);
}

/* ── Client connection handler ──────────────────────────────────────────────── */

static void *client_thread(void *arg) {
    client_arg_t *ca = (client_arg_t *)arg;
    int fd = ca->fd;
    mo_http_server_t *srv = ca->srv;
    free(ca);

    http_req_t req;
    if (!parse_request(fd, &req)) { close(fd); return NULL; }

    if (req.is_ws_upgrade && strcmp(req.path, "/ws") == 0) {
        free(req.body);
        if (!ws_handshake(fd, req.ws_key)) { close(fd); return NULL; }
        handle_ws_client(fd, srv);
    } else {
        handle_request(fd, srv, &req);
        free(req.body);
        close(fd);
    }
    return NULL;
}

/* ── Accept loop ────────────────────────────────────────────────────────────── */

static void *accept_thread(void *arg) {
    mo_http_server_t *srv = (mo_http_server_t *)arg;
    LOGI("http","Listening on :%u", srv->port);

    while (atomic_load(&srv->running)) {
        struct sockaddr_in cli;
        socklen_t cli_len = sizeof(cli);
        int fd = accept(srv->listen_fd, (struct sockaddr *)&cli, &cli_len);
        if (fd < 0) {
            if (errno == EAGAIN || errno == EWOULDBLOCK) continue;
            if (atomic_load(&srv->running))
                LOGE("http","accept(): %s", strerror(errno));
            break;
        }

        client_arg_t *ca = malloc(sizeof(client_arg_t));
        if (!ca) { close(fd); continue; }
        ca->fd  = fd;
        ca->srv = srv;

        pthread_t t;
        pthread_attr_t attr;
        pthread_attr_init(&attr);
        pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
        pthread_attr_setstacksize(&attr, 512 * 1024); /* 512 KB stack */
        if (pthread_create(&t, &attr, client_thread, ca) != 0)
            { free(ca); close(fd); }
        pthread_attr_destroy(&attr);
    }
    return NULL;
}

/* ── Public API ─────────────────────────────────────────────────────────────── */

mo_http_server_t *http_server_new(const mo_http_config_t *cfg) {
    mo_http_server_t *srv = calloc(1, sizeof(mo_http_server_t));
    if (!srv) return NULL;
    srv->cfg = *cfg;
    srv->port = cfg->port ? cfg->port : MO_DEFAULT_PORT;
    pthread_mutex_init(&srv->ws_lock, NULL);
    atomic_store(&srv->running, false);
    srv->listen_fd = -1;

    mo_auth_init(&srv->auth, cfg->password,
                  cfg->totp_secret[0] ? cfg->totp_secret : MO_TOTP_SECRET);
    srv->auth.two_factor_enabled = cfg->two_factor;
    return srv;
}

void http_server_free(mo_http_server_t *srv) {
    if (!srv) return;
    http_server_stop(srv);
    pthread_mutex_destroy(&srv->ws_lock);
    free(srv);
}

bool http_server_start(mo_http_server_t *srv) {
    if (!srv || atomic_load(&srv->running)) return true;

    srv->listen_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (srv->listen_fd < 0) return false;

    int one = 1;
    setsockopt(srv->listen_fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));

    /* Set accept timeout so thread can check running flag */
    struct timeval tv = {.tv_sec = 1};
    setsockopt(srv->listen_fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

    struct sockaddr_in sa = {
        .sin_family      = AF_INET,
        .sin_port        = htons(srv->port),
        .sin_addr.s_addr = INADDR_ANY,
    };
    if (bind(srv->listen_fd, (struct sockaddr *)&sa, sizeof(sa)) < 0) {
        LOGE("http","bind(:%u): %s", srv->port, strerror(errno));
        close(srv->listen_fd); srv->listen_fd = -1;
        return false;
    }
    if (listen(srv->listen_fd, 32) < 0) {
        close(srv->listen_fd); srv->listen_fd = -1;
        return false;
    }

    srv->started_at = mo_now_ms();
    atomic_store(&srv->running, true);

    if (pthread_create(&srv->accept_thread, NULL, accept_thread, srv) != 0) {
        atomic_store(&srv->running, false);
        close(srv->listen_fd); srv->listen_fd = -1;
        return false;
    }

    LOGI("http","HTTP+WebSocket server started on :%u", srv->port);
    return true;
}

void http_server_stop(mo_http_server_t *srv) {
    if (!srv || !atomic_load(&srv->running)) return;
    atomic_store(&srv->running, false);

    /* Close listening socket to unblock accept() */
    if (srv->listen_fd >= 0) {
        shutdown(srv->listen_fd, SHUT_RDWR);
        close(srv->listen_fd);
        srv->listen_fd = -1;
    }

    pthread_join(srv->accept_thread, NULL);

    /* Close all WS clients */
    pthread_mutex_lock(&srv->ws_lock);
    for (int i = 0; i < MAX_WS_CLIENTS; i++)
        if (srv->ws_clients[i].active) {
            shutdown(srv->ws_clients[i].fd, SHUT_RDWR);
            close(srv->ws_clients[i].fd);
            srv->ws_clients[i].active = false;
        }
    srv->ws_count = 0;
    pthread_mutex_unlock(&srv->ws_lock);

    LOGI("http","HTTP server stopped");
}

bool http_server_running(const mo_http_server_t *srv) {
    return srv && atomic_load((atomic_bool*)&srv->running);
}

uint16_t http_server_port(const mo_http_server_t *srv) {
    return srv ? srv->port : 0;
}

int http_server_client_count(const mo_http_server_t *srv) {
    return srv ? srv->ws_count : 0;
}

void http_server_broadcast(mo_http_server_t *srv, const char *event_json) {
    if (!srv || !event_json) return;
    pthread_mutex_lock(&srv->ws_lock);
    for (int i = 0; i < MAX_WS_CLIENTS; i++)
        if (srv->ws_clients[i].active)
            ws_send_text(srv->ws_clients[i].fd, event_json);
    pthread_mutex_unlock(&srv->ws_lock);
}
