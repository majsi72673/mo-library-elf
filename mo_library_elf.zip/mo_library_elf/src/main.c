/*
 * main.c — mo_library.elf entry point
 *
 * Boot sequence:
 *  1. Initialize logger
 *  2. Load built-in catalog
 *  3. Start DNS sinkhole (blocks Sony OTA/telemetry)
 *  4. Start mod manager
 *  5. Start PKG installer
 *  6. Start download manager
 *  7. Start HTTP + WebSocket server
 *  8. (Optional) start archive auto-monitor
 *  9. Periodic broadcast loop
 * 10. Wait for termination signal
 */
#include "mo_types.h"
#include "mo_log.h"
#include "catalog.h"
#include "dns_server.h"
#include "archive_engine.h"
#include "download_manager.h"
#include "http_server.h"
#include "mod_manager.h"
#include "pkg_installer.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/time.h>
#include "cJSON.h"

/* ── Global state ─────────────────────────────────────────────────────────── */

static volatile bool g_shutdown = false;

static mo_catalog_t      *g_catalog      = NULL;
static mo_dl_manager_t   *g_dl_manager   = NULL;
static mo_http_server_t  *g_http_server  = NULL;
static mo_mod_manager_t  *g_mod_manager  = NULL;
static mo_pkg_installer_t*g_pkg_installer= NULL;

/* ── Signal handler ───────────────────────────────────────────────────────── */

static void sig_handler(int sig) {
    (void)sig;
    g_shutdown = true;
}

/* ── Download event → WebSocket broadcast ─────────────────────────────────── */

static void on_dl_event(const mo_job_t *job, void *ud) {
    mo_http_server_t *srv = (mo_http_server_t *)ud;
    if (!srv) return;

    cJSON *root = cJSON_CreateObject();
    cJSON_AddStringToObject(root, "event",     "queue.update");
    cJSON *jj = cJSON_AddObjectToObject(root, "job");
    cJSON_AddStringToObject(jj, "id",        job->id);
    cJSON_AddStringToObject(jj, "titleId",   job->title_id);
    cJSON_AddStringToObject(jj, "variantId", job->variant_id);
    cJSON_AddStringToObject(jj, "status",    mo_job_status_str(job->status));
    cJSON_AddNumberToObject(jj, "progress",  job->progress);
    cJSON_AddNumberToObject(jj, "speedBps",  (double)job->speed_bps);
    cJSON_AddNumberToObject(jj, "stage",     job->stage);

    char *str = cJSON_PrintUnformatted(root);
    if (str) {
        http_server_broadcast(srv, str);
        free(str);
    }
    cJSON_Delete(root);
}

/* ── Periodic broadcast thread ────────────────────────────────────────────── */

static void *broadcast_thread(void *arg) {
    mo_http_server_t *srv = (mo_http_server_t *)arg;
    mo_dns_stats_t dns_prev = {0};

    while (!g_shutdown) {
        usleep(2000000);  /* 2-second tick */
        if (!http_server_running(srv)) continue;

        /* Broadcast storage event */
        cJSON *ev = cJSON_CreateObject();
        cJSON_AddStringToObject(ev, "event", "storage");
        cJSON_AddNumberToObject(ev, "internalUsed",
            (double)dl_storage_used(g_dl_manager, INSTALL_DATA));
        cJSON_AddNumberToObject(ev, "internalTotal", (double)MO_INTERNAL_TOTAL);
        cJSON_AddNumberToObject(ev, "usbUsed",
            (double)dl_storage_used(g_dl_manager, INSTALL_USB));
        cJSON_AddNumberToObject(ev, "usbTotal", (double)MO_USB_TOTAL);
        cJSON_AddBoolToObject  (ev, "usbMounted",
            dl_usb_mounted(g_dl_manager));

        char *s = cJSON_PrintUnformatted(ev);
        if (s) { http_server_broadcast(srv, s); free(s); }
        cJSON_Delete(ev);

        /* Log DNS stats if changed */
        mo_dns_stats_t dns_now;
        dns_get_stats(&dns_now);
        if (dns_now.queries_sinkholed != dns_prev.queries_sinkholed) {
            LOGI("dns","Stats: total=%llu sinked=%llu fwd=%llu",
                 (unsigned long long)dns_now.queries_total,
                 (unsigned long long)dns_now.queries_sinkholed,
                 (unsigned long long)dns_now.queries_forwarded);
            dns_prev = dns_now;
        }
    }
    return NULL;
}

/* ── Entry point ──────────────────────────────────────────────────────────── */

int main(int argc, char *argv[]) {
    (void)argc; (void)argv;

    /* -- Signals ----------------------------------------------------------- */
    struct sigaction sa = { .sa_handler = sig_handler };
    sigaction(SIGINT,  &sa, NULL);
    sigaction(SIGTERM, &sa, NULL);
    signal(SIGPIPE, SIG_IGN);  /* ignore broken pipe on socket writes */

    /* -- Logger ------------------------------------------------------------ */
    mo_log_init();
    LOGI("main","mo_library.elf v%s starting (firmware target: %s)",
         MO_VERSION, MO_FIRMWARE_TARGET);

    /* -- Catalog ----------------------------------------------------------- */
    g_catalog = catalog_new();
    if (!g_catalog) { LOGE("main","catalog_new() failed"); return 1; }
    catalog_load_builtin(g_catalog);

    /* Optionally load external catalog from USB */
    const char *ext_catalog = "/mnt/usb0/mo_library.json";
    if (access(ext_catalog, R_OK) == 0) {
        LOGI("main","Loading external catalog from %s", ext_catalog);
        catalog_load_file(g_catalog, ext_catalog, NULL);
    }

    /* -- DNS sinkhole ------------------------------------------------------ */
    mo_dns_config_t dns_cfg = {
        .listen_port   = DNS_LISTEN_PORT,
        .upstream_port = DNS_UPSTREAM_PORT,
        .log_queries   = false,
        .log_sinks     = true,
    };
    snprintf(dns_cfg.upstream_ip, sizeof(dns_cfg.upstream_ip), "%s", DNS_UPSTREAM_IP);

    if (!dns_server_start(&dns_cfg)) {
        LOGW("main","DNS sinkhole could not bind :%d (need root or CAP_NET_BIND_SERVICE)",
             DNS_LISTEN_PORT);
        LOGW("main","OTA protection inactive — run as root or redirect port 53 via pf");
    }

    /* -- Download manager -------------------------------------------------- */
    g_dl_manager = dl_manager_new(g_catalog);
    if (!g_dl_manager) { LOGE("main","dl_manager_new() failed"); return 1; }

    /* -- Mod manager ------------------------------------------------------- */
    g_mod_manager = mod_manager_new();
    if (!g_mod_manager) { LOGE("main","mod_manager_new() failed"); return 1; }

    /* Load mod catalog from USB if present */
    const char *ext_mods = "/mnt/usb0/mo_mods.json";
    if (access(ext_mods, R_OK) == 0) {
        LOGI("main","Loading mod catalog from %s", ext_mods);
        mod_load_file(g_mod_manager, ext_mods);
    }

    /* -- PKG installer ----------------------------------------------------- */
    g_pkg_installer = pkg_installer_new();
    if (!g_pkg_installer) { LOGE("main","pkg_installer_new() failed"); return 1; }

    /* -- HTTP server ------------------------------------------------------- */
    mo_http_config_t http_cfg = {
        .port           = MO_DEFAULT_PORT,
        .two_factor     = false,
        .catalog        = g_catalog,
        .dl_manager     = g_dl_manager,
        .mod_manager    = g_mod_manager,
        .pkg_installer  = g_pkg_installer,
    };
    snprintf(http_cfg.password,    sizeof(http_cfg.password),
             "%s", MO_DEFAULT_PASSWORD);
    snprintf(http_cfg.totp_secret, sizeof(http_cfg.totp_secret),
             "%s", MO_TOTP_SECRET);

    g_http_server = http_server_new(&http_cfg);
    if (!g_http_server) { LOGE("main","http_server_new() failed"); return 1; }

    /* Start DL manager with event → broadcast callback */
    if (!dl_manager_start(g_dl_manager, on_dl_event, g_http_server)) {
        LOGE("main","dl_manager_start() failed"); return 1;
    }

    /* Start PKG installer */
    if (!pkg_installer_start(g_pkg_installer, NULL, NULL)) {
        LOGE("main","pkg_installer_start() failed"); return 1;
    }

    if (!http_server_start(g_http_server)) {
        LOGE("main","http_server_start() failed"); return 1;
    }

    /* -- Archive auto-monitor (watch /data/tmp for completed downloads) ---- */
    mo_arch_monitor_cfg_t mon_cfg = {
        .dest_dir         = "/data",
        .delete_after     = true,
        .overwrite        = true,
        .poll_interval_ms = 2000,
    };
    snprintf(mon_cfg.watch_dir, sizeof(mon_cfg.watch_dir), "/data/tmp");
    archive_monitor_start(&mon_cfg);

    /* -- Broadcast thread -------------------------------------------------- */
    pthread_t bcast_tid;
    //pthread_create(&bcast_tid, NULL, broadcast_thread, g_http_server);
    //pthread_detach(bcast_tid);
    (void)bcast_tid;

    LOGI("main","All subsystems online. REST+WS: http://0.0.0.0:%u", MO_DEFAULT_PORT);
    LOGI("main","Catalog: %d titles loaded", catalog_total_count(g_catalog));
    LOGI("main","Mods ready | PKG installer ready");

    /* -- Main loop --------------------------------------------------------- */
    while (!g_shutdown) {
        sleep(1);
    }

    /* -- Shutdown sequence ------------------------------------------------- */
    LOGI("main","Shutdown requested — stopping services");

    //archive_monitor_stop();
    pkg_installer_stop(g_pkg_installer);
    http_server_stop(g_http_server);
    dl_manager_stop(g_dl_manager);
    dns_server_stop();

    http_server_free(g_http_server);
    pkg_installer_free(g_pkg_installer);
    mod_manager_free(g_mod_manager);
    dl_manager_free(g_dl_manager);
    catalog_free(g_catalog);

    LOGI("main","Goodbye");
    return 0;
}
