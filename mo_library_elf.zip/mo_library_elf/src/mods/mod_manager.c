/*
 * mod_manager.c — PS5 Mod Manager
 */
#include "mod_manager.h"
#include "mo_log.h"
#include "fs_util.h"
#include "cJSON.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/stat.h>
#include <errno.h>
#include <dirent.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

/* cJSON Is* helpers (macros removed from header to avoid conflicts) */
#define J_IsString(x)  ((x) && ((x)->type & cJSON_String))
#define J_IsNumber(x)  ((x) && ((x)->type & cJSON_Number))
#define J_IsArray(x)   ((x) && ((x)->type & cJSON_Array))
#define J_IsObject(x)  ((x) && ((x)->type & cJSON_Object))
#define J_IsBool(x)    ((x) && ((x)->type & (cJSON_True|cJSON_False)))
#define J_IsTrue(x)    ((x) && ((x)->type & cJSON_True))

/* ── Internal storage ────────────────────────────────────────────────────── */
#define MAX_MOD_LIBS 32

struct mo_mod_manager {
    mo_mod_t         mods[MOD_MAX_ENTRIES];
    int              mod_count;
    mo_mod_library_t libs[MAX_MOD_LIBS];
    int              lib_count;
    pthread_mutex_t  lock;
};

/* ── String helpers ──────────────────────────────────────────────────────── */

const char *mo_mod_type_str(mo_mod_type_t t) {
    switch (t) {
    case MOD_TYPE_TEXTURE: return "texture";
    case MOD_TYPE_SCRIPT:  return "script";
    case MOD_TYPE_AUDIO:   return "audio";
    case MOD_TYPE_SAVE:    return "save";
    case MOD_TYPE_CHEAT:   return "cheat";
    case MOD_TYPE_PATCH:   return "patch";
    default:               return "misc";
    }
}

const char *mo_mod_state_str(mo_mod_state_t s) {
    switch (s) {
    case MOD_STATE_AVAILABLE:   return "available";
    case MOD_STATE_DOWNLOADING: return "downloading";
    case MOD_STATE_INSTALLED:   return "installed";
    case MOD_STATE_ENABLED:     return "enabled";
    case MOD_STATE_DISABLED:    return "disabled";
    case MOD_STATE_ERROR:       return "error";
    default:                    return "unknown";
    }
}

mo_mod_type_t mo_mod_type_from_str(const char *s) {
    if (!s) return MOD_TYPE_MISC;
    if (strcmp(s, "texture") == 0) return MOD_TYPE_TEXTURE;
    if (strcmp(s, "script")  == 0) return MOD_TYPE_SCRIPT;
    if (strcmp(s, "audio")   == 0) return MOD_TYPE_AUDIO;
    if (strcmp(s, "save")    == 0) return MOD_TYPE_SAVE;
    if (strcmp(s, "cheat")   == 0) return MOD_TYPE_CHEAT;
    if (strcmp(s, "patch")   == 0) return MOD_TYPE_PATCH;
    return MOD_TYPE_MISC;
}

/* ── Lifecycle ───────────────────────────────────────────────────────────── */

mo_mod_manager_t *mod_manager_new(void) {
    mo_mod_manager_t *mgr = calloc(1, sizeof(mo_mod_manager_t));
    if (!mgr) return NULL;
    pthread_mutex_init(&mgr->lock, NULL);
    return mgr;
}

void mod_manager_free(mo_mod_manager_t *mgr) {
    if (!mgr) return;
    pthread_mutex_destroy(&mgr->lock);
    free(mgr);
}

/* ── JSON import ─────────────────────────────────────────────────────────── */

bool mod_import_json(mo_mod_manager_t *mgr, const char *json, size_t len) {
    if (!mgr || !json) return false;
    (void)len;

    cJSON *root = cJSON_Parse(json);
    if (!root) {
        LOGE("mods", "JSON parse error: %s", cJSON_GetErrorPtr());
        return false;
    }

    const cJSON *jlib = cJSON_GetObjectItemCaseSensitive(root, "library");
    const cJSON *jmods = cJSON_GetObjectItemCaseSensitive(root, "mods");

    if (!J_IsObject(jlib) || !J_IsArray(jmods)) {
        LOGE("mods", "Invalid mod JSON: need 'library' and 'mods'");
        cJSON_Delete(root);
        return false;
    }

    pthread_mutex_lock(&mgr->lock);

    /* Register library */
    mo_mod_library_t *lib = NULL;
    if (mgr->lib_count < MAX_MOD_LIBS) {
        lib = &mgr->libs[mgr->lib_count++];
        memset(lib, 0, sizeof(*lib));
        mo_uid(lib->id, sizeof(lib->id), "modlib");
        const cJSON *jname = cJSON_GetObjectItemCaseSensitive(jlib, "name");
        snprintf(lib->name, sizeof(lib->name), "%s",
                 J_IsString(jname) ? jname->valuestring : "Unknown");
        const cJSON *jurl = cJSON_GetObjectItemCaseSensitive(jlib, "url");
        if (J_IsString(jurl))
            snprintf(lib->url, sizeof(lib->url), "%s", jurl->valuestring);
        lib->enabled = true;
    }

    /* Parse mods */
    int added = 0;
    const cJSON *jm;
    cJSON_ArrayForEach(jm, jmods) {
        if (mgr->mod_count >= MOD_MAX_ENTRIES) break;

        mo_mod_t *m = &mgr->mods[mgr->mod_count];
        memset(m, 0, sizeof(*m));

        const cJSON *jid    = cJSON_GetObjectItemCaseSensitive(jm, "id");
        const cJSON *jtid   = cJSON_GetObjectItemCaseSensitive(jm, "titleId");
        const cJSON *jname  = cJSON_GetObjectItemCaseSensitive(jm, "name");
        const cJSON *jauth  = cJSON_GetObjectItemCaseSensitive(jm, "author");
        const cJSON *jver   = cJSON_GetObjectItemCaseSensitive(jm, "version");
        const cJSON *jdesc  = cJSON_GetObjectItemCaseSensitive(jm, "description");
        const cJSON *jtype  = cJSON_GetObjectItemCaseSensitive(jm, "type");
        const cJSON *jsize  = cJSON_GetObjectItemCaseSensitive(jm, "sizeBytes");
        const cJSON *jurl   = cJSON_GetObjectItemCaseSensitive(jm, "url");
        const cJSON *jtags  = cJSON_GetObjectItemCaseSensitive(jm, "tags");

        if (!J_IsString(jname) || !J_IsString(jtid)) continue;

        /* ID */
        if (J_IsString(jid))
            snprintf(m->id, sizeof(m->id), "%s", jid->valuestring);
        else
            mo_uid(m->id, sizeof(m->id), "mod");

        snprintf(m->title_id,    sizeof(m->title_id),    "%s", jtid->valuestring);
        snprintf(m->name,        sizeof(m->name),         "%s", jname->valuestring);
        snprintf(m->author,      sizeof(m->author),       "%s",
                 J_IsString(jauth) ? jauth->valuestring : "Unknown");
        snprintf(m->version,     sizeof(m->version),      "%s",
                 J_IsString(jver) ? jver->valuestring : "1.0");
        snprintf(m->description, sizeof(m->description),  "%s",
                 J_IsString(jdesc) ? jdesc->valuestring : "");
        m->type = mo_mod_type_from_str(
                 J_IsString(jtype) ? jtype->valuestring : "misc");
        m->size_bytes = J_IsNumber(jsize) ? (uint64_t)jsize->valuedouble : 0;
        if (J_IsString(jurl))
            snprintf(m->url, sizeof(m->url), "%s", jurl->valuestring);
        m->state = MOD_STATE_AVAILABLE;
        m->enabled = false;

        /* Install path: /data/mods/<title_id>/<mod_id>/ */
        snprintf(m->install_path, sizeof(m->install_path),
                 "/data/mods/%s/%s", m->title_id, m->id);

        /* Tags */
        if (J_IsArray(jtags)) {
            const cJSON *tag;
            cJSON_ArrayForEach(tag, jtags) {
                if (m->tag_count >= MOD_MAX_TAGS) break;
                if (J_IsString(tag))
                    snprintf(m->tags[m->tag_count++], 32, "%s", tag->valuestring);
            }
        }

        if (lib) snprintf(m->source_lib, sizeof(m->source_lib), "%s", lib->id);

        mgr->mod_count++;
        added++;
    }

    if (lib) lib->mod_count = added;
    pthread_mutex_unlock(&mgr->lock);

    LOGI("mods", "Imported %d mods from library '%s'",
         added, lib ? lib->name : "?");
    cJSON_Delete(root);
    return true;
}

/* ── Load from file ──────────────────────────────────────────────────────── */

bool mod_load_file(mo_mod_manager_t *mgr, const char *path) {
    if (!path) return false;

    uint64_t sz = fs_file_size(path);
    if (sz == 0) { LOGE("mods", "File empty or not found: %s", path); return false; }

    char *buf = malloc(sz + 1);
    if (!buf) return false;

    FILE *f = fopen(path, "rb");
    if (!f) { free(buf); return false; }
    fread(buf, 1, sz, f);
    fclose(f);
    buf[sz] = '\0';

    bool ok = mod_import_json(mgr, buf, sz);
    free(buf);
    return ok;
}

/* ── Fetch from URL ──────────────────────────────────────────────────────── */

bool mod_fetch_url(mo_mod_manager_t *mgr, const char *url) {
    if (!mgr || !url) return false;
    LOGI("mods", "Fetching mod catalog from %s", url);

    /* Parse URL */
    char host[256] = {0}, path[1024] = "/";
    uint16_t port = 80;
    const char *p = url;
    if (strncmp(p,"http://",7)==0) p+=7;

    const char *slash = strchr(p,'/'), *colon = strchr(p,':');
    size_t hl;
    if (colon && (!slash || colon < slash)) {
        hl = (size_t)(colon-p); port=(uint16_t)atoi(colon+1);
    } else hl = slash ? (size_t)(slash-p) : strlen(p);
    if (hl >= sizeof(host)) return false;
    memcpy(host, p, hl);
    if (slash) snprintf(path, sizeof(path), "%s", slash);

    struct addrinfo hints = {.ai_family=AF_INET,.ai_socktype=SOCK_STREAM};
    struct addrinfo *res = NULL;
    char ps[8]; snprintf(ps,sizeof(ps),"%u",port);
    if (getaddrinfo(host, ps, &hints, &res) != 0) {
        LOGE("mods","DNS failed: %s", host); return false;
    }

    int s = socket(AF_INET, SOCK_STREAM, 0);
    struct timeval tv = {.tv_sec=15};
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    setsockopt(s, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));

    if (connect(s, res->ai_addr, res->ai_addrlen) != 0) {
        close(s); freeaddrinfo(res);
        LOGE("mods","Connect failed: %s", host); return false;
    }
    freeaddrinfo(res);

    char req[512];
    int rl = snprintf(req,sizeof(req),
        "GET %s HTTP/1.0\r\nHost: %s\r\nUser-Agent: mo_library/" MO_VERSION "\r\nConnection: close\r\n\r\n",
        path, host);
    send(s, req, (size_t)rl, 0);

    char *buf = malloc(2*1024*1024);
    if (!buf) { close(s); return false; }
    size_t total = 0;
    ssize_t nr;
    while ((nr = recv(s, buf+total, 2*1024*1024-total-1, 0)) > 0)
        total += (size_t)nr;
    close(s);
    buf[total] = '\0';

    char *body = strstr(buf, "\r\n\r\n");
    if (!body) { free(buf); return false; }
    body += 4;
    size_t blen = total - (size_t)(body - buf);
    memmove(buf, body, blen);
    buf[blen] = '\0';

    bool ok = mod_import_json(mgr, buf, blen);
    free(buf);
    return ok;
}

/* ── Query ───────────────────────────────────────────────────────────────── */

int mod_get_for_title(const mo_mod_manager_t *mgr,
                       const char *title_id,
                       mo_mod_t *out, int max_out) {
    if (!mgr || !title_id || !out) return 0;
    int n = 0;
    pthread_mutex_lock((pthread_mutex_t*)&mgr->lock);
    for (int i = 0; i < mgr->mod_count && n < max_out; i++)
        if (strcmp(mgr->mods[i].title_id, title_id) == 0)
            out[n++] = mgr->mods[i];
    pthread_mutex_unlock((pthread_mutex_t*)&mgr->lock);
    return n;
}

int mod_get_all(const mo_mod_manager_t *mgr,
                 mo_mod_type_t type_filter,
                 mo_mod_t *out, int max_out) {
    if (!mgr || !out) return 0;
    int n = 0;
    pthread_mutex_lock((pthread_mutex_t*)&mgr->lock);
    for (int i = 0; i < mgr->mod_count && n < max_out; i++) {
        if (type_filter != MOD_TYPE_MISC && mgr->mods[i].type != type_filter)
            continue;
        out[n++] = mgr->mods[i];
    }
    pthread_mutex_unlock((pthread_mutex_t*)&mgr->lock);
    return n;
}

const mo_mod_t *mod_find(const mo_mod_manager_t *mgr, const char *id) {
    if (!mgr || !id) return NULL;
    for (int i = 0; i < mgr->mod_count; i++)
        if (strcmp(mgr->mods[i].id, id) == 0)
            return &mgr->mods[i];
    return NULL;
}

/* ── Install / Enable / Disable ─────────────────────────────────────────── */

bool mod_install(mo_mod_manager_t *mgr, const char *mod_id) {
    if (!mgr || !mod_id) return false;

    pthread_mutex_lock(&mgr->lock);
    mo_mod_t *m = NULL;
    for (int i = 0; i < mgr->mod_count; i++)
        if (strcmp(mgr->mods[i].id, mod_id) == 0) { m = &mgr->mods[i]; break; }

    if (!m) { pthread_mutex_unlock(&mgr->lock); return false; }
    if (m->state == MOD_STATE_INSTALLED || m->state == MOD_STATE_ENABLED) {
        pthread_mutex_unlock(&mgr->lock);
        LOGW("mods","Mod '%s' already installed", mod_id);
        return true;
    }

    m->state = MOD_STATE_DOWNLOADING;
    char install_path[MOD_MAX_PATH];
    snprintf(install_path, sizeof(install_path), "%s", m->install_path);
    pthread_mutex_unlock(&mgr->lock);

    /* Create install directory */
    if (!fs_mkdirs(install_path)) {
        LOGE("mods","Cannot create mod dir: %s", install_path);
        pthread_mutex_lock(&mgr->lock);
        m->state = MOD_STATE_ERROR;
        pthread_mutex_unlock(&mgr->lock);
        return false;
    }

    LOGI("mods","Installing mod '%s' → %s", mod_id, install_path);

    /*
     * On PS5: download mod->url to install_path/mod.zip, extract, cleanup.
     * In simulation: just mark as installed.
     */

    pthread_mutex_lock(&mgr->lock);
    for (int i = 0; i < mgr->mod_count; i++) {
        if (strcmp(mgr->mods[i].id, mod_id) == 0) {
            mgr->mods[i].state        = MOD_STATE_INSTALLED;
            mgr->mods[i].installed_at = mo_now_ms();
            mgr->mods[i].enabled      = false;
            break;
        }
    }
    pthread_mutex_unlock(&mgr->lock);

    LOGI("mods","Mod '%s' installed", mod_id);
    return true;
}

bool mod_enable(mo_mod_manager_t *mgr, const char *mod_id) {
    if (!mgr || !mod_id) return false;
    pthread_mutex_lock(&mgr->lock);
    bool ok = false;
    for (int i = 0; i < mgr->mod_count; i++) {
        if (strcmp(mgr->mods[i].id, mod_id) == 0) {
            if (mgr->mods[i].state == MOD_STATE_INSTALLED ||
                mgr->mods[i].state == MOD_STATE_DISABLED) {
                mgr->mods[i].state   = MOD_STATE_ENABLED;
                mgr->mods[i].enabled = true;
                ok = true;
                LOGI("mods","Mod '%s' enabled", mod_id);
            }
            break;
        }
    }
    pthread_mutex_unlock(&mgr->lock);
    return ok;
}

bool mod_disable(mo_mod_manager_t *mgr, const char *mod_id) {
    if (!mgr || !mod_id) return false;
    pthread_mutex_lock(&mgr->lock);
    bool ok = false;
    for (int i = 0; i < mgr->mod_count; i++) {
        if (strcmp(mgr->mods[i].id, mod_id) == 0) {
            if (mgr->mods[i].state == MOD_STATE_ENABLED) {
                mgr->mods[i].state   = MOD_STATE_DISABLED;
                mgr->mods[i].enabled = false;
                ok = true;
                LOGI("mods","Mod '%s' disabled", mod_id);
            }
            break;
        }
    }
    pthread_mutex_unlock(&mgr->lock);
    return ok;
}

bool mod_uninstall(mo_mod_manager_t *mgr, const char *mod_id) {
    if (!mgr || !mod_id) return false;
    pthread_mutex_lock(&mgr->lock);
    bool ok = false;
    for (int i = 0; i < mgr->mod_count; i++) {
        if (strcmp(mgr->mods[i].id, mod_id) == 0) {
            mgr->mods[i].state   = MOD_STATE_AVAILABLE;
            mgr->mods[i].enabled = false;
            ok = true;
            LOGI("mods","Mod '%s' uninstalled", mod_id);
            break;
        }
    }
    pthread_mutex_unlock(&mgr->lock);
    return ok;
}

/* ── JSON serializers ────────────────────────────────────────────────────── */

char *mod_catalog_to_json(const mo_mod_manager_t *mgr) {
    cJSON *root = cJSON_CreateObject();
    cJSON *arr  = cJSON_AddArrayToObject(root, "mods");

    pthread_mutex_lock((pthread_mutex_t*)&mgr->lock);
    for (int i = 0; i < mgr->mod_count; i++) {
        const mo_mod_t *m = &mgr->mods[i];
        cJSON *jm = cJSON_CreateObject();
        cJSON_AddStringToObject(jm, "id",          m->id);
        cJSON_AddStringToObject(jm, "titleId",     m->title_id);
        cJSON_AddStringToObject(jm, "name",        m->name);
        cJSON_AddStringToObject(jm, "author",      m->author);
        cJSON_AddStringToObject(jm, "version",     m->version);
        cJSON_AddStringToObject(jm, "description", m->description);
        cJSON_AddStringToObject(jm, "type",        mo_mod_type_str(m->type));
        cJSON_AddStringToObject(jm, "state",       mo_mod_state_str(m->state));
        cJSON_AddNumberToObject(jm, "sizeBytes",   (double)m->size_bytes);
        cJSON_AddStringToObject(jm, "url",         m->url);
        cJSON_AddStringToObject(jm, "installPath", m->install_path);
        cJSON_AddBoolToObject  (jm, "enabled",     m->enabled);
        cJSON_AddNumberToObject(jm, "installedAt", (double)m->installed_at);

        cJSON *tags = cJSON_AddArrayToObject(jm, "tags");
        for (int t = 0; t < m->tag_count; t++)
            cJSON_AddItemToArray(tags, cJSON_CreateString(m->tags[t]));

        cJSON_AddItemToArray(arr, jm);
    }
    pthread_mutex_unlock((pthread_mutex_t*)&mgr->lock);

    char *str = cJSON_PrintUnformatted(root);
    cJSON_Delete(root);
    return str;
}

char *mod_installed_to_json(const mo_mod_manager_t *mgr) {
    cJSON *root = cJSON_CreateObject();
    cJSON *arr  = cJSON_AddArrayToObject(root, "installed");

    pthread_mutex_lock((pthread_mutex_t*)&mgr->lock);
    for (int i = 0; i < mgr->mod_count; i++) {
        const mo_mod_t *m = &mgr->mods[i];
        if (m->state != MOD_STATE_INSTALLED &&
            m->state != MOD_STATE_ENABLED   &&
            m->state != MOD_STATE_DISABLED) continue;

        cJSON *jm = cJSON_CreateObject();
        cJSON_AddStringToObject(jm, "id",          m->id);
        cJSON_AddStringToObject(jm, "titleId",     m->title_id);
        cJSON_AddStringToObject(jm, "name",        m->name);
        cJSON_AddStringToObject(jm, "state",       mo_mod_state_str(m->state));
        cJSON_AddBoolToObject  (jm, "enabled",     m->enabled);
        cJSON_AddStringToObject(jm, "installPath", m->install_path);
        cJSON_AddNumberToObject(jm, "installedAt", (double)m->installed_at);
        cJSON_AddItemToArray(arr, jm);
    }
    pthread_mutex_unlock((pthread_mutex_t*)&mgr->lock);

    char *str = cJSON_PrintUnformatted(root);
    cJSON_Delete(root);
    return str;
}
