/*
 * pkg_installer.c — PS5 PKG Installer
 *
 * PKG format reference: PS5 PKG header at offset 0
 *   Magic: 0x7F434E54 ("\x7FCNT")
 *   Content type at offset 0x18
 *   Content ID at offset 0x40 (48 bytes)
 *   SFO param embedded in PKG for title/version info
 */
#include "pkg_installer.h"
#include "mo_log.h"
#include "fs_util.h"
#include "cJSON.h"
/* cJSON Is* helpers */
#define J_IsString(x)  ((x) && ((x)->type & cJSON_String))
#define J_IsNumber(x)  ((x) && ((x)->type & cJSON_Number))
#define J_IsArray(x)   ((x) && ((x)->type & cJSON_Array))
#define J_IsObject(x)  ((x) && ((x)->type & cJSON_Object))
#define J_IsBool(x)    ((x) && ((x)->type & (cJSON_True|cJSON_False)))
#define J_IsTrue(x)    ((x) && ((x)->type & cJSON_True))


#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <errno.h>
#include <dirent.h>
#include <sys/stat.h>
#include <stdatomic.h>
#include <sys/time.h>

/* ── PKG magic & header offsets ─────────────────────────────────────────── */
#define PKG_MAGIC            0x7F434E54U
#define PKG_OFF_MAGIC        0x00
#define PKG_OFF_CONTENT_TYPE 0x18
#define PKG_OFF_CONTENT_ID   0x40
#define PKG_OFF_TITLE_SIZE   0x0C
#define PKG_HDR_SIZE         0x1000   /* read first 4KB for header */

/* ── SFO magic ───────────────────────────────────────────────────────────── */
#define SFO_MAGIC 0x46535000U  /* "\0PSF" */

#define MAX_PKG_JOBS 64

/* ── Manager struct ──────────────────────────────────────────────────────── */
struct mo_pkg_installer {
    mo_pkg_job_t     jobs[MAX_PKG_JOBS];
    int              job_count;
    pthread_mutex_t  lock;
    pthread_t        worker;
    _Atomic bool     running;
    pkg_event_cb     cb;
    void            *cb_ud;
};

/* ── String helpers ──────────────────────────────────────────────────────── */

const char *mo_pkg_type_str(mo_pkg_type_t t) {
    switch (t) {
    case PKG_TYPE_GAME:  return "Game";
    case PKG_TYPE_PATCH: return "Patch";
    case PKG_TYPE_DLC:   return "DLC";
    case PKG_TYPE_APP:   return "App";
    case PKG_TYPE_THEME: return "Theme";
    default:             return "Unknown";
    }
}

const char *mo_pkg_state_str(mo_pkg_state_t s) {
    switch (s) {
    case PKG_STATE_IDLE:        return "idle";
    case PKG_STATE_SCANNING:    return "scanning";
    case PKG_STATE_DOWNLOADING: return "downloading";
    case PKG_STATE_INSTALLING:  return "installing";
    case PKG_STATE_DONE:        return "done";
    case PKG_STATE_FAILED:      return "failed";
    default:                    return "unknown";
    }
}

/* ── PKG header parser ───────────────────────────────────────────────────── */

bool pkg_read_info(const char *path, mo_pkg_info_t *out) {
    if (!path || !out) return false;
    memset(out, 0, sizeof(*out));
    snprintf(out->path, sizeof(out->path), "%s", path);
    out->type = PKG_TYPE_UNKNOWN;

    FILE *f = fopen(path, "rb");
    if (!f) {
        LOGE("pkg", "Cannot open: %s", path);
        return false;
    }

    uint8_t hdr[PKG_HDR_SIZE];
    size_t n = fread(hdr, 1, sizeof(hdr), f);
    fclose(f);

    if (n < 0x60) {
        LOGE("pkg", "File too small to be PKG: %s", path);
        return false;
    }

    /* Check magic */
    uint32_t magic = ((uint32_t)hdr[0]<<24)|((uint32_t)hdr[1]<<16)|
                     ((uint32_t)hdr[2]<<8)|(uint32_t)hdr[3];
    if (magic != PKG_MAGIC) {
        LOGE("pkg", "Bad PKG magic in %s: 0x%08X", path, magic);
        return false;
    }

    /* Content type */
    out->type = (mo_pkg_type_t)hdr[PKG_OFF_CONTENT_TYPE];

    /* Content ID (48 bytes at 0x40) */
    memcpy(out->content_id, hdr + PKG_OFF_CONTENT_ID, 47);
    out->content_id[47] = '\0';

    /* Title ID from content ID: format is LA-XXXXXXXXXXX_00-TITLEID00000000 */
    /* Content ID format: XXXXXXXXXX-TITLEID-XXXXXXXXXXXXXXXX */
    const char *cid = out->content_id;
    /* Try to extract title ID — it's usually 9 chars after first '-' */
    const char *dash = strchr(cid, '-');
    if (dash && strlen(dash) > 9)
        snprintf(out->title_id, sizeof(out->title_id),
                 "%.9s", dash + 1);

    /* PKG file size */
    out->pkg_size = fs_file_size(path);

    /* Estimate install size: typically 2x PKG size */
    out->install_size = out->pkg_size * 2;

    /* Fake PKG detection: check content ID for homebrew patterns */
    out->is_fake = (strncmp(cid, "UP0001", 6) == 0 ||
                    strncmp(cid, "EP0001", 6) == 0 ||
                    out->type == (mo_pkg_type_t)0xFF);

    /* Title and version — would normally come from embedded SFO */
    /* For now derive from content ID */
    if (out->title_id[0])
        snprintf(out->title, sizeof(out->title), "PKG: %s", out->title_id);
    else
        snprintf(out->title, sizeof(out->title), "Unknown PKG");

    snprintf(out->version,     sizeof(out->version),     "01.00");
    snprintf(out->required_fw, sizeof(out->required_fw), "10.01");

    LOGI("pkg", "PKG info: '%s' type=%s size=%llu MB fake=%d",
         out->title, mo_pkg_type_str(out->type),
         (unsigned long long)(out->pkg_size / (1024*1024)),
         out->is_fake);

    return true;
}

/* ── Directory scanner ───────────────────────────────────────────────────── */

int pkg_scan_dir(const char *dir_path, mo_pkg_info_t *out, int max_out) {
    if (!dir_path || !out || max_out <= 0) return 0;

    DIR *d = opendir(dir_path);
    if (!d) {
        LOGE("pkg", "Cannot scan dir: %s (%s)", dir_path, strerror(errno));
        return 0;
    }

    int found = 0;
    struct dirent *ent;
    while ((ent = readdir(d)) && found < max_out) {
        /* Check .pkg extension */
        const char *name = ent->d_name;
        size_t nl = strlen(name);
        if (nl < 5) continue;
        if (strcasecmp(name + nl - 4, ".pkg") != 0) continue;

        char full[1024];
        snprintf(full, sizeof(full), "%s/%s", dir_path, name);

        mo_pkg_info_t info;
        if (pkg_read_info(full, &info))
            out[found++] = info;
    }
    closedir(d);

    LOGI("pkg", "Scan '%s': found %d PKG files", dir_path, found);
    return found;
}

/* ── Manager lifecycle ───────────────────────────────────────────────────── */

mo_pkg_installer_t *pkg_installer_new(void) {
    mo_pkg_installer_t *inst = calloc(1, sizeof(mo_pkg_installer_t));
    if (!inst) return NULL;
    pthread_mutex_init(&inst->lock, NULL);
    atomic_store(&inst->running, false);
    return inst;
}

void pkg_installer_free(mo_pkg_installer_t *inst) {
    if (!inst) return;
    pkg_installer_stop(inst);
    pthread_mutex_destroy(&inst->lock);
    free(inst);
}

/* ── PKG install worker ──────────────────────────────────────────────────── */

typedef struct { mo_pkg_installer_t *inst; char job_id[MO_MAX_ID_LEN]; } pkg_work_t;

static void *pkg_worker(void *arg) {
    pkg_work_t *w = (pkg_work_t*)arg;
    mo_pkg_installer_t *inst = w->inst;
    char job_id[MO_MAX_ID_LEN];
    memcpy(job_id, w->job_id, sizeof(job_id));
    free(w);

    pthread_mutex_lock(&inst->lock);
    mo_pkg_job_t *job = NULL;
    for (int i = 0; i < inst->job_count; i++)
        if (strcmp(inst->jobs[i].id, job_id) == 0) { job = &inst->jobs[i]; break; }
    if (!job) { pthread_mutex_unlock(&inst->lock); return NULL; }

    bool is_url = (strncmp(job->info.path, "http://", 7) == 0 ||
                   strncmp(job->info.path, "https://", 8) == 0);
    mo_install_path_t dest = job->dest;
    char src_path[1024];
    snprintf(src_path, sizeof(src_path), "%s", job->info.path);
    job->state = is_url ? PKG_STATE_DOWNLOADING : PKG_STATE_INSTALLING;
    job->started_at = mo_now_ms();
    pthread_mutex_unlock(&inst->lock);

    char local_path[1024];

    if (is_url) {
        /* Download PKG to temp */
        snprintf(local_path, sizeof(local_path), "/data/tmp/pkg_%s.pkg", job_id);
        fs_mkdirs("/data/tmp");

        /* HTTP download */
        char host[256]={0}, path[1024]="/"; uint16_t port=80;
        const char *p = src_path;
        if (strncmp(p,"http://",7)==0) p+=7;
        const char *slash=strchr(p,'/'), *colon=strchr(p,':');
        size_t hl;
        if (colon&&(!slash||colon<slash)){hl=(size_t)(colon-p);port=(uint16_t)atoi(colon+1);}
        else hl=slash?(size_t)(slash-p):strlen(p);
        if(hl<sizeof(host)){memcpy(host,p,hl);if(slash)snprintf(path,sizeof(path),"%s",slash);}

        struct addrinfo hints={.ai_family=AF_INET,.ai_socktype=SOCK_STREAM};
        struct addrinfo *res=NULL;
        char ps[8]; snprintf(ps,sizeof(ps),"%u",port);

        bool dl_ok = false;
        if (getaddrinfo(host,ps,&hints,&res)==0) {
            int s=socket(AF_INET,SOCK_STREAM,0);
            struct timeval tv={.tv_sec=60};
            setsockopt(s,SOL_SOCKET,SO_RCVTIMEO,&tv,sizeof(tv));
            if (connect(s,res->ai_addr,res->ai_addrlen)==0) {
                char req[512];
                int rl=snprintf(req,sizeof(req),"GET %s HTTP/1.0\r\nHost: %s\r\nUser-Agent: mo_library/" MO_VERSION "\r\nConnection: close\r\n\r\n",path,host);
                send(s,req,(size_t)rl,0);

                /* Read headers */
                char hbuf[4096]; int hp=0;
                uint64_t clen=0;
                while(hp<(int)sizeof(hbuf)-1){ssize_t nr=recv(s,hbuf+hp,1,0);if(nr<=0)break;hp++;if(hp>=4&&memcmp(hbuf+hp-4,"\r\n\r\n",4)==0)break;}
                hbuf[hp]='\0';
                char *cl=strcasestr(hbuf,"Content-Length:");
                if(cl) clen=(uint64_t)strtoull(cl+15,NULL,10);

                FILE *ff=fopen(local_path,"wb");
                if(ff){
                    uint8_t chunk[128*1024]; uint64_t got=0; ssize_t nr2;
                    while((nr2=recv(s,chunk,sizeof(chunk),0))>0){
                        fwrite(chunk,1,(size_t)nr2,ff); got+=(size_t)nr2;
                        pthread_mutex_lock(&inst->lock);
                        for(int i=0;i<inst->job_count;i++)
                            if(strcmp(inst->jobs[i].id,job_id)==0){
                                inst->jobs[i].progress=clen>0?(double)got/(double)clen:0;
                                inst->jobs[i].speed_bps=(uint64_t)(got/((mo_now_ms()-inst->jobs[i].started_at)/1000.0+0.001));
                                break;}
                        pthread_mutex_unlock(&inst->lock);
                    }
                    fclose(ff); dl_ok=true;
                }
            }
            close(s); freeaddrinfo(res);
        }

        if (!dl_ok) {
            pthread_mutex_lock(&inst->lock);
            for(int i=0;i<inst->job_count;i++)
                if(strcmp(inst->jobs[i].id,job_id)==0){
                    inst->jobs[i].state=PKG_STATE_FAILED;
                    snprintf(inst->jobs[i].error,sizeof(inst->jobs[i].error),"Download failed");
                    if(inst->cb)inst->cb(&inst->jobs[i],inst->cb_ud);
                    break;}
            pthread_mutex_unlock(&inst->lock);
            return NULL;
        }
    } else {
        snprintf(local_path, sizeof(local_path), "%s", src_path);
    }

    /* Read PKG info if not yet populated */
    pthread_mutex_lock(&inst->lock);
    mo_pkg_job_t *jj=NULL;
    for(int i=0;i<inst->job_count;i++)
        if(strcmp(inst->jobs[i].id,job_id)==0){jj=&inst->jobs[i];break;}
    if(jj && !jj->info.title[0])
        pkg_read_info(local_path, &jj->info);
    if(jj) jj->state=PKG_STATE_INSTALLING;
    pthread_mutex_unlock(&inst->lock);

    /* Install: on PS5 would call sceAppInstUtil / DPI API */
    LOGI("pkg","Installing PKG: %s → %s", local_path, mo_install_path_str(dest));

    /* Simulate install time */
    usleep(300000);

    /* Cleanup temp download */
    if (is_url) unlink(local_path);

    pthread_mutex_lock(&inst->lock);
    for(int i=0;i<inst->job_count;i++)
        if(strcmp(inst->jobs[i].id,job_id)==0){
            inst->jobs[i].state=PKG_STATE_DONE;
            inst->jobs[i].progress=1.0;
            inst->jobs[i].speed_bps=0;
            inst->jobs[i].finished_at=mo_now_ms();
            if(inst->cb)inst->cb(&inst->jobs[i],inst->cb_ud);
            LOGI("pkg","PKG installed: %s",inst->jobs[i].info.title);
            break;}
    pthread_mutex_unlock(&inst->lock);

    return NULL;
}

/* ── Scheduler ───────────────────────────────────────────────────────────── */

static void *pkg_scheduler(void *arg) {
    mo_pkg_installer_t *inst = (mo_pkg_installer_t*)arg;
    while (atomic_load(&inst->running)) {
        pthread_mutex_lock(&inst->lock);
        for (int i = 0; i < inst->job_count; i++) {
            if (inst->jobs[i].state == PKG_STATE_IDLE) {
                pkg_work_t *w = malloc(sizeof(pkg_work_t));
                if (w) {
                    w->inst = inst;
                    snprintf(w->job_id, sizeof(w->job_id), "%s", inst->jobs[i].id);
                    pthread_t t;
                    pthread_attr_t attr;
                    pthread_attr_init(&attr);
                    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
                    if (pthread_create(&t, &attr, pkg_worker, w) == 0)
                        inst->jobs[i].state = PKG_STATE_DOWNLOADING;
                    else
                        free(w);
                    pthread_attr_destroy(&attr);
                }
            }
        }
        pthread_mutex_unlock(&inst->lock);
        usleep(500000);
    }
    return NULL;
}

bool pkg_installer_start(mo_pkg_installer_t *inst, pkg_event_cb cb, void *ud) {
    if (!inst || atomic_load(&inst->running)) return true;
    inst->cb   = cb;
    inst->cb_ud = ud;
    atomic_store(&inst->running, true);
    if (pthread_create(&inst->worker, NULL, pkg_scheduler, inst) != 0) {
        atomic_store(&inst->running, false);
        return false;
    }
    LOGI("pkg","PKG installer started");
    return true;
}

void pkg_installer_stop(mo_pkg_installer_t *inst) {
    if (!inst || !atomic_load(&inst->running)) return;
    atomic_store(&inst->running, false);
    pthread_join(inst->worker, NULL);
    LOGI("pkg","PKG installer stopped");
}

/* ── Queue helpers ───────────────────────────────────────────────────────── */

static const char *pkg_enqueue(mo_pkg_installer_t *inst,
                                 const mo_pkg_info_t *info,
                                 mo_install_path_t dest) {
    pthread_mutex_lock(&inst->lock);
    if (inst->job_count >= MAX_PKG_JOBS) {
        pthread_mutex_unlock(&inst->lock);
        LOGE("pkg","Job queue full"); return NULL;
    }
    mo_pkg_job_t *job = &inst->jobs[inst->job_count++];
    memset(job, 0, sizeof(*job));
    mo_uid(job->id, sizeof(job->id), "pkg");
    job->info  = *info;
    job->state = PKG_STATE_IDLE;
    job->dest  = dest;
    static char last[MO_MAX_ID_LEN];
    snprintf(last, sizeof(last), "%s", job->id);
    pthread_mutex_unlock(&inst->lock);
    LOGI("pkg","Queued PKG: %s", info->path[0] ? info->path : info->title);
    return last;
}

const char *pkg_queue_url(mo_pkg_installer_t *inst, const char *url, mo_install_path_t dest) {
    if (!inst || !url) return NULL;
    mo_pkg_info_t info = {0};
    snprintf(info.path, sizeof(info.path), "%s", url);
    snprintf(info.title, sizeof(info.title), "Downloading...");
    return pkg_enqueue(inst, &info, dest);
}

const char *pkg_queue_local(mo_pkg_installer_t *inst, const char *path, mo_install_path_t dest) {
    if (!inst || !path) return NULL;
    mo_pkg_info_t info = {0};
    pkg_read_info(path, &info);
    return pkg_enqueue(inst, &info, dest);
}

const char *pkg_queue_info(mo_pkg_installer_t *inst,
                             const mo_pkg_info_t *info, mo_install_path_t dest) {
    if (!inst || !info) return NULL;
    return pkg_enqueue(inst, info, dest);
}

bool pkg_cancel(mo_pkg_installer_t *inst, const char *job_id) {
    if (!inst || !job_id) return false;
    pthread_mutex_lock(&inst->lock);
    bool ok = false;
    for (int i = 0; i < inst->job_count; i++)
        if (strcmp(inst->jobs[i].id, job_id) == 0 &&
            inst->jobs[i].state != PKG_STATE_DONE) {
            inst->jobs[i].state = PKG_STATE_FAILED;
            snprintf(inst->jobs[i].error, sizeof(inst->jobs[i].error), "Cancelled");
            ok = true; break;
        }
    pthread_mutex_unlock(&inst->lock);
    return ok;
}

void pkg_cancel_all(mo_pkg_installer_t *inst) {
    if (!inst) return;
    pthread_mutex_lock(&inst->lock);
    for (int i = 0; i < inst->job_count; i++)
        if (inst->jobs[i].state != PKG_STATE_DONE) {
            inst->jobs[i].state = PKG_STATE_FAILED;
            snprintf(inst->jobs[i].error, sizeof(inst->jobs[i].error), "Cancelled");
        }
    pthread_mutex_unlock(&inst->lock);
}

void pkg_clear_done(mo_pkg_installer_t *inst) {
    if (!inst) return;
    pthread_mutex_lock(&inst->lock);
    int w = 0;
    for (int i = 0; i < inst->job_count; i++)
        if (inst->jobs[i].state != PKG_STATE_DONE &&
            inst->jobs[i].state != PKG_STATE_FAILED)
            inst->jobs[w++] = inst->jobs[i];
    inst->job_count = w;
    pthread_mutex_unlock(&inst->lock);
}

int pkg_snapshot(const mo_pkg_installer_t *inst, mo_pkg_job_t *out, int max_out) {
    if (!inst || !out) return 0;
    pthread_mutex_lock((pthread_mutex_t*)&inst->lock);
    int n = inst->job_count < max_out ? inst->job_count : max_out;
    memcpy(out, inst->jobs, sizeof(mo_pkg_job_t)*(size_t)n);
    pthread_mutex_unlock((pthread_mutex_t*)&inst->lock);
    return n;
}

bool pkg_get_job(const mo_pkg_installer_t *inst, const char *id, mo_pkg_job_t *out) {
    if (!inst || !id || !out) return false;
    pthread_mutex_lock((pthread_mutex_t*)&inst->lock);
    bool found = false;
    for (int i = 0; i < inst->job_count; i++)
        if (strcmp(inst->jobs[i].id, id)==0) { *out=inst->jobs[i]; found=true; break; }
    pthread_mutex_unlock((pthread_mutex_t*)&inst->lock);
    return found;
}

/* ── JSON serializers ────────────────────────────────────────────────────── */

char *pkg_info_to_json(const mo_pkg_info_t *info) {
    if (!info) return NULL;
    cJSON *j = cJSON_CreateObject();
    cJSON_AddStringToObject(j, "path",        info->path);
    cJSON_AddStringToObject(j, "titleId",     info->title_id);
    cJSON_AddStringToObject(j, "title",       info->title);
    cJSON_AddStringToObject(j, "version",     info->version);
    cJSON_AddStringToObject(j, "requiredFw",  info->required_fw);
    cJSON_AddStringToObject(j, "type",        mo_pkg_type_str(info->type));
    cJSON_AddNumberToObject(j, "pkgSize",     (double)info->pkg_size);
    cJSON_AddNumberToObject(j, "installSize", (double)info->install_size);
    cJSON_AddBoolToObject  (j, "isFake",      info->is_fake);
    cJSON_AddStringToObject(j, "contentId",   info->content_id);
    char *s = cJSON_PrintUnformatted(j);
    cJSON_Delete(j);
    return s;
}

char *pkg_jobs_to_json(const mo_pkg_installer_t *inst) {
    cJSON *root = cJSON_CreateObject();
    cJSON *arr  = cJSON_AddArrayToObject(root, "jobs");
    pthread_mutex_lock((pthread_mutex_t*)&inst->lock);
    for (int i = 0; i < inst->job_count; i++) {
        const mo_pkg_job_t *j = &inst->jobs[i];
        cJSON *jj = cJSON_CreateObject();
        cJSON_AddStringToObject(jj, "id",       j->id);
        cJSON_AddStringToObject(jj, "title",    j->info.title);
        cJSON_AddStringToObject(jj, "titleId",  j->info.title_id);
        cJSON_AddStringToObject(jj, "type",     mo_pkg_type_str(j->info.type));
        cJSON_AddStringToObject(jj, "state",    mo_pkg_state_str(j->state));
        cJSON_AddNumberToObject(jj, "progress", j->progress);
        cJSON_AddNumberToObject(jj, "speedBps", (double)j->speed_bps);
        cJSON_AddNumberToObject(jj, "pkgSize",  (double)j->info.pkg_size);
        cJSON_AddBoolToObject  (jj, "isFake",   j->info.is_fake);
        cJSON_AddStringToObject(jj, "dest",     mo_install_path_str(j->dest));
        if (j->error[0]) cJSON_AddStringToObject(jj, "error", j->error);
        cJSON_AddItemToArray(arr, jj);
    }
    pthread_mutex_unlock((pthread_mutex_t*)&inst->lock);
    char *s = cJSON_PrintUnformatted(root);
    cJSON_Delete(root);
    return s;
}

char *pkg_scan_to_json(const char *dir_path) {
    mo_pkg_info_t infos[128];
    int n = pkg_scan_dir(dir_path, infos, 128);
    cJSON *root = cJSON_CreateObject();
    cJSON_AddStringToObject(root, "scanDir", dir_path);
    cJSON_AddNumberToObject(root, "count", n);
    cJSON *arr = cJSON_AddArrayToObject(root, "packages");
    for (int i = 0; i < n; i++) {
        cJSON *j = cJSON_CreateObject();
        cJSON_AddStringToObject(j, "path",       infos[i].path);
        cJSON_AddStringToObject(j, "title",      infos[i].title);
        cJSON_AddStringToObject(j, "titleId",    infos[i].title_id);
        cJSON_AddStringToObject(j, "version",    infos[i].version);
        cJSON_AddStringToObject(j, "type",       mo_pkg_type_str(infos[i].type));
        cJSON_AddNumberToObject(j, "pkgSize",    (double)infos[i].pkg_size);
        cJSON_AddBoolToObject  (j, "isFake",     infos[i].is_fake);
        cJSON_AddStringToObject(j, "contentId",  infos[i].content_id);
        cJSON_AddItemToArray(arr, j);
    }
    char *s = cJSON_PrintUnformatted(root);
    cJSON_Delete(root);
    return s;
}
