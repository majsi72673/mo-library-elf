/*
 * fs_util.c — Filesystem helpers
 */
#include "fs_util.h"
#include "mo_log.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <errno.h>
#include <unistd.h>

bool fs_mkdirs(const char *path) {
    if (!path || !path[0]) return false;

    char tmp[1024];
    snprintf(tmp, sizeof(tmp), "%s", path);
    size_t len = strlen(tmp);
    if (tmp[len - 1] == '/') tmp[--len] = '\0';

    for (size_t i = 1; i <= len; i++) {
        if (tmp[i] == '/' || tmp[i] == '\0') {
            char c = tmp[i];
            tmp[i] = '\0';
            if (mkdir(tmp, 0755) < 0 && errno != EEXIST) {
                LOGE("fs", "mkdir('%s'): %s", tmp, strerror(errno));
                return false;
            }
            tmp[i] = c;
        }
    }
    return true;
}

bool fs_file_exists(const char *path) {
    if (!path) return false;
    struct stat st;
    return stat(path, &st) == 0 && S_ISREG(st.st_mode);
}

uint64_t fs_file_size(const char *path) {
    if (!path) return 0;
    struct stat st;
    if (stat(path, &st) < 0) return 0;
    return (uint64_t)st.st_size;
}

uint64_t fs_mtime_ms(const char *path) {
    if (!path) return 0;
    struct stat st;
    if (stat(path, &st) < 0) return 0;
#if defined(__APPLE__)
    return (uint64_t)st.st_mtimespec.tv_sec  * 1000ULL
         + (uint64_t)st.st_mtimespec.tv_nsec / 1000000ULL;
#elif defined(__FreeBSD__) || defined(__PS5__)
    return (uint64_t)st.st_mtim.tv_sec  * 1000ULL
         + (uint64_t)st.st_mtim.tv_nsec / 1000000ULL;
#else
    return (uint64_t)st.st_mtim.tv_sec  * 1000ULL
         + (uint64_t)st.st_mtim.tv_nsec / 1000000ULL;
#endif
}
