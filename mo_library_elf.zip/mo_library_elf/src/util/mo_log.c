/*
 * mo_log.c — Ring-buffer logger + TOTP + Auth
 */
#include "mo_log.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <time.h>
#include <pthread.h>

/* ── Ring buffer ─────────────────────────────────────────────────────────────── */
static mo_log_entry_t  s_ring[MO_MAX_LOGS];
static int             s_head = 0;   /* next write position */
static int             s_count = 0;  /* entries in buffer   */
static pthread_mutex_t s_mutex = PTHREAD_MUTEX_INITIALIZER;
static uint64_t        s_seq = 0;

void mo_log_init(void) {
    pthread_mutex_lock(&s_mutex);
    memset(s_ring, 0, sizeof(s_ring));
    s_head = s_count = 0;
    s_seq = 0;
    pthread_mutex_unlock(&s_mutex);
}

void mo_log(mo_log_level_t level, const char *source, const char *fmt, ...) {
    mo_log_entry_t entry;
    va_list ap;

    memset(&entry, 0, sizeof(entry));
    entry.ts    = mo_now_ms();
    entry.level = level;
    snprintf(entry.source, sizeof(entry.source), "%s", source ? source : "?");

    va_start(ap, fmt);
    vsnprintf(entry.message, sizeof(entry.message), fmt, ap);
    va_end(ap);

    /* Print to stderr as well (visible in UART / serial logs) */
    fprintf(stderr, "[%s] %s: %s\n",
            mo_log_level_str(level), entry.source, entry.message);
    fflush(stderr);

    pthread_mutex_lock(&s_mutex);
    mo_uid(entry.id, sizeof(entry.id), "log");
    s_ring[s_head] = entry;
    s_head = (s_head + 1) % MO_MAX_LOGS;
    if (s_count < MO_MAX_LOGS) s_count++;
    s_seq++;
    pthread_mutex_unlock(&s_mutex);
}

int mo_log_snapshot(mo_log_entry_t *out, int max_out) {
    if (!out || max_out <= 0) return 0;

    pthread_mutex_lock(&s_mutex);
    int n = s_count < max_out ? s_count : max_out;
    /* Read oldest → newest */
    int start = (s_count < MO_MAX_LOGS)
                    ? 0
                    : s_head;  /* s_head points to oldest when full */
    for (int i = 0; i < n; i++) {
        out[i] = s_ring[(start + i) % MO_MAX_LOGS];
    }
    pthread_mutex_unlock(&s_mutex);
    return n;
}

char *mo_log_export(void) {
    mo_log_entry_t buf[MO_MAX_LOGS];
    int n = mo_log_snapshot(buf, MO_MAX_LOGS);

    /* Estimate: each line ~128 chars */
    size_t cap = (size_t)n * 160 + 1;
    char *out = malloc(cap);
    if (!out) return NULL;
    out[0] = '\0';

    size_t pos = 0;
    for (int i = 0; i < n; i++) {
        char line[512];
        /* ISO-8601 approximation from ms epoch */
        time_t sec = (time_t)(buf[i].ts / 1000);
        struct tm tm_val;
        gmtime_r(&sec, &tm_val);
        char tsbuf[32];
        strftime(tsbuf, sizeof(tsbuf), "%Y-%m-%dT%H:%M:%SZ", &tm_val);

        int written = snprintf(line, sizeof(line), "%s [%s] %s: %s\n",
                               tsbuf,
                               mo_log_level_str(buf[i].level),
                               buf[i].source,
                               buf[i].message);
        if (written > 0 && pos + (size_t)written < cap) {
            memcpy(out + pos, line, (size_t)written);
            pos += (size_t)written;
        }
    }
    out[pos] = '\0';
    return out;
}

void mo_log_clear(void) {
    pthread_mutex_lock(&s_mutex);
    memset(s_ring, 0, sizeof(s_ring));
    s_head = s_count = 0;
    pthread_mutex_unlock(&s_mutex);
}

/* ── TOTP (FNV-1a based, matching web app demoTotp) ─────────────────────────── */

static uint32_t fnv1a_str(const char *s) {
    uint32_t h = 2166136261UL;
    while (*s) {
        h ^= (uint8_t)*s++;
        h *= 16777619UL;
    }
    return h;
}

void mo_totp_generate(const char *secret, uint64_t epoch_ms, char out[7]) {
    uint64_t window = epoch_ms / 30000ULL;
    char key[128];
    snprintf(key, sizeof(key), "%s:%llu", secret,
             (unsigned long long)window);
    uint32_t h = fnv1a_str(key);
    snprintf(out, 7, "%06u", (unsigned)(h % 1000000U));
}

int mo_totp_remaining_seconds(uint64_t epoch_ms) {
    return (int)(30 - ((epoch_ms / 1000ULL) % 30ULL));
}

/* ── Auth ────────────────────────────────────────────────────────────────────── */

void mo_auth_init(mo_auth_t *a, const char *password, const char *totp_secret) {
    memset(a, 0, sizeof(*a));
    snprintf(a->password,    sizeof(a->password),    "%s",
             password    ? password    : MO_DEFAULT_PASSWORD);
    snprintf(a->totp_secret, sizeof(a->totp_secret), "%s",
             totp_secret ? totp_secret : MO_TOTP_SECRET);
    a->two_factor_enabled = false;
    a->authed = false;
}

/*
 * BUG FIX: constant-time string comparison to eliminate timing oracle.
 * strcmp() short-circuits on mismatch, leaking prefix length via timing.
 * This implementation always visits every byte of both strings.
 */
static int ct_strcmp(const char *a, const char *b) {
    int diff = 0;
    size_t la = strlen(a);
    size_t lb = strlen(b);
    /* XOR lengths so different-length strings always fail */
    diff |= (int)(la ^ lb);
    size_t n = la < lb ? la : lb;
    for (size_t i = 0; i < n; i++)
        diff |= (unsigned char)a[i] ^ (unsigned char)b[i];
    return diff; /* 0 iff equal */
}

mo_auth_result_t mo_auth_login(mo_auth_t *a,
                                 const char *password,
                                 const char *totp_code) {
    if (!a || !password) return AUTH_BAD_PASSWORD;

    /* BUG FIX: constant-time compare — no timing oracle */
    if (ct_strcmp(password, a->password) != 0)
        return AUTH_BAD_PASSWORD;

    if (a->two_factor_enabled) {
        if (!totp_code) return AUTH_BAD_TOTP;

        uint64_t now = mo_now_ms();
        bool totp_ok = false;

        /*
         * BUG FIX: check current window AND ±1 adjacent windows
         * to handle clock skew between client and payload.
         * Each window is 30 000 ms; offsets: -30s, 0, +30s.
         */
        int64_t offsets[3] = { -30000LL, 0LL, 30000LL };
        for (int i = 0; i < 3 && !totp_ok; i++) {
            char expected[7];
            uint64_t t = (uint64_t)((int64_t)now + offsets[i]);
            mo_totp_generate(a->totp_secret, t, expected);
            if (ct_strcmp(totp_code, expected) == 0)
                totp_ok = true;
        }
        if (!totp_ok) return AUTH_BAD_TOTP;
    }

    a->authed = true;
    mo_log(LOG_INFO, "auth", "Owner session opened");
    return AUTH_OK;
}

void mo_auth_logout(mo_auth_t *a) {
    if (a) a->authed = false;
}

void mo_auth_set_password(mo_auth_t *a, const char *new_pw) {
    if (!a || !new_pw) return;
    snprintf(a->password, sizeof(a->password), "%s", new_pw);
    mo_log(LOG_INFO, "auth", "Owner password rotated");
}

void mo_auth_set_two_factor(mo_auth_t *a, bool enabled) {
    if (!a) return;
    a->two_factor_enabled = enabled;
    mo_log(LOG_INFO, "auth", enabled ? "2FA enabled" : "2FA disabled");
}
