/*
 * mo_types.c — String helpers, UID generation, formatting
 */
#include "mo_types.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>

/* ── Enum → string ─────────────────────────────────────────────────────────── */

const char *mo_format_str(mo_format_t f) {
    switch (f) {
    case FMT_FPKG:  return "FPKG";
    case FMT_FFPKG: return "FFPKG";
    case FMT_EXFAT: return "EXFAT";
    case FMT_FFPFS: return "FFPFS";
    case FMT_DUMP:  return "Dump";
    case FMT_ZIP:   return "zip";
    case FMT_7Z:    return "7z";
    case FMT_RAR:   return "rar";
    default:        return "unknown";
    }
}

const char *mo_category_str(mo_category_t c) {
    switch (c) {
    case CAT_GAME:     return "game";
    case CAT_DLC:      return "dlc";
    case CAT_UPDATE:   return "update";
    case CAT_BACKPORT: return "backport";
    case CAT_PACKAGE:  return "package";
    default:           return "unknown";
    }
}

const char *mo_region_str(mo_region_t r) {
    switch (r) {
    case REGION_US:   return "US";
    case REGION_EU:   return "EU";
    case REGION_JP:   return "JP";
    case REGION_ASIA: return "ASIA";
    default:          return "UNKNOWN";
    }
}

const char *mo_job_status_str(mo_job_status_t s) {
    switch (s) {
    case JOB_QUEUED:        return "queued";
    case JOB_DOWNLOADING:   return "downloading";
    case JOB_DECOMPRESSING: return "decompressing";
    case JOB_INSTALLING:    return "installing";
    case JOB_PAUSED:        return "paused";
    case JOB_COMPLETED:     return "completed";
    case JOB_FAILED:        return "failed";
    case JOB_CANCELLED:     return "cancelled";
    default:                return "unknown";
    }
}

const char *mo_log_level_str(mo_log_level_t l) {
    switch (l) {
    case LOG_INFO:  return "info";
    case LOG_WARN:  return "warn";
    case LOG_ERROR: return "error";
    default:        return "info";
    }
}

const char *mo_install_path_str(mo_install_path_t p) {
    switch (p) {
    case INSTALL_DATA: return "/data";
    case INSTALL_MNT:  return "/mnt";
    case INSTALL_USB:  return "/mnt/usb0";
    default:           return "/data";
    }
}

/* ── String → enum ─────────────────────────────────────────────────────────── */

mo_format_t mo_format_from_str(const char *s) {
    if (!s) return FMT_UNKNOWN;
    if (strcmp(s,"FPKG")  == 0) return FMT_FPKG;
    if (strcmp(s,"FFPKG") == 0) return FMT_FFPKG;
    if (strcmp(s,"EXFAT") == 0) return FMT_EXFAT;
    if (strcmp(s,"FFPFS") == 0) return FMT_FFPFS;
    if (strcmp(s,"Dump")  == 0) return FMT_DUMP;
    if (strcmp(s,"zip")   == 0) return FMT_ZIP;
    if (strcmp(s,"7z")    == 0) return FMT_7Z;
    if (strcmp(s,"rar")   == 0) return FMT_RAR;
    return FMT_UNKNOWN;
}

mo_category_t mo_category_from_str(const char *s) {
    if (!s) return CAT_UNKNOWN;
    if (strcmp(s,"game")     == 0) return CAT_GAME;
    if (strcmp(s,"dlc")      == 0) return CAT_DLC;
    if (strcmp(s,"update")   == 0) return CAT_UPDATE;
    if (strcmp(s,"backport") == 0) return CAT_BACKPORT;
    if (strcmp(s,"package")  == 0) return CAT_PACKAGE;
    return CAT_UNKNOWN;
}

mo_region_t mo_region_from_str(const char *s) {
    if (!s) return REGION_UNKNOWN;
    if (strcmp(s,"US")   == 0) return REGION_US;
    if (strcmp(s,"EU")   == 0) return REGION_EU;
    if (strcmp(s,"JP")   == 0) return REGION_JP;
    if (strcmp(s,"ASIA") == 0) return REGION_ASIA;
    return REGION_UNKNOWN;
}

/* ── Utility ────────────────────────────────────────────────────────────────── */

uint64_t mo_needed_bytes(const mo_variant_t *v) {
    if (!v) return 0;
    if (v->compressed)
        return (uint64_t)((double)v->size_bytes * v->expand_ratio);
    return v->size_bytes;
}

void mo_uid(char *out, size_t len, const char *prefix) {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    /* Use time + pid + random for uniqueness */
    unsigned long rnd = (unsigned long)random();
    snprintf(out, len, "%s-%lx-%lx",
             prefix ? prefix : "id",
             (unsigned long)(tv.tv_sec ^ tv.tv_usec),
             rnd & 0xFFFFFFFFUL);
}

uint64_t mo_now_ms(void) {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (uint64_t)tv.tv_sec * 1000ULL + (uint64_t)(tv.tv_usec / 1000);
}

void mo_format_bytes(char *out, size_t len, uint64_t bytes) {
    if (bytes < 1024ULL) {
        snprintf(out, len, "%llu B", (unsigned long long)bytes);
    } else if (bytes < MO_MB) {
        snprintf(out, len, "%.1f KB", (double)bytes / 1024.0);
    } else if (bytes < MO_GB) {
        snprintf(out, len, "%.1f MB", (double)bytes / (double)MO_MB);
    } else {
        snprintf(out, len, "%.2f GB", (double)bytes / (double)MO_GB);
    }
}

void mo_format_speed(char *out, size_t len, uint64_t bps) {
    if (bps == 0) {
        snprintf(out, len, "0 KB/s");
    } else if (bps < MO_MB) {
        snprintf(out, len, "%.0f KB/s", (double)bps / 1024.0);
    } else {
        snprintf(out, len, "%.1f MB/s", (double)bps / (double)MO_MB);
    }
}
