/*
 * cJSON — Ultralightweight JSON parser in ANSI C
 * Copyright (c) 2009-2017 Dave Gamble and cJSON contributors
 * MIT License — https://github.com/DaveGamble/cJSON
 *
 * Embedded minimal implementation for mo_library.elf
 * Covers: Parse, Print, Create*, Add*ToObject/Array, Delete, Get*, Is*, ForEach
 */
#include "cJSON.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#include <limits.h>

static void *(*cjson_malloc)(size_t) = malloc;
static void  (*cjson_free)(void *)   = free;

void cJSON_InitHooks(cJSON_Hooks *h) {
    if (!h) { cjson_malloc=malloc; cjson_free=free; return; }
    cjson_malloc = h->malloc_fn ? h->malloc_fn : malloc;
    cjson_free   = h->free_fn   ? h->free_fn   : free;
}
const char *cJSON_Version(void) { return "1.7.17-embedded"; }
void *cJSON_malloc(size_t s) { return cjson_malloc(s); }
void  cJSON_free(void *p)    { cjson_free(p); }

static cJSON *cJSON_New(void) {
    cJSON *n = (cJSON*)cjson_malloc(sizeof(cJSON));
    if (n) memset(n, 0, sizeof(cJSON));
    return n;
}

static char *cJSON_strdup(const char *s) {
    if (!s) return NULL;
    size_t l = strlen(s)+1;
    char *o = (char*)cjson_malloc(l);
    if (o) memcpy(o, s, l);
    return o;
}

void cJSON_Delete(cJSON *c) {
    while (c) {
        cJSON *next = c->next;
        if (!(c->type & cJSON_IsReference) && c->child) cJSON_Delete(c->child);
        if (!(c->type & cJSON_IsReference) && c->valuestring) cjson_free(c->valuestring);
        if (!(c->type & cJSON_StringIsConst) && c->string) cjson_free(c->string);
        cjson_free(c);
        c = next;
    }
}

/* ── Parser ── */
static const char *ep = NULL;
const char *cJSON_GetErrorPtr(void) { return ep; }

static const char *skip(const char *s) {
    while (s && *s && (unsigned char)*s <= ' ') s++;
    return s;
}

static const char *parse_value(cJSON *item, const char *value);
static const char *parse_string(cJSON *item, const char *str) {
    const char *ptr = str+1; char *ptr2; char *out; int len=0; unsigned uc,uc2;
    if (*str!='\"') { ep=str; return NULL; }
    while (*ptr!='\"' && *ptr && ++len) if (*ptr++=='\\') ptr++;
    out = (char*)cjson_malloc(len+1); if (!out) return NULL;
    ptr=str+1; ptr2=out;
    while (*ptr!='\"' && *ptr) {
        if (*ptr!='\\') *ptr2++=*ptr++;
        else {
            ptr++;
            switch(*ptr){
            case 'b':*ptr2++='\b';break;case 'f':*ptr2++='\f';break;
            case 'n':*ptr2++='\n';break;case 'r':*ptr2++='\r';break;
            case 't':*ptr2++='\t';break;
            case 'u':
                sscanf(ptr+1,"%4x",&uc);ptr+=4;
                if (uc>=0xD800&&uc<=0xDBFF&&*(ptr+1)=='\\' && *(ptr+2)=='u'){
                    sscanf(ptr+3,"%4x",&uc2);ptr+=6;
                    uc=0x10000+(uc-0xD800)*0x400+(uc2-0xDC00);
                }
                if (uc<0x80)*ptr2++=(char)uc;
                else if(uc<0x800){*ptr2++=(char)(0xC0|(uc>>6));*ptr2++=(char)(0x80|(uc&0x3F));}
                else if(uc<0x10000){*ptr2++=(char)(0xE0|(uc>>12));*ptr2++=(char)(0x80|((uc>>6)&0x3F));*ptr2++=(char)(0x80|(uc&0x3F));}
                else{*ptr2++=(char)(0xF0|(uc>>18));*ptr2++=(char)(0x80|((uc>>12)&0x3F));*ptr2++=(char)(0x80|((uc>>6)&0x3F));*ptr2++=(char)(0x80|(uc&0x3F));}
                break;
            default:*ptr2++=*ptr;break;
            }
            ptr++;
        }
    }
    *ptr2=0;
    if (*ptr=='\"') ptr++;
    item->valuestring=out; item->type=cJSON_String;
    return ptr;
}

static const char *parse_number(cJSON *item, const char *num) {
    double n=0,sign=1,scale=0; int subscale=0,signsubscale=1;
    if (*num=='-'){sign=-1;num++;}
    if (*num=='0') num++;
    else if (*num>='1'&&*num<='9'){n=0;do{n=n*10+(*num-'0');}while(*num++>='0'&&*num<='9');}
    if (*num=='.'&&num[1]>='0'&&num[1]<='9'){num++;while(*num>='0'&&*num<='9'){n=n*10+(*num-'0');scale--;num++;}}
    if (*num=='e'||*num=='E'){num++;if(*num=='+')num++;else if(*num=='-'){signsubscale=-1;num++;}while(*num>='0'&&*num<='9')subscale=subscale*10+(*num++-'0');}
    n=sign*n*pow(10.0,(scale+subscale*signsubscale));
    item->valuedouble=n; item->valueint=(int)n; item->type=cJSON_Number;
    return num;
}

static const char *parse_array(cJSON *item, const char *value) {
    cJSON *child; if (*value!='['){ep=value;return NULL;}
    item->type=cJSON_Array; value=skip(value+1);
    if (*value==']') return value+1;
    item->child=child=cJSON_New(); if (!item->child) return NULL;
    value=skip(parse_value(child,skip(value))); if (!value) return NULL;
    while (*value==','){
        cJSON *new_item=cJSON_New(); if (!new_item) return NULL;
        child->next=new_item; new_item->prev=child; child=new_item;
        value=skip(parse_value(child,skip(value+1))); if (!value) return NULL;
    }
    if (*value==']') return value+1; ep=value; return NULL;
}

static const char *parse_object(cJSON *item, const char *value) {
    cJSON *child; if (*value!='{'){ep=value;return NULL;}
    item->type=cJSON_Object; value=skip(value+1);
    if (*value=='}') return value+1;
    item->child=child=cJSON_New(); if (!item->child) return NULL;
    value=skip(parse_string(child,skip(value))); if (!value) return NULL;
    child->string=child->valuestring; child->valuestring=NULL;
    if (*value!=':'){ep=value;return NULL;}
    value=skip(parse_value(child,skip(value+1))); if (!value) return NULL;
    while (*value==','){
        cJSON *new_item=cJSON_New(); if (!new_item) return NULL;
        child->next=new_item; new_item->prev=child; child=new_item;
        value=skip(parse_string(child,skip(value+1))); if (!value) return NULL;
        child->string=child->valuestring; child->valuestring=NULL;
        if (*value!=':'){ep=value;return NULL;}
        value=skip(parse_value(child,skip(value+1))); if (!value) return NULL;
    }
    if (*value=='}') return value+1; ep=value; return NULL;
}

static const char *parse_value(cJSON *item, const char *value) {
    if (!value) return NULL;
    if (!strncmp(value,"null",4)){item->type=cJSON_NULL;return value+4;}
    if (!strncmp(value,"false",5)){item->type=cJSON_False;return value+5;}
    if (!strncmp(value,"true",4)){item->type=cJSON_True;item->valueint=1;return value+4;}
    if (*value=='\"') return parse_string(item,value);
    if (*value=='-'||(*value>='0'&&*value<='9')) return parse_number(item,value);
    if (*value=='[') return parse_array(item,value);
    if (*value=='{') return parse_object(item,value);
    ep=value; return NULL;
}

cJSON *cJSON_ParseWithLength(const char *v, size_t l) { (void)l; return cJSON_Parse(v); }
cJSON *cJSON_Parse(const char *value) {
    cJSON *c=cJSON_New(); if (!c) return NULL;
    ep=NULL;
    if (!parse_value(c,skip(value))){cJSON_Delete(c);return NULL;}
    return c;
}
cJSON *cJSON_ParseWithOpts(const char *v, const char **e, cJSON_bool nt) {
    (void)nt; cJSON *c=cJSON_Parse(v); if(e)*e=ep; return c;
}
cJSON *cJSON_ParseWithLengthOpts(const char *v,size_t l,const char **e,cJSON_bool nt){
    (void)l;(void)nt;cJSON *c=cJSON_Parse(v);if(e)*e=ep;return c;
}

/* ── Printer ── */
typedef struct { char *buf; int len, offset; } pb_t;
static void pb_ensure(pb_t *p, int n) {
    if (p->offset+n+1 > p->len) {
        p->len=(p->offset+n+1)*2;
        p->buf=(char*)realloc(p->buf,(size_t)p->len);
    }
}
static void pb_str(pb_t *p, const char *s) {
    int n=(int)strlen(s); pb_ensure(p,n);
    memcpy(p->buf+p->offset,s,n); p->offset+=n; p->buf[p->offset]=0;
}
static void print_value(pb_t *p, const cJSON *item, int depth, int fmt);
static void print_string_ptr(pb_t *p, const char *s) {
    const char *ptr; char *ptr2,*out; int len=0;
    pb_ensure(p,3);
    if (!s){pb_str(p,"\"\"");return;}
    for(ptr=s;*ptr;ptr++){len++;if((unsigned char)*ptr<32||*ptr=='\"'||*ptr=='\\')len+=5;}
    out=(char*)cjson_malloc((size_t)len+3); if(!out)return;
    ptr2=out; *ptr2++='\"';
    for(ptr=s;*ptr;ptr++){
        if((unsigned char)*ptr>31&&*ptr!='\"'&&*ptr!='\\')*ptr2++=*ptr;
        else{*ptr2++='\\';switch(*ptr){case'\\':*ptr2++='\\';break;case'\"':*ptr2++='\"';break;
        case'\b':*ptr2++='b';break;case'\f':*ptr2++='f';break;
        case'\n':*ptr2++='n';break;case'\r':*ptr2++='r';break;case'\t':*ptr2++='t';break;
        default:sprintf(ptr2,"u%04x",(unsigned)*ptr);ptr2+=5;break;}}
    }
    *ptr2++='\"'; *ptr2=0;
    pb_str(p,out); cjson_free(out);
}
static void print_array(pb_t *p,const cJSON *item,int d,int f){
    cJSON *c=item->child; pb_str(p,"[");
    while(c){print_value(p,c,d+1,f);c=c->next;if(c)pb_str(p,f?", ":",");}
    pb_str(p,"]");
}
static void print_object(pb_t *p,const cJSON *item,int d,int f){
    cJSON *c=item->child; pb_str(p,"{");
    while(c){
        print_string_ptr(p,c->string); pb_str(p,f?": ":":");
        print_value(p,c,d+1,f); c=c->next; if(c)pb_str(p,f?", ":",");
    }
    pb_str(p,"}");
}
static void print_value(pb_t *p,const cJSON *item,int d,int f){
    if(!item)return;
    switch(item->type&0xFF){
    case cJSON_NULL: pb_str(p,"null");break;
    case cJSON_False:pb_str(p,"false");break;
    case cJSON_True: pb_str(p,"true");break;
    case cJSON_Number:{char buf[64];
        if(fabs(item->valuedouble-item->valueint)<1e-9&&fabs(item->valuedouble)<(double)INT_MAX)
            sprintf(buf,"%d",item->valueint);
        else sprintf(buf,"%.17g",item->valuedouble);
        pb_str(p,buf);}break;
    case cJSON_String:print_string_ptr(p,item->valuestring);break;
    case cJSON_Array: print_array(p,item,d,f);break;
    case cJSON_Object:print_object(p,item,d,f);break;
    default:break;
    }
}
static char *do_print(const cJSON *item,int fmt){
    pb_t p={0};p.len=64;p.buf=(char*)cjson_malloc(64);
    if(!p.buf)return NULL; p.buf[0]=0;
    print_value(&p,item,0,fmt);
    return p.buf;
}
char *cJSON_Print(const cJSON *i){return do_print(i,1);}
char *cJSON_PrintUnformatted(const cJSON *i){return do_print(i,0);}
char *cJSON_PrintBuffered(const cJSON *i,int pb,cJSON_bool f){(void)pb;return do_print(i,f);}
cJSON_bool cJSON_PrintPreallocated(cJSON *i,char *b,int l,cJSON_bool f){
    char *s=do_print(i,f);if(!s)return 0;
    if((int)strlen(s)<l)strcpy(b,s);else{cjson_free(s);return 0;}
    cjson_free(s);return 1;
}

/* ── Array/Object operations ── */
int cJSON_GetArraySize(const cJSON *a){int c=0;if(a)for(cJSON*i=a->child;i;i=i->next)c++;return c;}
cJSON *cJSON_GetArrayItem(const cJSON *a,int i){if(!a)return NULL;cJSON*c=a->child;while(c&&i-->0)c=c->next;return c;}
cJSON *cJSON_GetObjectItemCaseSensitive(const cJSON *o,const char *s){
    if(!o||!s)return NULL;for(cJSON*c=o->child;c;c=c->next)if(c->string&&strcmp(c->string,s)==0)return c;return NULL;}
cJSON *cJSON_GetObjectItem(const cJSON *o,const char *s){
    if(!o||!s)return NULL;for(cJSON*c=o->child;c;c=c->next)if(c->string&&strcasecmp(c->string,s)==0)return c;return NULL;}
cJSON_bool cJSON_HasObjectItem(const cJSON *o,const char *s){return cJSON_GetObjectItem(o,s)?1:0;}
char *cJSON_GetStringValue(const cJSON *i){return(i&&(i->type&cJSON_String))?i->valuestring:NULL;}
double cJSON_GetNumberValue(const cJSON *i){return(i&&(i->type&cJSON_Number))?i->valuedouble:NAN;}

cJSON_bool cJSON_IsInvalid(const cJSON *i){return i&&i->type==0;}
cJSON_bool cJSON_IsFalse(const cJSON *i){return i&&(i->type&cJSON_False);}
cJSON_bool cJSON_IsTrue(const cJSON *i){return i&&(i->type&cJSON_True);}
cJSON_bool cJSON_IsBool(const cJSON *i){return i&&(i->type&(cJSON_True|cJSON_False));}
cJSON_bool cJSON_IsNull(const cJSON *i){return i&&(i->type&cJSON_NULL);}
cJSON_bool cJSON_IsNumber(const cJSON *i){return i&&(i->type&cJSON_Number);}
cJSON_bool cJSON_IsString(const cJSON *i){return i&&(i->type&cJSON_String);}
cJSON_bool cJSON_IsArray(const cJSON *i){return i&&(i->type&cJSON_Array);}
cJSON_bool cJSON_IsObject(const cJSON *i){return i&&(i->type&cJSON_Object);}
cJSON_bool cJSON_IsRaw(const cJSON *i){return i&&(i->type&cJSON_Raw);}

cJSON *cJSON_CreateNull(void){cJSON*i=cJSON_New();if(i)i->type=cJSON_NULL;return i;}
cJSON *cJSON_CreateTrue(void){cJSON*i=cJSON_New();if(i){i->type=cJSON_True;i->valueint=1;}return i;}
cJSON *cJSON_CreateFalse(void){cJSON*i=cJSON_New();if(i)i->type=cJSON_False;return i;}
cJSON *cJSON_CreateBool(cJSON_bool b){cJSON*i=cJSON_New();if(i){i->type=b?cJSON_True:cJSON_False;i->valueint=b?1:0;}return i;}
cJSON *cJSON_CreateNumber(double n){cJSON*i=cJSON_New();if(i){i->type=cJSON_Number;i->valuedouble=n;i->valueint=(int)n;}return i;}
cJSON *cJSON_CreateString(const char *s){cJSON*i=cJSON_New();if(i){i->type=cJSON_String;i->valuestring=cJSON_strdup(s);}return i;}
cJSON *cJSON_CreateRaw(const char *r){cJSON*i=cJSON_New();if(i){i->type=cJSON_Raw;i->valuestring=cJSON_strdup(r);}return i;}
cJSON *cJSON_CreateArray(void){cJSON*i=cJSON_New();if(i)i->type=cJSON_Array;return i;}
cJSON *cJSON_CreateObject(void){cJSON*i=cJSON_New();if(i)i->type=cJSON_Object;return i;}
cJSON *cJSON_CreateStringReference(const char *s){cJSON*i=cJSON_New();if(i){i->type=cJSON_String|cJSON_IsReference;i->valuestring=(char*)s;}return i;}
cJSON *cJSON_CreateObjectReference(const cJSON *c){cJSON*i=cJSON_New();if(i){i->type=cJSON_Object|cJSON_IsReference;i->child=(cJSON*)c;}return i;}
cJSON *cJSON_CreateArrayReference(const cJSON *c){cJSON*i=cJSON_New();if(i){i->type=cJSON_Array|cJSON_IsReference;i->child=(cJSON*)c;}return i;}
cJSON *cJSON_CreateIntArray(const int *n,int c){cJSON*a=cJSON_CreateArray();for(int i=0;i<c;i++){cJSON*v=cJSON_CreateNumber(n[i]);cJSON_AddItemToArray(a,v);}return a;}
cJSON *cJSON_CreateFloatArray(const float *n,int c){cJSON*a=cJSON_CreateArray();for(int i=0;i<c;i++){cJSON*v=cJSON_CreateNumber(n[i]);cJSON_AddItemToArray(a,v);}return a;}
cJSON *cJSON_CreateDoubleArray(const double *n,int c){cJSON*a=cJSON_CreateArray();for(int i=0;i<c;i++){cJSON*v=cJSON_CreateNumber(n[i]);cJSON_AddItemToArray(a,v);}return a;}
cJSON *cJSON_CreateStringArray(const char *const *s,int c){cJSON*a=cJSON_CreateArray();for(int i=0;i<c;i++){cJSON*v=cJSON_CreateString(s[i]);cJSON_AddItemToArray(a,v);}return a;}

static void suffix_object(cJSON *prev,cJSON *item){prev->next=item;item->prev=prev;}
static cJSON *create_reference(const cJSON *item){cJSON*r=cJSON_New();if(!r)return NULL;memcpy(r,item,sizeof(cJSON));r->type|=cJSON_IsReference;r->next=r->prev=NULL;return r;}

cJSON_bool cJSON_AddItemToArray(cJSON *a,cJSON *item){
    if(!a||!item)return 0;
    if(!a->child){a->child=item;}
    else{cJSON*c=a->child;while(c->next)c=c->next;suffix_object(c,item);}
    return 1;
}
cJSON_bool cJSON_AddItemToObject(cJSON *o,const char *s,cJSON *item){
    if(!o||!s||!item)return 0;
    if(item->string&&!(item->type&cJSON_StringIsConst))cjson_free(item->string);
    item->string=cJSON_strdup(s);
    return cJSON_AddItemToArray(o,item);
}
cJSON_bool cJSON_AddItemToObjectCS(cJSON *o,const char *s,cJSON *item){
    if(!o||!s||!item)return 0;
    item->string=(char*)s; item->type|=cJSON_StringIsConst;
    return cJSON_AddItemToArray(o,item);
}
cJSON_bool cJSON_AddItemReferenceToArray(cJSON *a,cJSON *item){return cJSON_AddItemToArray(a,create_reference(item));}
cJSON_bool cJSON_AddItemReferenceToObject(cJSON *o,const char *s,cJSON *item){return cJSON_AddItemToObject(o,s,create_reference(item));}

cJSON *cJSON_DetachItemViaPointer(cJSON *parent,cJSON *const item){
    if(!parent||!item)return NULL;
    if(item->prev)item->prev->next=item->next;else if(parent->child==item)parent->child=item->next;
    if(item->next)item->next->prev=item->prev;
    item->next=item->prev=NULL; return item;
}
cJSON *cJSON_DetachItemFromArray(cJSON *a,int w){return cJSON_DetachItemViaPointer(a,cJSON_GetArrayItem(a,w));}
void cJSON_DeleteItemFromArray(cJSON *a,int w){cJSON_Delete(cJSON_DetachItemFromArray(a,w));}
cJSON *cJSON_DetachItemFromObjectCaseSensitive(cJSON *o,const char *s){return cJSON_DetachItemViaPointer(o,cJSON_GetObjectItemCaseSensitive(o,s));}
void cJSON_DeleteItemFromObjectCaseSensitive(cJSON *o,const char *s){cJSON_Delete(cJSON_DetachItemFromObjectCaseSensitive(o,s));}
cJSON *cJSON_DetachItemFromObject(cJSON *o,const char *s){return cJSON_DetachItemViaPointer(o,cJSON_GetObjectItem(o,s));}
void cJSON_DeleteItemFromObject(cJSON *o,const char *s){cJSON_Delete(cJSON_DetachItemFromObject(o,s));}

cJSON_bool cJSON_InsertItemInArray(cJSON *a,int w,cJSON *item){
    cJSON *b=cJSON_GetArrayItem(a,w);if(!b){return cJSON_AddItemToArray(a,item);}
    item->next=b;item->prev=b->prev;if(b->prev)b->prev->next=item;else a->child=item;b->prev=item;return 1;
}
cJSON_bool cJSON_ReplaceItemViaPointer(cJSON *const parent,cJSON *const item,cJSON *replacement){
    if(!parent||!item||!replacement)return 0;
    replacement->next=item->next;replacement->prev=item->prev;
    if(replacement->next)replacement->next->prev=replacement;
    if(parent->child==item)parent->child=replacement;
    else if(replacement->prev)replacement->prev->next=replacement;
    item->next=item->prev=NULL;cJSON_Delete(item);return 1;
}
cJSON_bool cJSON_ReplaceItemInArray(cJSON *a,int w,cJSON *n){return cJSON_ReplaceItemViaPointer(a,cJSON_GetArrayItem(a,w),n);}
cJSON_bool cJSON_ReplaceItemInObjectCaseSensitive(cJSON *o,const char *s,cJSON *n){
    cJSON *r=cJSON_GetObjectItemCaseSensitive(o,s);if(!r)return 0;
    if(n->string&&!(n->type&cJSON_StringIsConst))cjson_free(n->string);
    n->string=cJSON_strdup(s);return cJSON_ReplaceItemViaPointer(o,r,n);
}
cJSON_bool cJSON_ReplaceItemInObject(cJSON *o,const char *s,cJSON *n){return cJSON_ReplaceItemInObjectCaseSensitive(o,s,n);}

cJSON *cJSON_Duplicate(const cJSON *item,cJSON_bool recurse){
    cJSON *n,*c,*p=NULL; if(!item)return NULL;
    n=cJSON_New(); if(!n)return NULL;
    n->type=item->type&(~cJSON_IsReference);
    n->valueint=item->valueint; n->valuedouble=item->valuedouble;
    if(item->valuestring){n->valuestring=cJSON_strdup(item->valuestring);if(!n->valuestring){cJSON_Delete(n);return NULL;}}
    if(item->string){n->string=cJSON_strdup(item->string);if(!n->string){cJSON_Delete(n);return NULL;}}
    if(!recurse)return n;
    cJSON *child=item->child;
    while(child){
        c=cJSON_Duplicate(child,1);if(!c){cJSON_Delete(n);return NULL;}
        if(p){c->prev=p;p->next=c;p=c;}else{n->child=c;p=c;}
        child=child->next;
    }
    return n;
}

cJSON_bool cJSON_Compare(const cJSON *a,const cJSON *b,const cJSON_bool cs){
    if(!a||!b)return 0;
    if((a->type&0xFF)!=(b->type&0xFF))return 0;
    switch(a->type&0xFF){
    case cJSON_NULL:case cJSON_True:case cJSON_False:return 1;
    case cJSON_Number:return fabs(a->valuedouble-b->valuedouble)<1e-10;
    case cJSON_String:case cJSON_Raw:
        if(!a->valuestring||!b->valuestring)return 0;
        return cs?strcmp(a->valuestring,b->valuestring)==0:strcasecmp(a->valuestring,b->valuestring)==0;
    default:return 0;
    }
}

void cJSON_Minify(char *j){char *i=j;if(!j)return;while(*j){if(*j==' '||*j=='\t'||*j=='\r'||*j=='\n')j++;else if(*j=='/'&&j[1]=='/'){while(*j&&*j!='\n')j++;}else if(*j=='/'&&j[1]=='*'){while(*j&&!(*j=='*'&&j[1]=='/'))j++;j+=2;}else if(*j=='\"'){*i++=*j++;while(*j&&*j!='\"'){if(*j=='\\')(*i++=*j++);*i++=*j++;}*i++=*j++;}else*i++=*j++;}*i=0;}

double cJSON_SetNumberHelper(cJSON *o,double n){if(!o)return n;o->valuedouble=n;o->valueint=(int)n;return n;}
char *cJSON_SetValuestring(cJSON *o,const char *s){if(!o)return NULL;if(o->valuestring)cjson_free(o->valuestring);o->valuestring=cJSON_strdup(s);return o->valuestring;}

/* ── Helpers ── */
cJSON *cJSON_AddNullToObject(cJSON *o,const char *n){cJSON *i=cJSON_CreateNull();if(cJSON_AddItemToObject(o,n,i))return i;cJSON_Delete(i);return NULL;}
cJSON *cJSON_AddTrueToObject(cJSON *o,const char *n){cJSON *i=cJSON_CreateTrue();if(cJSON_AddItemToObject(o,n,i))return i;cJSON_Delete(i);return NULL;}
cJSON *cJSON_AddFalseToObject(cJSON *o,const char *n){cJSON *i=cJSON_CreateFalse();if(cJSON_AddItemToObject(o,n,i))return i;cJSON_Delete(i);return NULL;}
cJSON *cJSON_AddBoolToObject(cJSON *o,const char *n,const cJSON_bool b){cJSON *i=cJSON_CreateBool(b);if(cJSON_AddItemToObject(o,n,i))return i;cJSON_Delete(i);return NULL;}
cJSON *cJSON_AddNumberToObject(cJSON *o,const char *n,const double num){cJSON *i=cJSON_CreateNumber(num);if(cJSON_AddItemToObject(o,n,i))return i;cJSON_Delete(i);return NULL;}
cJSON *cJSON_AddStringToObject(cJSON *o,const char *n,const char *s){cJSON *i=cJSON_CreateString(s);if(cJSON_AddItemToObject(o,n,i))return i;cJSON_Delete(i);return NULL;}
cJSON *cJSON_AddRawToObject(cJSON *o,const char *n,const char *r){cJSON *i=cJSON_CreateRaw(r);if(cJSON_AddItemToObject(o,n,i))return i;cJSON_Delete(i);return NULL;}
cJSON *cJSON_AddObjectToObject(cJSON *o,const char *n){cJSON *i=cJSON_CreateObject();if(cJSON_AddItemToObject(o,n,i))return i;cJSON_Delete(i);return NULL;}
cJSON *cJSON_AddArrayToObject(cJSON *o,const char *n){cJSON *i=cJSON_CreateArray();if(cJSON_AddItemToObject(o,n,i))return i;cJSON_Delete(i);return NULL;}
