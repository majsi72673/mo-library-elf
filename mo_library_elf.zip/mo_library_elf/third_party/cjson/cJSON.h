/*
  Copyright (c) 2009-2017 Dave Gamble and cJSON contributors — MIT License
  Vendored for mo_library.elf. Source: https://github.com/DaveGamble/cJSON
  Run `make vendor` to download the matching cJSON.c implementation.
*/
#ifndef cJSON__h
#define cJSON__h
#ifdef __cplusplus
extern "C" {
#endif
#include <stddef.h>
#ifndef CJSON_PUBLIC
#define CJSON_PUBLIC(type) type
#endif
#define cJSON_False   (1<<0)
#define cJSON_True    (1<<1)
#define cJSON_NULL    (1<<2)
#define cJSON_Number  (1<<3)
#define cJSON_String  (1<<4)
#define cJSON_Array   (1<<5)
#define cJSON_Object  (1<<6)
#define cJSON_Raw     (1<<7)
#define cJSON_IsReference 256
#define cJSON_StringIsConst 512
typedef struct cJSON {
    struct cJSON *next, *prev, *child;
    int type;
    char *valuestring;
    int valueint;
    double valuedouble;
    char *string;
} cJSON;
typedef int cJSON_bool;
typedef struct { void *(*malloc_fn)(size_t); void (*free_fn)(void*); } cJSON_Hooks;
CJSON_PUBLIC(void)       cJSON_InitHooks(cJSON_Hooks *hooks);
CJSON_PUBLIC(const char*)cJSON_Version(void);
CJSON_PUBLIC(cJSON*)     cJSON_Parse(const char *value);
CJSON_PUBLIC(cJSON*)     cJSON_ParseWithLength(const char *value, size_t len);
CJSON_PUBLIC(char*)      cJSON_Print(const cJSON *item);
CJSON_PUBLIC(char*)      cJSON_PrintUnformatted(const cJSON *item);
CJSON_PUBLIC(cJSON_bool) cJSON_PrintPreallocated(cJSON*,char*,int,cJSON_bool);
CJSON_PUBLIC(void)       cJSON_Delete(cJSON *item);
CJSON_PUBLIC(int)        cJSON_GetArraySize(const cJSON *array);
CJSON_PUBLIC(cJSON*)     cJSON_GetArrayItem(const cJSON *array, int index);
CJSON_PUBLIC(cJSON*)     cJSON_GetObjectItem(const cJSON *object, const char *string);
CJSON_PUBLIC(cJSON*)     cJSON_GetObjectItemCaseSensitive(const cJSON*, const char*);
CJSON_PUBLIC(cJSON_bool) cJSON_HasObjectItem(const cJSON*, const char*);
CJSON_PUBLIC(const char*)cJSON_GetErrorPtr(void);
CJSON_PUBLIC(char*)      cJSON_GetStringValue(const cJSON *item);
CJSON_PUBLIC(double)     cJSON_GetNumberValue(const cJSON *item);
/* #define cJSON_IsInvalid(x) ((x) && (x)->type == 0) */
/* #define cJSON_IsFalse(x)   ((x) && (x)->type & cJSON_False) */
/* #define cJSON_IsTrue(x)    ((x) && (x)->type & cJSON_True) */
/* #define cJSON_IsBool(x)    ((x) && (x)->type & (cJSON_True|cJSON_False)) */
/* #define cJSON_IsNull(x)    ((x) && (x)->type & cJSON_NULL) */
/* #define cJSON_IsNumber(x)  ((x) && (x)->type & cJSON_Number) */
/* #define cJSON_IsString(x)  ((x) && (x)->type & cJSON_String) */
/* #define cJSON_IsArray(x)   ((x) && (x)->type & cJSON_Array) */
/* #define cJSON_IsObject(x)  ((x) && (x)->type & cJSON_Object) */
/* #define cJSON_IsRaw(x)     ((x) && (x)->type & cJSON_Raw) */
CJSON_PUBLIC(cJSON*) cJSON_CreateNull(void);
CJSON_PUBLIC(cJSON*) cJSON_CreateTrue(void);
CJSON_PUBLIC(cJSON*) cJSON_CreateFalse(void);
CJSON_PUBLIC(cJSON*) cJSON_CreateBool(cJSON_bool boolean);
CJSON_PUBLIC(cJSON*) cJSON_CreateNumber(double num);
CJSON_PUBLIC(cJSON*) cJSON_CreateString(const char *string);
CJSON_PUBLIC(cJSON*) cJSON_CreateRaw(const char *raw);
CJSON_PUBLIC(cJSON*) cJSON_CreateArray(void);
CJSON_PUBLIC(cJSON*) cJSON_CreateObject(void);
CJSON_PUBLIC(cJSON_bool) cJSON_AddItemToArray(cJSON *array, cJSON *item);
CJSON_PUBLIC(cJSON_bool) cJSON_AddItemToObject(cJSON *object, const char *string, cJSON *item);
CJSON_PUBLIC(cJSON*)     cJSON_DetachItemFromArray(cJSON *array, int which);
CJSON_PUBLIC(void)       cJSON_DeleteItemFromArray(cJSON *array, int which);
CJSON_PUBLIC(cJSON*)     cJSON_DetachItemFromObjectCaseSensitive(cJSON*, const char*);
CJSON_PUBLIC(void)       cJSON_DeleteItemFromObjectCaseSensitive(cJSON*, const char*);
CJSON_PUBLIC(cJSON_bool) cJSON_ReplaceItemInObjectCaseSensitive(cJSON*,const char*,cJSON*);
CJSON_PUBLIC(cJSON*)     cJSON_Duplicate(const cJSON *item, cJSON_bool recurse);
CJSON_PUBLIC(cJSON_bool) cJSON_Compare(const cJSON *a, const cJSON *b, cJSON_bool cs);
CJSON_PUBLIC(void)       cJSON_Minify(char *json);
CJSON_PUBLIC(cJSON*) cJSON_AddNullToObject(cJSON *object, const char *name);
CJSON_PUBLIC(cJSON*) cJSON_AddTrueToObject(cJSON *object, const char *name);
CJSON_PUBLIC(cJSON*) cJSON_AddFalseToObject(cJSON *object, const char *name);
CJSON_PUBLIC(cJSON*) cJSON_AddBoolToObject(cJSON *object, const char *name, cJSON_bool b);
CJSON_PUBLIC(cJSON*) cJSON_AddNumberToObject(cJSON *object, const char *name, double num);
CJSON_PUBLIC(cJSON*) cJSON_AddStringToObject(cJSON *object, const char *name, const char *s);
CJSON_PUBLIC(cJSON*) cJSON_AddRawToObject(cJSON *object, const char *name, const char *raw);
CJSON_PUBLIC(cJSON*) cJSON_AddObjectToObject(cJSON *object, const char *name);
CJSON_PUBLIC(cJSON*) cJSON_AddArrayToObject(cJSON *object, const char *name);
CJSON_PUBLIC(void*)  cJSON_malloc(size_t size);
CJSON_PUBLIC(void)   cJSON_free(void *object);
#define cJSON_ArrayForEach(element, array) \
    for((element)=((array)!=NULL?(array)->child:NULL);(element)!=NULL;(element)=(element)->next)
#ifdef __cplusplus
}
#endif
#endif /* cJSON__h */
