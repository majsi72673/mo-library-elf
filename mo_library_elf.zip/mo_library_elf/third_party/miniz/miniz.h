#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct { int dummy; } mz_zip_archive;
typedef unsigned int mz_uint;
typedef struct {
    char m_filename[512];
    unsigned long long m_uncomp_size;
    int m_is_directory;
} mz_zip_archive_file_stat;
static inline int  mz_zip_reader_init_file(mz_zip_archive *z,const char*p,int f){(void)z;(void)p;(void)f;return 0;}
static inline mz_uint mz_zip_reader_get_num_files(mz_zip_archive *z){(void)z;return 0;}
static inline int  mz_zip_reader_file_stat(mz_zip_archive *z,mz_uint i,mz_zip_archive_file_stat*s){(void)z;(void)i;(void)s;return 0;}
static inline int  mz_zip_reader_is_file_a_directory(mz_zip_archive *z,mz_uint i){(void)z;(void)i;return 0;}
static inline int  mz_zip_reader_extract_to_file(mz_zip_archive *z,mz_uint i,const char*p,int f){(void)z;(void)i;(void)p;(void)f;return 0;}
static inline void mz_zip_reader_end(mz_zip_archive *z){(void)z;}
